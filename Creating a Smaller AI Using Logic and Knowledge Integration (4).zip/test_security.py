"""
Comprehensive tests for the Child AI security system
Tests authentication, authorization, and security mechanisms
"""

import pytest
import jwt
import time
import sqlite3
import os
import sys
from datetime import datetime, timedelta

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from security import SecurityManager, require_auth, require_role, rate_limit

class TestSecurityManager:
    """Test suite for SecurityManager class"""
    
    def setup_method(self):
        """Setup test environment"""
        # Use in-memory database for testing
        self.test_db = ":memory:"
        self.security_manager = SecurityManager(
            secret_key="test_secret_key",
            db_path=self.test_db
        )
    
    def test_security_manager_initialization(self):
        """Test security manager initialization"""
        assert self.security_manager is not None
        assert self.security_manager.secret_key == "test_secret_key"
        assert self.security_manager.db_path == self.test_db
        assert self.security_manager.token_expiry == 3600
    
    def test_database_initialization(self):
        """Test database table creation"""
        conn = sqlite3.connect(self.test_db)
        cursor = conn.cursor()
        
        # Check if tables exist
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        expected_tables = ['users', 'sessions', 'api_keys', 'rate_limits']
        for table in expected_tables:
            assert table in tables
        
        conn.close()
    
    def test_password_hashing(self):
        """Test password hashing and verification"""
        password = "test_password_123"
        salt = "test_salt"
        
        # Test hashing
        hash1 = self.security_manager.hash_password(password, salt)
        hash2 = self.security_manager.hash_password(password, salt)
        
        # Same password and salt should produce same hash
        assert hash1 == hash2
        
        # Test verification
        assert self.security_manager.verify_password(password, hash1, salt)
        assert not self.security_manager.verify_password("wrong_password", hash1, salt)
    
    def test_default_admin_creation(self):
        """Test default admin user creation"""
        conn = sqlite3.connect(self.test_db)
        cursor = conn.cursor()
        
        cursor.execute("SELECT username, role FROM users WHERE role = 'admin'")
        admin_user = cursor.fetchone()
        
        assert admin_user is not None
        assert admin_user[0] == "admin"
        assert admin_user[1] == "admin"
        
        conn.close()
    
    def test_user_authentication(self):
        """Test user authentication"""
        # Test with default admin
        result = self.security_manager.authenticate_user("admin", "admin123")
        assert result['success'] is True
        assert result['username'] == "admin"
        assert result['role'] == "admin"
        
        # Test with wrong password
        result = self.security_manager.authenticate_user("admin", "wrong_password")
        assert result['success'] is False
        assert 'error' in result
        
        # Test with non-existent user
        result = self.security_manager.authenticate_user("nonexistent", "password")
        assert result['success'] is False
    
    def test_token_generation_and_verification(self):
        """Test JWT token generation and verification"""
        user_id = 1
        username = "testuser"
        role = "user"
        
        # Generate token
        token = self.security_manager.generate_token(user_id, username, role)
        assert token is not None
        assert isinstance(token, str)
        
        # Verify token
        verification_result = self.security_manager.verify_token(token)
        assert verification_result['valid'] is True
        assert verification_result['user_id'] == user_id
        assert verification_result['username'] == username
        assert verification_result['role'] == role
    
    def test_token_expiration(self):
        """Test token expiration handling"""
        # Create security manager with very short expiry
        short_expiry_manager = SecurityManager(
            secret_key="test_key",
            db_path=":memory:"
        )
        short_expiry_manager.token_expiry = 1  # 1 second
        
        token = short_expiry_manager.generate_token(1, "testuser", "user")
        
        # Token should be valid immediately
        result = short_expiry_manager.verify_token(token)
        assert result['valid'] is True
        
        # Wait for expiration
        time.sleep(2)
        
        # Token should be expired
        result = short_expiry_manager.verify_token(token)
        assert result['valid'] is False
        assert 'expired' in result['error'].lower()
    
    def test_invalid_token_handling(self):
        """Test handling of invalid tokens"""
        # Test completely invalid token
        result = self.security_manager.verify_token("invalid_token")
        assert result['valid'] is False
        assert 'invalid' in result['error'].lower()
        
        # Test token with wrong secret
        wrong_secret_token = jwt.encode(
            {'user_id': 1, 'username': 'test', 'role': 'user'},
            'wrong_secret',
            algorithm='HS256'
        )
        result = self.security_manager.verify_token(wrong_secret_token)
        assert result['valid'] is False
    
    def test_token_revocation(self):
        """Test token revocation"""
        token = self.security_manager.generate_token(1, "testuser", "user")
        
        # Token should be valid
        result = self.security_manager.verify_token(token)
        assert result['valid'] is True
        
        # Revoke token
        self.security_manager.revoke_token(token)
        
        # Token should be invalid after revocation
        result = self.security_manager.verify_token(token)
        assert result['valid'] is False
    
    def test_rate_limiting(self):
        """Test rate limiting functionality"""
        identifier = "test_user"
        endpoint = "test_endpoint"
        limit = 3
        window = 60
        
        # Should allow requests within limit
        for i in range(limit):
            result = self.security_manager.check_rate_limit(identifier, endpoint, limit, window)
            assert result is True
        
        # Should block request exceeding limit
        result = self.security_manager.check_rate_limit(identifier, endpoint, limit, window)
        assert result is False
    
    def test_session_cleanup(self):
        """Test expired session cleanup"""
        # Create a session
        token = self.security_manager.generate_token(1, "testuser", "user")
        
        # Manually expire the session in database
        conn = sqlite3.connect(self.test_db)
        cursor = conn.cursor()
        
        past_time = datetime.utcnow() - timedelta(hours=1)
        cursor.execute(
            "UPDATE sessions SET expires_at = ? WHERE user_id = ?",
            (past_time, 1)
        )
        conn.commit()
        conn.close()
        
        # Cleanup should remove expired sessions
        self.security_manager.cleanup_expired_sessions()
        
        # Verify session is removed
        conn = sqlite3.connect(self.test_db)
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM sessions WHERE user_id = ?", (1,))
        count = cursor.fetchone()[0]
        conn.close()
        
        assert count == 0

class TestSecurityDecorators:
    """Test suite for security decorators"""
    
    def setup_method(self):
        """Setup test environment"""
        self.security_manager = SecurityManager(
            secret_key="test_secret",
            db_path=":memory:"
        )
    
    def test_require_auth_decorator(self):
        """Test require_auth decorator"""
        from flask import Flask, request
        
        app = Flask(__name__)
        app.security_manager = self.security_manager
        
        @require_auth
        def protected_function():
            return "success"
        
        with app.test_request_context():
            # Test without token
            with pytest.raises(Exception):  # Should raise authentication error
                protected_function()
    
    def test_require_role_decorator(self):
        """Test require_role decorator"""
        from flask import Flask, request
        
        app = Flask(__name__)
        app.security_manager = self.security_manager
        
        @require_role('admin')
        def admin_function():
            return "admin_success"
        
        # This test would need more complex setup with Flask request context
        # For now, just verify the decorator exists and is callable
        assert callable(admin_function)
    
    def test_rate_limit_decorator(self):
        """Test rate_limit decorator"""
        from flask import Flask
        
        app = Flask(__name__)
        app.security_manager = self.security_manager
        
        @rate_limit(limit=2, window=60)
        def rate_limited_function():
            return "success"
        
        # Verify decorator exists and is callable
        assert callable(rate_limited_function)

class TestSecurityIntegration:
    """Integration tests for security system"""
    
    def setup_method(self):
        """Setup test environment"""
        self.security_manager = SecurityManager(
            secret_key="integration_test_key",
            db_path=":memory:"
        )
    
    def test_complete_authentication_flow(self):
        """Test complete authentication flow"""
        # 1. Authenticate user
        auth_result = self.security_manager.authenticate_user("admin", "admin123")
        assert auth_result['success'] is True
        
        # 2. Generate token
        token = self.security_manager.generate_token(
            auth_result['user_id'],
            auth_result['username'],
            auth_result['role']
        )
        assert token is not None
        
        # 3. Verify token
        verification = self.security_manager.verify_token(token)
        assert verification['valid'] is True
        
        # 4. Use token for subsequent requests (simulated)
        assert verification['username'] == "admin"
        assert verification['role'] == "admin"
    
    def test_security_with_multiple_users(self):
        """Test security system with multiple users"""
        # Create additional test user
        conn = sqlite3.connect(self.security_manager.db_path)
        cursor = conn.cursor()
        
        salt = "test_salt"
        password_hash = self.security_manager.hash_password("user123", salt)
        
        cursor.execute('''
            INSERT INTO users (username, email, password_hash, salt, role)
            VALUES (?, ?, ?, ?, ?)
        ''', ("testuser", "test@example.com", password_hash, salt, "user"))
        
        conn.commit()
        conn.close()
        
        # Test authentication for both users
        admin_auth = self.security_manager.authenticate_user("admin", "admin123")
        user_auth = self.security_manager.authenticate_user("testuser", "user123")
        
        assert admin_auth['success'] is True
        assert user_auth['success'] is True
        assert admin_auth['role'] == "admin"
        assert user_auth['role'] == "user"
        
        # Generate tokens for both
        admin_token = self.security_manager.generate_token(
            admin_auth['user_id'], admin_auth['username'], admin_auth['role']
        )
        user_token = self.security_manager.generate_token(
            user_auth['user_id'], user_auth['username'], user_auth['role']
        )
        
        # Verify both tokens
        admin_verification = self.security_manager.verify_token(admin_token)
        user_verification = self.security_manager.verify_token(user_token)
        
        assert admin_verification['valid'] is True
        assert user_verification['valid'] is True
        assert admin_verification['role'] == "admin"
        assert user_verification['role'] == "user"
    
    def test_concurrent_rate_limiting(self):
        """Test rate limiting with concurrent requests"""
        import threading
        
        results = []
        
        def make_request():
            result = self.security_manager.check_rate_limit("test_user", "test_endpoint", 5, 60)
            results.append(result)
        
        # Create multiple threads
        threads = []
        for i in range(10):
            thread = threading.Thread(target=make_request)
            threads.append(thread)
        
        # Start all threads
        for thread in threads:
            thread.start()
        
        # Wait for all threads to complete
        for thread in threads:
            thread.join()
        
        # Check results - should have some True and some False
        true_count = sum(1 for r in results if r)
        false_count = sum(1 for r in results if not r)
        
        assert true_count <= 5  # Should not exceed limit
        assert false_count >= 5  # Some should be blocked
    
    def test_security_error_handling(self):
        """Test security system error handling"""
        # Test with corrupted database path
        try:
            corrupted_manager = SecurityManager(db_path="/invalid/path/database.db")
            # Should handle gracefully or raise appropriate exception
        except Exception as e:
            # Should be a specific, handleable exception
            assert isinstance(e, (OSError, sqlite3.Error))
        
        # Test with invalid token format
        result = self.security_manager.verify_token("not.a.jwt.token")
        assert result['valid'] is False
        assert 'error' in result

if __name__ == '__main__':
    pytest.main([__file__, '-v'])

