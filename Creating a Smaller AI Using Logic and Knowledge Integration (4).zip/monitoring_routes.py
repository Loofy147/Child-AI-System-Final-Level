"""
Monitoring and observability routes for Child AI system
Provides health checks, metrics, and system status endpoints
"""

from flask import Blueprint, jsonify, request, current_app
from src.security import require_auth, require_role, rate_limit
from src.monitoring import HealthChecker, MetricsCollector
import sqlite3
from datetime import datetime, timedelta
import json

monitoring_bp = Blueprint('monitoring', __name__, url_prefix='/api/monitoring')

@monitoring_bp.route('/health', methods=['GET'])
@rate_limit(limit=60, window=60)  # 60 requests per minute
def health_check():
    """Comprehensive health check endpoint"""
    try:
        health_checker = HealthChecker()
        health_status = health_checker.run_all_checks()
        
        # Determine HTTP status code based on health
        if health_status['overall_status'] == 'healthy':
            status_code = 200
        elif health_status['overall_status'] == 'warning':
            status_code = 200  # Still operational
        else:
            status_code = 503  # Service unavailable
        
        return jsonify({
            'success': True,
            'health': health_status
        }), status_code
        
    except Exception as e:
        current_app.logger.error(f"Health check error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Health check failed',
            'overall_status': 'unhealthy'
        }), 503

@monitoring_bp.route('/metrics', methods=['GET'])
@require_auth
@require_role('admin')
def get_metrics():
    """Get system metrics summary"""
    try:
        hours = request.args.get('hours', 24, type=int)
        hours = min(hours, 168)  # Limit to 1 week
        
        metrics_collector = current_app.metrics_collector
        metrics_summary = metrics_collector.get_metrics_summary(hours=hours)
        
        return jsonify({
            'success': True,
            'metrics': metrics_summary,
            'period_hours': hours
        })
        
    except Exception as e:
        current_app.logger.error(f"Metrics retrieval error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve metrics'
        }), 500

@monitoring_bp.route('/metrics/realtime', methods=['GET'])
@require_auth
@require_role('admin')
def get_realtime_metrics():
    """Get real-time system metrics"""
    try:
        import psutil
        
        # Get current system stats
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Get recent request metrics
        metrics_collector = current_app.metrics_collector
        conn = sqlite3.connect(metrics_collector.db_path)
        cursor = conn.cursor()
        
        # Last 5 minutes of requests
        five_minutes_ago = datetime.utcnow() - timedelta(minutes=5)
        cursor.execute('''
            SELECT COUNT(*) as request_count,
                   AVG(response_time_ms) as avg_response_time,
                   COUNT(CASE WHEN status_code >= 400 THEN 1 END) as error_count
            FROM app_metrics 
            WHERE timestamp > ?
        ''', (five_minutes_ago,))
        
        recent_requests = cursor.fetchone()
        
        # Active AI operations (last minute)
        one_minute_ago = datetime.utcnow() - timedelta(minutes=1)
        cursor.execute('''
            SELECT COUNT(*) as ai_operations,
                   AVG(duration_ms) as avg_duration,
                   SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successful_ops
            FROM ai_metrics 
            WHERE timestamp > ?
        ''', (one_minute_ago,))
        
        recent_ai_ops = cursor.fetchone()
        conn.close()
        
        return jsonify({
            'success': True,
            'realtime_metrics': {
                'timestamp': datetime.utcnow().isoformat(),
                'system': {
                    'cpu_percent': round(cpu_percent, 2),
                    'memory_percent': round(memory.percent, 2),
                    'memory_used_gb': round(memory.used / (1024**3), 2),
                    'disk_percent': round(disk.percent, 2),
                    'disk_free_gb': round(disk.free / (1024**3), 2)
                },
                'requests_last_5min': {
                    'total_requests': recent_requests[0] or 0,
                    'avg_response_time_ms': round(recent_requests[1] or 0, 2),
                    'error_count': recent_requests[2] or 0
                },
                'ai_operations_last_1min': {
                    'total_operations': recent_ai_ops[0] or 0,
                    'avg_duration_ms': round(recent_ai_ops[1] or 0, 2),
                    'successful_operations': recent_ai_ops[2] or 0
                }
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Real-time metrics error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve real-time metrics'
        }), 500

@monitoring_bp.route('/logs', methods=['GET'])
@require_auth
@require_role('admin')
def get_logs():
    """Get recent log entries"""
    try:
        level = request.args.get('level', 'INFO')
        limit = min(request.args.get('limit', 100, type=int), 1000)
        hours = min(request.args.get('hours', 24, type=int), 168)
        
        # Read log file
        log_entries = []
        try:
            with open('logs/child_ai.log', 'r') as f:
                lines = f.readlines()
                
            # Parse JSON log entries
            cutoff_time = datetime.utcnow() - timedelta(hours=hours)
            
            for line in reversed(lines[-limit*2:]):  # Get more lines to filter
                try:
                    log_entry = json.loads(line.strip())
                    log_time = datetime.fromisoformat(log_entry['timestamp'].replace('Z', '+00:00'))
                    
                    if log_time >= cutoff_time:
                        if level == 'ALL' or log_entry['level'] == level:
                            log_entries.append(log_entry)
                            
                        if len(log_entries) >= limit:
                            break
                            
                except (json.JSONDecodeError, KeyError, ValueError):
                    continue
                    
        except FileNotFoundError:
            log_entries = []
        
        return jsonify({
            'success': True,
            'logs': log_entries[:limit],
            'total_returned': len(log_entries),
            'filters': {
                'level': level,
                'hours': hours,
                'limit': limit
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Log retrieval error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve logs'
        }), 500

@monitoring_bp.route('/errors', methods=['GET'])
@require_auth
@require_role('admin')
def get_errors():
    """Get recent error logs"""
    try:
        limit = min(request.args.get('limit', 50, type=int), 500)
        hours = min(request.args.get('hours', 24, type=int), 168)
        
        metrics_collector = current_app.metrics_collector
        conn = sqlite3.connect(metrics_collector.db_path)
        cursor = conn.cursor()
        
        since = datetime.utcnow() - timedelta(hours=hours)
        cursor.execute('''
            SELECT timestamp, error_type, error_message, endpoint, user_id, request_data
            FROM error_logs 
            WHERE timestamp > ?
            ORDER BY timestamp DESC
            LIMIT ?
        ''', (since, limit))
        
        errors = cursor.fetchall()
        conn.close()
        
        error_list = []
        for error in errors:
            error_data = {
                'timestamp': error[0],
                'error_type': error[1],
                'error_message': error[2],
                'endpoint': error[3],
                'user_id': error[4]
            }
            
            if error[5]:
                try:
                    error_data['request_data'] = json.loads(error[5])
                except json.JSONDecodeError:
                    error_data['request_data'] = error[5]
            
            error_list.append(error_data)
        
        return jsonify({
            'success': True,
            'errors': error_list,
            'total_returned': len(error_list),
            'period_hours': hours
        })
        
    except Exception as e:
        current_app.logger.error(f"Error log retrieval error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve error logs'
        }), 500

@monitoring_bp.route('/performance', methods=['GET'])
@require_auth
@require_role('admin')
def get_performance_metrics():
    """Get detailed performance metrics"""
    try:
        hours = min(request.args.get('hours', 24, type=int), 168)
        
        metrics_collector = current_app.metrics_collector
        conn = sqlite3.connect(metrics_collector.db_path)
        cursor = conn.cursor()
        
        since = datetime.utcnow() - timedelta(hours=hours)
        
        # Endpoint performance
        cursor.execute('''
            SELECT endpoint, 
                   COUNT(*) as request_count,
                   AVG(response_time_ms) as avg_response_time,
                   MAX(response_time_ms) as max_response_time,
                   MIN(response_time_ms) as min_response_time,
                   COUNT(CASE WHEN status_code >= 400 THEN 1 END) as error_count
            FROM app_metrics 
            WHERE timestamp > ?
            GROUP BY endpoint
            ORDER BY request_count DESC
        ''', (since,))
        
        endpoint_stats = cursor.fetchall()
        
        # AI operation performance
        cursor.execute('''
            SELECT operation_type,
                   COUNT(*) as operation_count,
                   AVG(duration_ms) as avg_duration,
                   MAX(duration_ms) as max_duration,
                   MIN(duration_ms) as min_duration,
                   SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successful_count,
                   AVG(facts_processed) as avg_facts_processed,
                   AVG(inferences_made) as avg_inferences_made
            FROM ai_metrics 
            WHERE timestamp > ?
            GROUP BY operation_type
            ORDER BY operation_count DESC
        ''', (since,))
        
        ai_operation_stats = cursor.fetchall()
        
        # Hourly request distribution
        cursor.execute('''
            SELECT strftime('%Y-%m-%d %H:00:00', timestamp) as hour,
                   COUNT(*) as request_count,
                   AVG(response_time_ms) as avg_response_time
            FROM app_metrics 
            WHERE timestamp > ?
            GROUP BY strftime('%Y-%m-%d %H:00:00', timestamp)
            ORDER BY hour
        ''', (since,))
        
        hourly_stats = cursor.fetchall()
        
        conn.close()
        
        # Format results
        endpoint_performance = []
        for stat in endpoint_stats:
            endpoint_performance.append({
                'endpoint': stat[0],
                'request_count': stat[1],
                'avg_response_time_ms': round(stat[2], 2),
                'max_response_time_ms': round(stat[3], 2),
                'min_response_time_ms': round(stat[4], 2),
                'error_count': stat[5],
                'error_rate': round((stat[5] / stat[1]) * 100, 2) if stat[1] > 0 else 0
            })
        
        ai_performance = []
        for stat in ai_operation_stats:
            ai_performance.append({
                'operation_type': stat[0],
                'operation_count': stat[1],
                'avg_duration_ms': round(stat[2], 2),
                'max_duration_ms': round(stat[3], 2),
                'min_duration_ms': round(stat[4], 2),
                'successful_count': stat[5],
                'success_rate': round((stat[5] / stat[1]) * 100, 2) if stat[1] > 0 else 0,
                'avg_facts_processed': round(stat[6] or 0, 2),
                'avg_inferences_made': round(stat[7] or 0, 2)
            })
        
        hourly_distribution = []
        for stat in hourly_stats:
            hourly_distribution.append({
                'hour': stat[0],
                'request_count': stat[1],
                'avg_response_time_ms': round(stat[2], 2)
            })
        
        return jsonify({
            'success': True,
            'performance': {
                'endpoint_performance': endpoint_performance,
                'ai_operation_performance': ai_performance,
                'hourly_distribution': hourly_distribution
            },
            'period_hours': hours
        })
        
    except Exception as e:
        current_app.logger.error(f"Performance metrics error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve performance metrics'
        }), 500

@monitoring_bp.route('/dashboard', methods=['GET'])
@require_auth
@require_role('admin')
def get_dashboard_data():
    """Get comprehensive dashboard data"""
    try:
        # Get health status
        health_checker = HealthChecker()
        health_status = health_checker.run_all_checks()
        
        # Get metrics summary
        metrics_collector = current_app.metrics_collector
        metrics_summary = metrics_collector.get_metrics_summary(hours=24)
        
        # Get real-time system stats
        import psutil
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Get recent activity
        conn = sqlite3.connect(metrics_collector.db_path)
        cursor = conn.cursor()
        
        # Active users (last hour)
        one_hour_ago = datetime.utcnow() - timedelta(hours=1)
        cursor.execute('''
            SELECT COUNT(DISTINCT user_id) as active_users
            FROM app_metrics 
            WHERE timestamp > ? AND user_id IS NOT NULL
        ''', (one_hour_ago,))
        
        active_users = cursor.fetchone()[0] or 0
        
        # Recent errors (last hour)
        cursor.execute('''
            SELECT COUNT(*) as recent_errors
            FROM error_logs 
            WHERE timestamp > ?
        ''', (one_hour_ago,))
        
        recent_errors = cursor.fetchone()[0] or 0
        
        conn.close()
        
        return jsonify({
            'success': True,
            'dashboard': {
                'timestamp': datetime.utcnow().isoformat(),
                'health': health_status,
                'system': {
                    'cpu_percent': round(cpu_percent, 2),
                    'memory_percent': round(memory.percent, 2),
                    'disk_percent': round(disk.percent, 2)
                },
                'metrics_24h': metrics_summary,
                'activity': {
                    'active_users_last_hour': active_users,
                    'recent_errors_last_hour': recent_errors
                }
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Dashboard data error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Failed to retrieve dashboard data'
        }), 500

