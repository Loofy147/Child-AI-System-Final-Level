"""
Reinforcement Learning Agent for Child AI
Implements Q-Learning and Policy Gradient methods for autonomous learning
"""

import numpy as np
import random
import json
import pickle
from typing import Dict, List, Tuple, Any, Optional, Callable
from dataclasses import dataclass, asdict
from collections import defaultdict, deque
import logging
from datetime import datetime
import math

from rl_environment import KnowledgeLearningEnvironment, Action, ActionType, Observation
from logic_engine import LogicEngine
from knowledge_integration import KnowledgeIntegrator

@dataclass
class RLConfig:
    """Configuration for the RL agent"""
    learning_rate: float = 0.1
    discount_factor: float = 0.95
    epsilon: float = 1.0  # Exploration rate
    epsilon_decay: float = 0.995
    epsilon_min: float = 0.01
    memory_size: int = 10000
    batch_size: int = 32
    target_update_frequency: int = 100
    save_frequency: int = 1000
    algorithm: str = "dqn"  # "dqn", "q_learning", "policy_gradient"

class ExperienceReplay:
    """Experience replay buffer for storing and sampling experiences"""
    
    def __init__(self, capacity: int):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)
        self.position = 0
    
    def push(self, state: Dict, action: Dict, reward: float, next_state: Dict, done: bool):
        """Add an experience to the buffer"""
        experience = {
            'state': state,
            'action': action,
            'reward': reward,
            'next_state': next_state,
            'done': done,
            'timestamp': datetime.utcnow().isoformat()
        }
        self.buffer.append(experience)
    
    def sample(self, batch_size: int) -> List[Dict]:
        """Sample a batch of experiences"""
        return random.sample(self.buffer, min(batch_size, len(self.buffer)))
    
    def __len__(self) -> int:
        return len(self.buffer)

class QTable:
    """Q-Table for tabular Q-learning"""
    
    def __init__(self, learning_rate: float = 0.1, discount_factor: float = 0.95):
        self.q_table = defaultdict(lambda: defaultdict(float))
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.visit_counts = defaultdict(lambda: defaultdict(int))
    
    def get_q_value(self, state: str, action: str) -> float:
        """Get Q-value for state-action pair"""
        return self.q_table[state][action]
    
    def update_q_value(self, state: str, action: str, reward: float, next_state: str, done: bool):
        """Update Q-value using Q-learning update rule"""
        current_q = self.q_table[state][action]
        
        if done:
            target_q = reward
        else:
            # Find maximum Q-value for next state
            next_q_values = self.q_table[next_state]
            max_next_q = max(next_q_values.values()) if next_q_values else 0.0
            target_q = reward + self.discount_factor * max_next_q
        
        # Q-learning update
        self.q_table[state][action] = current_q + self.learning_rate * (target_q - current_q)
        self.visit_counts[state][action] += 1
    
    def get_best_action(self, state: str, available_actions: List[str]) -> str:
        """Get the best action for a given state"""
        if not available_actions:
            return random.choice(list(ActionType))
        
        q_values = {action: self.get_q_value(state, action) for action in available_actions}
        return max(q_values, key=q_values.get)
    
    def get_action_values(self, state: str) -> Dict[str, float]:
        """Get all action values for a state"""
        return dict(self.q_table[state])

class PolicyNetwork:
    """Simple policy network for policy gradient methods"""
    
    def __init__(self, state_dim: int, action_dim: int, learning_rate: float = 0.01):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.learning_rate = learning_rate
        
        # Simple linear policy (in practice, would use neural networks)
        self.weights = np.random.randn(state_dim, action_dim) * 0.1
        self.bias = np.zeros(action_dim)
        
        # For tracking gradients
        self.states = []
        self.actions = []
        self.rewards = []
    
    def predict(self, state_vector: np.ndarray) -> np.ndarray:
        """Predict action probabilities"""
        logits = np.dot(state_vector, self.weights) + self.bias
        # Softmax
        exp_logits = np.exp(logits - np.max(logits))
        return exp_logits / np.sum(exp_logits)
    
    def select_action(self, state_vector: np.ndarray) -> int:
        """Select action based on policy"""
        action_probs = self.predict(state_vector)
        return np.random.choice(len(action_probs), p=action_probs)
    
    def store_transition(self, state: np.ndarray, action: int, reward: float):
        """Store transition for policy gradient update"""
        self.states.append(state)
        self.actions.append(action)
        self.rewards.append(reward)
    
    def update_policy(self, discount_factor: float = 0.95):
        """Update policy using REINFORCE algorithm"""
        if not self.states:
            return
        
        # Calculate discounted rewards
        discounted_rewards = []
        cumulative_reward = 0
        for reward in reversed(self.rewards):
            cumulative_reward = reward + discount_factor * cumulative_reward
            discounted_rewards.insert(0, cumulative_reward)
        
        # Normalize rewards
        discounted_rewards = np.array(discounted_rewards)
        discounted_rewards = (discounted_rewards - np.mean(discounted_rewards)) / (np.std(discounted_rewards) + 1e-8)
        
        # Calculate gradients and update
        for state, action, reward in zip(self.states, self.actions, discounted_rewards):
            # Simple policy gradient update
            action_probs = self.predict(state)
            
            # Update weights (simplified gradient ascent)
            grad_log_prob = np.zeros_like(action_probs)
            grad_log_prob[action] = 1.0 / action_probs[action]
            
            # Update weights
            self.weights += self.learning_rate * reward * np.outer(state, grad_log_prob)
            self.bias += self.learning_rate * reward * grad_log_prob
        
        # Clear stored transitions
        self.states.clear()
        self.actions.clear()
        self.rewards.clear()

class RLAgent:
    """
    Reinforcement Learning Agent that learns to interact with the knowledge environment
    Integrates with the existing Child AI logic engine and knowledge integrator
    """
    
    def __init__(self, 
                 logic_engine: LogicEngine,
                 knowledge_integrator: KnowledgeIntegrator,
                 config: Optional[RLConfig] = None):
        """Initialize the RL agent"""
        self.config = config or RLConfig()
        self.logger = logging.getLogger(__name__)
        
        # Core AI components
        self.logic_engine = logic_engine
        self.knowledge_integrator = knowledge_integrator
        
        # RL components
        self.q_table = QTable(self.config.learning_rate, self.config.discount_factor)
        self.experience_replay = ExperienceReplay(self.config.memory_size)
        self.policy_network = PolicyNetwork(20, len(ActionType), self.config.learning_rate)
        
        # Training state
        self.current_episode = 0
        self.total_steps = 0
        self.epsilon = self.config.epsilon
        
        # Performance tracking
        self.episode_rewards = []
        self.episode_lengths = []
        self.learning_curves = []
        self.action_statistics = defaultdict(int)
        
        # State representation
        self.state_encoder = StateEncoder()
        
        self.logger.info(f"RL Agent initialized with algorithm: {self.config.algorithm}")
    
    def select_action(self, state: Dict[str, Any], available_actions: List[ActionType]) -> Action:
        """Select an action based on the current policy"""
        
        if self.config.algorithm == "q_learning":
            return self._select_action_q_learning(state, available_actions)
        elif self.config.algorithm == "dqn":
            return self._select_action_dqn(state, available_actions)
        elif self.config.algorithm == "policy_gradient":
            return self._select_action_policy_gradient(state, available_actions)
        else:
            return self._select_action_random(available_actions)
    
    def _select_action_q_learning(self, state: Dict[str, Any], available_actions: List[ActionType]) -> Action:
        """Select action using epsilon-greedy Q-learning"""
        state_str = self.state_encoder.encode_state(state)
        action_strs = [action.value for action in available_actions]
        
        # Epsilon-greedy action selection
        if random.random() < self.epsilon:
            # Explore: random action
            action_type = random.choice(available_actions)
        else:
            # Exploit: best action according to Q-table
            best_action_str = self.q_table.get_best_action(state_str, action_strs)
            action_type = ActionType(best_action_str)
        
        # Generate action parameters based on action type and current state
        parameters = self._generate_action_parameters(action_type, state)
        
        return Action(
            action_type=action_type,
            parameters=parameters,
            timestamp=datetime.utcnow()
        )
    
    def _select_action_dqn(self, state: Dict[str, Any], available_actions: List[ActionType]) -> Action:
        """Select action using Deep Q-Network (simplified version)"""
        # For now, use Q-learning approach
        # In a full implementation, this would use a neural network
        return self._select_action_q_learning(state, available_actions)
    
    def _select_action_policy_gradient(self, state: Dict[str, Any], available_actions: List[ActionType]) -> Action:
        """Select action using policy gradient method"""
        state_vector = self.state_encoder.encode_state_vector(state)
        action_index = self.policy_network.select_action(state_vector)
        
        # Map action index to available actions
        if action_index < len(available_actions):
            action_type = available_actions[action_index]
        else:
            action_type = random.choice(available_actions)
        
        parameters = self._generate_action_parameters(action_type, state)
        
        return Action(
            action_type=action_type,
            parameters=parameters,
            timestamp=datetime.utcnow()
        )
    
    def _select_action_random(self, available_actions: List[ActionType]) -> Action:
        """Select random action (baseline)"""
        action_type = random.choice(available_actions)
        parameters = self._generate_action_parameters(action_type, {})
        
        return Action(
            action_type=action_type,
            parameters=parameters,
            timestamp=datetime.utcnow()
        )
    
    def _generate_action_parameters(self, action_type: ActionType, state: Dict[str, Any]) -> Dict[str, Any]:
        """Generate appropriate parameters for the given action type"""
        parameters = {}
        
        if action_type == ActionType.ADD_FACT:
            # Generate a fact to add (could be based on current scenario)
            scenario_info = state.get('available_knowledge', {})
            available_facts = scenario_info.get('facts', [])
            if available_facts:
                parameters['fact'] = random.choice(available_facts)
            else:
                parameters['fact'] = 'TestFact(x)'
        
        elif action_type == ActionType.ADD_RULE:
            # Generate a rule to add
            scenario_info = state.get('available_knowledge', {})
            available_rules = scenario_info.get('rules', [])
            if available_rules:
                parameters['rule'] = random.choice(available_rules)
            else:
                parameters['rule'] = 'TestRule(X) → TestConclusion(X)'
        
        elif action_type == ActionType.MAKE_INFERENCE:
            # Generate a query to make
            scenario_info = state.get('available_knowledge', {})
            available_queries = scenario_info.get('queries', [])
            if available_queries:
                parameters['query'] = random.choice(available_queries)
                # Simulate inference result (in practice, would use logic engine)
                parameters['result'] = random.choice([True, False])
            else:
                parameters['query'] = 'TestQuery(x)?'
                parameters['result'] = True
        
        elif action_type == ActionType.QUERY_KNOWLEDGE:
            parameters['topic'] = 'general'
        
        elif action_type == ActionType.LEARN_FROM_FEEDBACK:
            parameters['feedback_type'] = 'correction'
            parameters['feedback_data'] = 'example_feedback'
        
        elif action_type == ActionType.EXPLORE_TOPIC:
            parameters['topic'] = random.choice(['logic', 'reasoning', 'knowledge', 'inference'])
        
        return parameters
    
    def update(self, state: Dict[str, Any], action: Action, reward: float, 
               next_state: Dict[str, Any], done: bool):
        """Update the agent's policy based on the experience"""
        
        # Store experience
        self.experience_replay.push(state, asdict(action), reward, next_state, done)
        
        # Update based on algorithm
        if self.config.algorithm == "q_learning":
            self._update_q_learning(state, action, reward, next_state, done)
        elif self.config.algorithm == "dqn":
            self._update_dqn()
        elif self.config.algorithm == "policy_gradient":
            self._update_policy_gradient(state, action, reward)
        
        # Update statistics
        self.action_statistics[action.action_type.value] += 1
        self.total_steps += 1
        
        # Decay epsilon
        if self.epsilon > self.config.epsilon_min:
            self.epsilon *= self.config.epsilon_decay
    
    def _update_q_learning(self, state: Dict[str, Any], action: Action, reward: float,
                          next_state: Dict[str, Any], done: bool):
        """Update Q-table using Q-learning"""
        state_str = self.state_encoder.encode_state(state)
        next_state_str = self.state_encoder.encode_state(next_state)
        action_str = action.action_type.value
        
        self.q_table.update_q_value(state_str, action_str, reward, next_state_str, done)
    
    def _update_dqn(self):
        """Update Deep Q-Network (simplified)"""
        # In a full implementation, this would train a neural network
        # For now, use experience replay with Q-learning
        if len(self.experience_replay) < self.config.batch_size:
            return
        
        batch = self.experience_replay.sample(self.config.batch_size)
        for experience in batch:
            state = experience['state']
            action_dict = experience['action']
            reward = experience['reward']
            next_state = experience['next_state']
            done = experience['done']
            
            # Reconstruct action
            action = Action(
                action_type=ActionType(action_dict['action_type']),
                parameters=action_dict['parameters'],
                timestamp=datetime.fromisoformat(action_dict['timestamp'])
            )
            
            self._update_q_learning(state, action, reward, next_state, done)
    
    def _update_policy_gradient(self, state: Dict[str, Any], action: Action, reward: float):
        """Update policy using policy gradient"""
        state_vector = self.state_encoder.encode_state_vector(state)
        action_index = list(ActionType).index(action.action_type)
        
        self.policy_network.store_transition(state_vector, action_index, reward)
    
    def end_episode(self, episode_reward: float, episode_length: int):
        """Called at the end of each episode"""
        self.current_episode += 1
        self.episode_rewards.append(episode_reward)
        self.episode_lengths.append(episode_length)
        
        # Update policy gradient if using that algorithm
        if self.config.algorithm == "policy_gradient":
            self.policy_network.update_policy(self.config.discount_factor)
        
        # Log episode statistics
        if self.current_episode % 10 == 0:
            avg_reward = np.mean(self.episode_rewards[-10:])
            avg_length = np.mean(self.episode_lengths[-10:])
            self.logger.info(f"Episode {self.current_episode}: Avg Reward: {avg_reward:.2f}, Avg Length: {avg_length:.1f}, Epsilon: {self.epsilon:.3f}")
        
        # Save model periodically
        if self.current_episode % self.config.save_frequency == 0:
            self.save_model(f"rl_agent_episode_{self.current_episode}.pkl")
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Get comprehensive performance metrics"""
        if not self.episode_rewards:
            return {}
        
        recent_rewards = self.episode_rewards[-100:] if len(self.episode_rewards) >= 100 else self.episode_rewards
        
        return {
            'total_episodes': self.current_episode,
            'total_steps': self.total_steps,
            'average_reward': np.mean(self.episode_rewards),
            'recent_average_reward': np.mean(recent_rewards),
            'best_reward': max(self.episode_rewards),
            'reward_std': np.std(self.episode_rewards),
            'average_episode_length': np.mean(self.episode_lengths),
            'current_epsilon': self.epsilon,
            'action_distribution': dict(self.action_statistics),
            'learning_progress': self._calculate_learning_progress(),
            'q_table_size': len(self.q_table.q_table) if hasattr(self.q_table, 'q_table') else 0
        }
    
    def _calculate_learning_progress(self) -> Dict[str, float]:
        """Calculate learning progress indicators"""
        if len(self.episode_rewards) < 20:
            return {'trend': 0.0, 'stability': 0.0, 'efficiency': 0.0}
        
        # Trend: improvement over time
        early_rewards = np.mean(self.episode_rewards[:10])
        recent_rewards = np.mean(self.episode_rewards[-10:])
        trend = (recent_rewards - early_rewards) / (abs(early_rewards) + 1e-8)
        
        # Stability: consistency of recent performance
        stability = 1.0 / (1.0 + np.std(self.episode_rewards[-20:]))
        
        # Efficiency: reward per step
        efficiency = np.mean(self.episode_rewards) / (np.mean(self.episode_lengths) + 1e-8)
        
        return {
            'trend': trend,
            'stability': stability,
            'efficiency': efficiency
        }
    
    def get_policy_summary(self) -> Dict[str, Any]:
        """Get summary of the learned policy"""
        if self.config.algorithm == "q_learning":
            # Analyze Q-table
            state_action_counts = {}
            for state, actions in self.q_table.q_table.items():
                best_action = max(actions, key=actions.get) if actions else None
                state_action_counts[state] = {
                    'best_action': best_action,
                    'q_value': actions.get(best_action, 0.0) if best_action else 0.0,
                    'action_count': len(actions)
                }
            
            return {
                'algorithm': 'q_learning',
                'states_learned': len(self.q_table.q_table),
                'total_state_action_pairs': sum(len(actions) for actions in self.q_table.q_table.values()),
                'sample_policies': dict(list(state_action_counts.items())[:5])
            }
        
        elif self.config.algorithm == "policy_gradient":
            return {
                'algorithm': 'policy_gradient',
                'network_weights_shape': self.policy_network.weights.shape,
                'network_bias_shape': self.policy_network.bias.shape,
                'weight_statistics': {
                    'mean': float(np.mean(self.policy_network.weights)),
                    'std': float(np.std(self.policy_network.weights))
                }
            }
        
        return {'algorithm': self.config.algorithm}
    
    def save_model(self, filepath: str):
        """Save the trained model"""
        model_data = {
            'config': asdict(self.config),
            'current_episode': self.current_episode,
            'total_steps': self.total_steps,
            'epsilon': self.epsilon,
            'episode_rewards': self.episode_rewards,
            'episode_lengths': self.episode_lengths,
            'action_statistics': dict(self.action_statistics),
            'q_table': dict(self.q_table.q_table) if hasattr(self.q_table, 'q_table') else {},
            'policy_weights': self.policy_network.weights.tolist() if hasattr(self.policy_network, 'weights') else [],
            'policy_bias': self.policy_network.bias.tolist() if hasattr(self.policy_network, 'bias') else []
        }
        
        try:
            with open(filepath, 'wb') as f:
                pickle.dump(model_data, f)
            self.logger.info(f"Model saved to {filepath}")
        except Exception as e:
            self.logger.error(f"Failed to save model: {e}")
    
    def load_model(self, filepath: str):
        """Load a trained model"""
        try:
            with open(filepath, 'rb') as f:
                model_data = pickle.load(f)
            
            # Restore state
            self.current_episode = model_data.get('current_episode', 0)
            self.total_steps = model_data.get('total_steps', 0)
            self.epsilon = model_data.get('epsilon', self.config.epsilon)
            self.episode_rewards = model_data.get('episode_rewards', [])
            self.episode_lengths = model_data.get('episode_lengths', [])
            self.action_statistics = defaultdict(int, model_data.get('action_statistics', {}))
            
            # Restore Q-table
            if 'q_table' in model_data:
                for state, actions in model_data['q_table'].items():
                    for action, q_value in actions.items():
                        self.q_table.q_table[state][action] = q_value
            
            # Restore policy network
            if 'policy_weights' in model_data and model_data['policy_weights']:
                self.policy_network.weights = np.array(model_data['policy_weights'])
            if 'policy_bias' in model_data and model_data['policy_bias']:
                self.policy_network.bias = np.array(model_data['policy_bias'])
            
            self.logger.info(f"Model loaded from {filepath}")
            
        except Exception as e:
            self.logger.error(f"Failed to load model: {e}")

class StateEncoder:
    """Encodes environment states into representations suitable for RL algorithms"""
    
    def __init__(self):
        self.feature_extractors = {
            'episode': lambda s: s.get('episode', 0),
            'step': lambda s: s.get('step', 0),
            'scenario_difficulty': lambda s: s.get('scenario_difficulty', 0),
            'facts_count': lambda s: s.get('agent_facts_count', 0),
            'rules_count': lambda s: s.get('agent_rules_count', 0),
            'total_reward': lambda s: s.get('total_reward', 0.0),
            'facts_learned': lambda s: s.get('scenario_progress', {}).get('facts_learned', 0),
            'rules_learned': lambda s: s.get('scenario_progress', {}).get('rules_learned', 0),
            'queries_attempted': lambda s: s.get('scenario_progress', {}).get('queries_attempted', 0),
            'correct_inferences': lambda s: s.get('scenario_progress', {}).get('correct_inferences', 0)
        }
    
    def encode_state(self, state: Dict[str, Any]) -> str:
        """Encode state as string for tabular methods"""
        # Create a simplified state representation
        features = []
        features.append(f"diff_{state.get('scenario_difficulty', 0)}")
        features.append(f"facts_{min(state.get('agent_facts_count', 0), 10)}")  # Discretize
        features.append(f"rules_{min(state.get('agent_rules_count', 0), 5)}")
        
        progress = state.get('scenario_progress', {})
        features.append(f"learned_{progress.get('facts_learned', 0)}")
        features.append(f"correct_{progress.get('correct_inferences', 0)}")
        
        return "_".join(features)
    
    def encode_state_vector(self, state: Dict[str, Any]) -> np.ndarray:
        """Encode state as vector for neural network methods"""
        features = []
        
        for feature_name, extractor in self.feature_extractors.items():
            try:
                value = extractor(state)
                features.append(float(value))
            except:
                features.append(0.0)
        
        # Normalize features
        features = np.array(features)
        
        # Add some derived features
        progress = state.get('scenario_progress', {})
        facts_learned = progress.get('facts_learned', 0)
        total_facts = max(state.get('agent_facts_count', 1), 1)
        learning_ratio = facts_learned / total_facts
        features = np.append(features, learning_ratio)
        
        # Pad to fixed size
        target_size = 20
        if len(features) < target_size:
            features = np.pad(features, (0, target_size - len(features)), 'constant')
        elif len(features) > target_size:
            features = features[:target_size]
        
        return features

