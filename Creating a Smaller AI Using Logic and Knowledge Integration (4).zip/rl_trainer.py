"""
Reinforcement Learning Training System for Child AI
Implements training loops, evaluation metrics, and performance monitoring
"""

import numpy as np
import matplotlib.pyplot as plt
import json
import time
import logging
from typing import Dict, List, Tuple, Any, Optional, Callable
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
import threading
import queue
from pathlib import Path

from rl_environment import KnowledgeLearningEnvironment, Action, ActionType
from rl_agent import RLAgent, RLConfig
from logic_engine import LogicEngine
from knowledge_integration import KnowledgeIntegrator

@dataclass
class TrainingConfig:
    """Configuration for RL training"""
    max_episodes: int = 1000
    max_steps_per_episode: int = 100
    evaluation_frequency: int = 50
    save_frequency: int = 100
    log_frequency: int = 10
    early_stopping_patience: int = 100
    target_performance: float = 0.8
    enable_curriculum_learning: bool = True
    enable_adaptive_learning_rate: bool = True
    enable_performance_tracking: bool = True
    training_data_dir: str = "training_data"
    model_save_dir: str = "models"

class PerformanceMetrics:
    """Tracks and analyzes performance metrics during training"""
    
    def __init__(self):
        self.episode_rewards = []
        self.episode_lengths = []
        self.success_rates = []
        self.learning_efficiency = []
        self.exploration_rates = []
        self.convergence_metrics = []
        self.scenario_performance = {}
        
    def update(self, episode: int, reward: float, length: int, success: bool, 
               exploration_rate: float, agent_metrics: Dict[str, Any]):
        """Update metrics with new episode data"""
        self.episode_rewards.append(reward)
        self.episode_lengths.append(length)
        self.success_rates.append(1.0 if success else 0.0)
        self.exploration_rates.append(exploration_rate)
        
        # Calculate learning efficiency (reward per step)
        efficiency = reward / length if length > 0 else 0.0
        self.learning_efficiency.append(efficiency)
        
        # Calculate convergence metric (stability of recent performance)
        if len(self.episode_rewards) >= 20:
            recent_rewards = self.episode_rewards[-20:]
            convergence = 1.0 / (1.0 + np.std(recent_rewards))
            self.convergence_metrics.append(convergence)
        else:
            self.convergence_metrics.append(0.0)
    
    def get_current_performance(self, window_size: int = 50) -> Dict[str, float]:
        """Get current performance metrics over a sliding window"""
        if not self.episode_rewards:
            return {}
        
        window_size = min(window_size, len(self.episode_rewards))
        recent_rewards = self.episode_rewards[-window_size:]
        recent_lengths = self.episode_lengths[-window_size:]
        recent_success = self.success_rates[-window_size:]
        recent_efficiency = self.learning_efficiency[-window_size:]
        
        return {
            'average_reward': np.mean(recent_rewards),
            'reward_std': np.std(recent_rewards),
            'average_length': np.mean(recent_lengths),
            'success_rate': np.mean(recent_success),
            'learning_efficiency': np.mean(recent_efficiency),
            'convergence': self.convergence_metrics[-1] if self.convergence_metrics else 0.0,
            'total_episodes': len(self.episode_rewards)
        }
    
    def analyze_learning_curve(self) -> Dict[str, Any]:
        """Analyze the learning curve and provide insights"""
        if len(self.episode_rewards) < 10:
            return {'status': 'insufficient_data'}
        
        # Divide into phases for analysis
        total_episodes = len(self.episode_rewards)
        phase_size = max(10, total_episodes // 4)
        
        phases = []
        for i in range(0, total_episodes, phase_size):
            phase_rewards = self.episode_rewards[i:i+phase_size]
            phases.append({
                'start_episode': i,
                'end_episode': min(i+phase_size-1, total_episodes-1),
                'average_reward': np.mean(phase_rewards),
                'reward_trend': np.polyfit(range(len(phase_rewards)), phase_rewards, 1)[0]
            })
        
        # Overall trend analysis
        overall_trend = np.polyfit(range(total_episodes), self.episode_rewards, 1)[0]
        
        # Stability analysis
        recent_stability = np.std(self.episode_rewards[-20:]) if len(self.episode_rewards) >= 20 else float('inf')
        
        return {
            'status': 'analyzed',
            'overall_trend': overall_trend,
            'recent_stability': recent_stability,
            'phases': phases,
            'learning_status': self._classify_learning_status(overall_trend, recent_stability)
        }
    
    def _classify_learning_status(self, trend: float, stability: float) -> str:
        """Classify the current learning status"""
        if trend > 0.1 and stability < 1.0:
            return 'learning_well'
        elif trend > 0.05:
            return 'learning_slowly'
        elif abs(trend) < 0.05 and stability < 0.5:
            return 'converged'
        elif trend < -0.05:
            return 'degrading'
        else:
            return 'unstable'

class RLTrainer:
    """
    Comprehensive training system for the RL agent
    Handles training loops, evaluation, and performance monitoring
    """
    
    def __init__(self, 
                 agent: RLAgent,
                 environment: KnowledgeLearningEnvironment,
                 config: Optional[TrainingConfig] = None):
        """Initialize the trainer"""
        self.agent = agent
        self.environment = environment
        self.config = config or TrainingConfig()
        self.logger = logging.getLogger(__name__)
        
        # Training state
        self.current_episode = 0
        self.total_steps = 0
        self.training_start_time = None
        self.is_training = False
        self.should_stop = False
        
        # Performance tracking
        self.metrics = PerformanceMetrics()
        self.evaluation_results = []
        self.best_performance = 0.0
        self.episodes_without_improvement = 0
        
        # Create directories
        Path(self.config.training_data_dir).mkdir(exist_ok=True)
        Path(self.config.model_save_dir).mkdir(exist_ok=True)
        
        self.logger.info("RL Trainer initialized")
    
    def train(self, episodes: Optional[int] = None) -> Dict[str, Any]:
        """Main training loop"""
        max_episodes = episodes or self.config.max_episodes
        self.training_start_time = datetime.utcnow()
        self.is_training = True
        self.should_stop = False
        
        self.logger.info(f"Starting training for {max_episodes} episodes")
        
        try:
            for episode in range(max_episodes):
                if self.should_stop:
                    self.logger.info("Training stopped by user request")
                    break
                
                self.current_episode = episode + 1
                episode_result = self._run_episode()
                
                # Update metrics
                self.metrics.update(
                    episode=self.current_episode,
                    reward=episode_result['total_reward'],
                    length=episode_result['steps'],
                    success=episode_result['success'],
                    exploration_rate=self.agent.epsilon,
                    agent_metrics=self.agent.get_performance_metrics()
                )
                
                # Update agent
                self.agent.end_episode(episode_result['total_reward'], episode_result['steps'])
                
                # Periodic evaluation
                if self.current_episode % self.config.evaluation_frequency == 0:
                    eval_result = self.evaluate()
                    self.evaluation_results.append(eval_result)
                    
                    # Check for improvement
                    current_performance = eval_result['average_performance']
                    if current_performance > self.best_performance:
                        self.best_performance = current_performance
                        self.episodes_without_improvement = 0
                        self._save_best_model()
                    else:
                        self.episodes_without_improvement += self.config.evaluation_frequency
                
                # Periodic logging
                if self.current_episode % self.config.log_frequency == 0:
                    self._log_progress()
                
                # Periodic saving
                if self.current_episode % self.config.save_frequency == 0:
                    self._save_checkpoint()
                
                # Early stopping check
                if self._should_early_stop():
                    self.logger.info(f"Early stopping at episode {self.current_episode}")
                    break
                
                # Adaptive learning rate
                if self.config.enable_adaptive_learning_rate:
                    self._adjust_learning_rate()
        
        except KeyboardInterrupt:
            self.logger.info("Training interrupted by user")
        except Exception as e:
            self.logger.error(f"Training error: {e}")
            raise
        finally:
            self.is_training = False
        
        # Final evaluation and summary
        final_eval = self.evaluate()
        training_summary = self._generate_training_summary()
        
        self.logger.info("Training completed")
        return training_summary
    
    def _run_episode(self) -> Dict[str, Any]:
        """Run a single training episode"""
        state = self.environment.reset()
        total_reward = 0.0
        steps = 0
        success = False
        
        for step in range(self.config.max_steps_per_episode):
            # Select action
            available_actions = self.environment.get_action_space()
            action = self.agent.select_action(state, available_actions)
            
            # Execute action
            observation = self.environment.step(action)
            
            # Update agent
            self.agent.update(
                state=state,
                action=action,
                reward=observation.reward,
                next_state=observation.state,
                done=observation.done
            )
            
            # Update episode state
            state = observation.state
            total_reward += observation.reward
            steps += 1
            self.total_steps += 1
            
            # Check if episode is done
            if observation.done:
                success = self._evaluate_episode_success(observation.info)
                break
        
        return {
            'total_reward': total_reward,
            'steps': steps,
            'success': success,
            'final_state': state
        }
    
    def _evaluate_episode_success(self, episode_info: Dict[str, Any]) -> bool:
        """Evaluate if the episode was successful"""
        # Define success criteria based on the scenario
        performance_metrics = episode_info.get('performance_metrics', {})
        
        # Success if accuracy is high and efficiency is reasonable
        accuracy = performance_metrics.get('accuracy', 0.0)
        efficiency = performance_metrics.get('efficiency', 0.0)
        
        return accuracy > 0.7 and efficiency > 0.1
    
    def evaluate(self, num_episodes: int = 10) -> Dict[str, Any]:
        """Evaluate the current agent performance"""
        self.logger.info(f"Evaluating agent over {num_episodes} episodes")
        
        # Temporarily disable exploration for evaluation
        original_epsilon = self.agent.epsilon
        self.agent.epsilon = 0.0  # Pure exploitation
        
        evaluation_rewards = []
        evaluation_successes = []
        evaluation_lengths = []
        
        try:
            for eval_episode in range(num_episodes):
                state = self.environment.reset()
                total_reward = 0.0
                steps = 0
                
                for step in range(self.config.max_steps_per_episode):
                    available_actions = self.environment.get_action_space()
                    action = self.agent.select_action(state, available_actions)
                    observation = self.environment.step(action)
                    
                    state = observation.state
                    total_reward += observation.reward
                    steps += 1
                    
                    if observation.done:
                        success = self._evaluate_episode_success(observation.info)
                        evaluation_successes.append(success)
                        break
                
                evaluation_rewards.append(total_reward)
                evaluation_lengths.append(steps)
        
        finally:
            # Restore original epsilon
            self.agent.epsilon = original_epsilon
        
        # Calculate evaluation metrics
        eval_result = {
            'timestamp': datetime.utcnow().isoformat(),
            'episode': self.current_episode,
            'average_reward': np.mean(evaluation_rewards),
            'reward_std': np.std(evaluation_rewards),
            'success_rate': np.mean(evaluation_successes),
            'average_length': np.mean(evaluation_lengths),
            'average_performance': np.mean(evaluation_rewards) * np.mean(evaluation_successes),
            'individual_rewards': evaluation_rewards,
            'individual_successes': evaluation_successes
        }
        
        self.logger.info(f"Evaluation complete: Avg Reward: {eval_result['average_reward']:.2f}, Success Rate: {eval_result['success_rate']:.2f}")
        
        return eval_result
    
    def _should_early_stop(self) -> bool:
        """Check if training should stop early"""
        # Stop if target performance is reached
        if self.best_performance >= self.config.target_performance:
            return True
        
        # Stop if no improvement for too long
        if self.episodes_without_improvement >= self.config.early_stopping_patience:
            return True
        
        return False
    
    def _adjust_learning_rate(self):
        """Adjust learning rate based on performance"""
        if len(self.metrics.episode_rewards) < 50:
            return
        
        # Analyze recent performance trend
        recent_rewards = self.metrics.episode_rewards[-20:]
        trend = np.polyfit(range(len(recent_rewards)), recent_rewards, 1)[0]
        
        # Adjust learning rate based on trend
        if trend < -0.1:  # Performance declining
            self.agent.config.learning_rate *= 0.9  # Reduce learning rate
        elif trend > 0.1:  # Performance improving
            self.agent.config.learning_rate *= 1.05  # Slightly increase learning rate
        
        # Keep learning rate within bounds
        self.agent.config.learning_rate = np.clip(self.agent.config.learning_rate, 0.001, 0.5)
    
    def _log_progress(self):
        """Log training progress"""
        current_metrics = self.metrics.get_current_performance()
        
        self.logger.info(f"Episode {self.current_episode}:")
        self.logger.info(f"  Avg Reward: {current_metrics.get('average_reward', 0):.2f}")
        self.logger.info(f"  Success Rate: {current_metrics.get('success_rate', 0):.2f}")
        self.logger.info(f"  Efficiency: {current_metrics.get('learning_efficiency', 0):.3f}")
        self.logger.info(f"  Epsilon: {self.agent.epsilon:.3f}")
        self.logger.info(f"  Best Performance: {self.best_performance:.2f}")
    
    def _save_checkpoint(self):
        """Save training checkpoint"""
        checkpoint_path = Path(self.config.model_save_dir) / f"checkpoint_episode_{self.current_episode}.pkl"
        self.agent.save_model(str(checkpoint_path))
        
        # Save training state
        training_state = {
            'current_episode': self.current_episode,
            'total_steps': self.total_steps,
            'best_performance': self.best_performance,
            'episodes_without_improvement': self.episodes_without_improvement,
            'metrics': {
                'episode_rewards': self.metrics.episode_rewards,
                'episode_lengths': self.metrics.episode_lengths,
                'success_rates': self.metrics.success_rates
            },
            'evaluation_results': self.evaluation_results
        }
        
        state_path = Path(self.config.training_data_dir) / f"training_state_{self.current_episode}.json"
        with open(state_path, 'w') as f:
            json.dump(training_state, f, indent=2)
    
    def _save_best_model(self):
        """Save the best performing model"""
        best_model_path = Path(self.config.model_save_dir) / "best_model.pkl"
        self.agent.save_model(str(best_model_path))
        self.logger.info(f"New best model saved with performance: {self.best_performance:.2f}")
    
    def _generate_training_summary(self) -> Dict[str, Any]:
        """Generate comprehensive training summary"""
        training_duration = datetime.utcnow() - self.training_start_time if self.training_start_time else timedelta(0)
        
        learning_analysis = self.metrics.analyze_learning_curve()
        current_performance = self.metrics.get_current_performance()
        agent_metrics = self.agent.get_performance_metrics()
        
        summary = {
            'training_info': {
                'total_episodes': self.current_episode,
                'total_steps': self.total_steps,
                'training_duration': str(training_duration),
                'episodes_per_hour': self.current_episode / (training_duration.total_seconds() / 3600) if training_duration.total_seconds() > 0 else 0
            },
            'performance': current_performance,
            'best_performance': self.best_performance,
            'learning_analysis': learning_analysis,
            'agent_metrics': agent_metrics,
            'evaluation_history': self.evaluation_results[-10:],  # Last 10 evaluations
            'final_policy_summary': self.agent.get_policy_summary()
        }
        
        # Save summary
        summary_path = Path(self.config.training_data_dir) / f"training_summary_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
        with open(summary_path, 'w') as f:
            json.dump(summary, f, indent=2, default=str)
        
        return summary
    
    def stop_training(self):
        """Stop training gracefully"""
        self.should_stop = True
        self.logger.info("Training stop requested")
    
    def get_training_status(self) -> Dict[str, Any]:
        """Get current training status"""
        return {
            'is_training': self.is_training,
            'current_episode': self.current_episode,
            'total_steps': self.total_steps,
            'best_performance': self.best_performance,
            'current_metrics': self.metrics.get_current_performance(),
            'agent_epsilon': self.agent.epsilon,
            'episodes_without_improvement': self.episodes_without_improvement
        }
    
    def plot_training_progress(self, save_path: Optional[str] = None) -> str:
        """Plot training progress and save visualization"""
        if not self.metrics.episode_rewards:
            return "No training data available for plotting"
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle('RL Training Progress', fontsize=16)
        
        # Episode rewards
        axes[0, 0].plot(self.metrics.episode_rewards)
        axes[0, 0].set_title('Episode Rewards')
        axes[0, 0].set_xlabel('Episode')
        axes[0, 0].set_ylabel('Reward')
        axes[0, 0].grid(True)
        
        # Success rate (moving average)
        if len(self.metrics.success_rates) > 10:
            window_size = min(50, len(self.metrics.success_rates) // 10)
            success_ma = np.convolve(self.metrics.success_rates, np.ones(window_size)/window_size, mode='valid')
            axes[0, 1].plot(success_ma)
            axes[0, 1].set_title(f'Success Rate (MA-{window_size})')
            axes[0, 1].set_xlabel('Episode')
            axes[0, 1].set_ylabel('Success Rate')
            axes[0, 1].grid(True)
        
        # Learning efficiency
        axes[1, 0].plot(self.metrics.learning_efficiency)
        axes[1, 0].set_title('Learning Efficiency (Reward/Step)')
        axes[1, 0].set_xlabel('Episode')
        axes[1, 0].set_ylabel('Efficiency')
        axes[1, 0].grid(True)
        
        # Exploration rate
        axes[1, 1].plot(self.metrics.exploration_rates)
        axes[1, 1].set_title('Exploration Rate (Epsilon)')
        axes[1, 1].set_xlabel('Episode')
        axes[1, 1].set_ylabel('Epsilon')
        axes[1, 1].grid(True)
        
        plt.tight_layout()
        
        # Save plot
        if save_path is None:
            save_path = Path(self.config.training_data_dir) / f"training_progress_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.png"
        
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return str(save_path)

class RewardFunction:
    """
    Customizable reward function for different learning objectives
    """
    
    def __init__(self, config: Optional[Dict[str, float]] = None):
        """Initialize reward function with weights"""
        self.config = config or {
            'correct_inference_weight': 3.0,
            'correct_fact_weight': 1.0,
            'correct_rule_weight': 2.0,
            'exploration_weight': 0.1,
            'efficiency_weight': 0.5,
            'learning_progress_weight': 0.3,
            'penalty_incorrect': -0.5,
            'penalty_inefficient': -0.1
        }
    
    def calculate_reward(self, action: Action, environment_state: Dict[str, Any], 
                        action_result: Dict[str, Any]) -> float:
        """Calculate reward for an action"""
        base_reward = 0.0
        
        # Reward based on action type and correctness
        if action.action_type == ActionType.MAKE_INFERENCE:
            if action_result.get('correct', False):
                base_reward += self.config['correct_inference_weight']
            else:
                base_reward += self.config['penalty_incorrect']
        
        elif action.action_type == ActionType.ADD_FACT:
            if action_result.get('correct', False):
                base_reward += self.config['correct_fact_weight']
            else:
                base_reward += self.config['penalty_incorrect']
        
        elif action.action_type == ActionType.ADD_RULE:
            if action_result.get('correct', False):
                base_reward += self.config['correct_rule_weight']
            else:
                base_reward += self.config['penalty_incorrect']
        
        elif action.action_type == ActionType.EXPLORE_TOPIC:
            base_reward += self.config['exploration_weight']
        
        # Efficiency bonus/penalty
        steps_taken = environment_state.get('step', 0)
        if steps_taken > 0:
            efficiency = action_result.get('value', 0) / steps_taken
            if efficiency > 0.1:
                base_reward += self.config['efficiency_weight'] * efficiency
            else:
                base_reward += self.config['penalty_inefficient']
        
        # Learning progress bonus
        progress = environment_state.get('scenario_progress', {})
        learning_ratio = progress.get('facts_learned', 0) / max(progress.get('total_facts', 1), 1)
        base_reward += self.config['learning_progress_weight'] * learning_ratio
        
        return base_reward
    
    def update_weights(self, performance_feedback: Dict[str, float]):
        """Update reward weights based on performance feedback"""
        for key, adjustment in performance_feedback.items():
            if key in self.config:
                self.config[key] *= (1.0 + adjustment)
                # Keep weights within reasonable bounds
                self.config[key] = np.clip(self.config[key], 0.01, 10.0)

