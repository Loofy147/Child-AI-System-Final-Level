"""
Learning and Adaptation Module for Child AI
This module implements continuous learning mechanisms and performance evaluation.
"""

import json
import time
import sqlite3
import os
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
import requests
from openai import OpenAI


@dataclass
class LearningExample:
    """Represents a learning example."""
    input_data: str
    expected_output: str
    actual_output: str
    feedback: str
    confidence: float
    timestamp: datetime
    source: str


@dataclass
class PerformanceMetric:
    """Represents a performance metric."""
    metric_name: str
    value: float
    timestamp: datetime
    context: Dict[str, Any]


class LearningDatabase:
    """Manages the learning database for storing examples and metrics."""
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialize the learning database."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create learning examples table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_examples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                input_data TEXT NOT NULL,
                expected_output TEXT NOT NULL,
                actual_output TEXT NOT NULL,
                feedback TEXT NOT NULL,
                confidence REAL NOT NULL,
                timestamp TEXT NOT NULL,
                source TEXT NOT NULL
            )
        ''')
        
        # Create performance metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                metric_name TEXT NOT NULL,
                value REAL NOT NULL,
                timestamp TEXT NOT NULL,
                context TEXT NOT NULL
            )
        ''')
        
        # Create knowledge evolution table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge_evolution (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action_type TEXT NOT NULL,
                content TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                source TEXT NOT NULL,
                confidence REAL DEFAULT 1.0
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def store_learning_example(self, example: LearningExample):
        """Store a learning example."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO learning_examples 
            (input_data, expected_output, actual_output, feedback, confidence, timestamp, source)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            example.input_data,
            example.expected_output,
            example.actual_output,
            example.feedback,
            example.confidence,
            example.timestamp.isoformat(),
            example.source
        ))
        
        conn.commit()
        conn.close()
    
    def store_performance_metric(self, metric: PerformanceMetric):
        """Store a performance metric."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO performance_metrics (metric_name, value, timestamp, context)
            VALUES (?, ?, ?, ?)
        ''', (
            metric.metric_name,
            metric.value,
            metric.timestamp.isoformat(),
            json.dumps(metric.context)
        ))
        
        conn.commit()
        conn.close()
    
    def get_recent_examples(self, limit: int = 50) -> List[LearningExample]:
        """Get recent learning examples."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT input_data, expected_output, actual_output, feedback, confidence, timestamp, source
            FROM learning_examples
            ORDER BY timestamp DESC
            LIMIT ?
        ''', (limit,))
        
        examples = []
        for row in cursor.fetchall():
            examples.append(LearningExample(
                input_data=row[0],
                expected_output=row[1],
                actual_output=row[2],
                feedback=row[3],
                confidence=row[4],
                timestamp=datetime.fromisoformat(row[5]),
                source=row[6]
            ))
        
        conn.close()
        return examples
    
    def get_performance_history(self, metric_name: str, limit: int = 100) -> List[PerformanceMetric]:
        """Get performance history for a specific metric."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT metric_name, value, timestamp, context
            FROM performance_metrics
            WHERE metric_name = ?
            ORDER BY timestamp DESC
            LIMIT ?
        ''', (metric_name, limit))
        
        metrics = []
        for row in cursor.fetchall():
            metrics.append(PerformanceMetric(
                metric_name=row[0],
                value=row[1],
                timestamp=datetime.fromisoformat(row[2]),
                context=json.loads(row[3])
            ))
        
        conn.close()
        return metrics


class RuleInductionEngine:
    """Implements rule induction from examples."""
    
    def __init__(self):
        self.induced_rules: List[Tuple[str, str, float]] = []
    
    def induce_rules_from_examples(self, examples: List[LearningExample]) -> List[Tuple[str, str, float]]:
        """Induce logical rules from learning examples."""
        rules = []
        
        # Simple pattern-based rule induction
        for example in examples:
            if example.feedback.lower() in ['positive', 'correct', 'good']:
                # Try to extract patterns
                input_parts = example.input_data.split()
                output_parts = example.expected_output.split()
                
                # Look for simple patterns like "If X then Y"
                if len(input_parts) >= 2 and len(output_parts) >= 2:
                    # Create a simple rule
                    premise = ' '.join(input_parts[:2])
                    conclusion = ' '.join(output_parts[:2])
                    confidence = example.confidence
                    
                    rule = (premise, conclusion, confidence)
                    if rule not in rules:
                        rules.append(rule)
        
        self.induced_rules.extend(rules)
        return rules
    
    def get_induced_rules(self) -> List[Tuple[str, str, float]]:
        """Get all induced rules."""
        return self.induced_rules.copy()


class PerformanceEvaluator:
    """Evaluates the performance of the AI system."""
    
    def __init__(self, learning_db: LearningDatabase):
        self.learning_db = learning_db
        self.openai_client = None
        
        # Initialize OpenAI client if available
        try:
            self.openai_client = OpenAI()
        except Exception:
            print("OpenAI client not available for external evaluation")
    
    def evaluate_accuracy(self, examples: List[LearningExample]) -> float:
        """Evaluate accuracy based on feedback."""
        if not examples:
            return 0.0
        
        positive_feedback = sum(1 for ex in examples if ex.feedback.lower() in ['positive', 'correct', 'good'])
        return positive_feedback / len(examples)
    
    def evaluate_confidence_calibration(self, examples: List[LearningExample]) -> float:
        """Evaluate how well confidence scores match actual performance."""
        if not examples:
            return 0.0
        
        total_error = 0.0
        for example in examples:
            actual_correct = 1.0 if example.feedback.lower() in ['positive', 'correct', 'good'] else 0.0
            confidence_error = abs(example.confidence - actual_correct)
            total_error += confidence_error
        
        return 1.0 - (total_error / len(examples))  # Higher is better
    
    def evaluate_with_external_llm(self, query: str, ai_response: str) -> Dict[str, Any]:
        """Evaluate AI response using external LLM."""
        if not self.openai_client:
            return {'error': 'External LLM not available'}
        
        try:
            evaluation_prompt = f"""
            Please evaluate the following AI response for accuracy, relevance, and logical consistency.
            
            Query: {query}
            AI Response: {ai_response}
            
            Please provide:
            1. A score from 0-10 for accuracy
            2. A score from 0-10 for relevance
            3. A score from 0-10 for logical consistency
            4. Brief feedback on strengths and weaknesses
            
            Format your response as JSON with keys: accuracy_score, relevance_score, logic_score, feedback
            """
            
            response = self.openai_client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": evaluation_prompt}],
                temperature=0.1
            )
            
            evaluation_text = response.choices[0].message.content
            
            # Try to parse as JSON
            try:
                evaluation = json.loads(evaluation_text)
                return evaluation
            except json.JSONDecodeError:
                return {'feedback': evaluation_text, 'error': 'Could not parse as JSON'}
        
        except Exception as e:
            return {'error': f'External evaluation failed: {str(e)}'}
    
    def generate_performance_report(self) -> Dict[str, Any]:
        """Generate a comprehensive performance report."""
        recent_examples = self.learning_db.get_recent_examples(100)
        
        accuracy = self.evaluate_accuracy(recent_examples)
        confidence_calibration = self.evaluate_confidence_calibration(recent_examples)
        
        # Get performance trends
        accuracy_history = self.learning_db.get_performance_history('accuracy', 50)
        
        report = {
            'current_accuracy': accuracy,
            'confidence_calibration': confidence_calibration,
            'total_examples': len(recent_examples),
            'performance_trend': 'stable',  # Simplified
            'recommendations': []
        }
        
        # Add recommendations based on performance
        if accuracy < 0.7:
            report['recommendations'].append('Consider reviewing and improving knowledge base')
        if confidence_calibration < 0.6:
            report['recommendations'].append('Improve confidence estimation mechanisms')
        
        return report


class LearningModule:
    """Main learning and adaptation module."""
    
    def __init__(self, logic_engine, knowledge_integrator, db_path: str = None):
        self.logic_engine = logic_engine
        self.knowledge_integrator = knowledge_integrator
        
        # Initialize database
        if db_path is None:
            db_path = os.path.join(os.path.dirname(__file__), 'database', 'learning.db')
        
        # Ensure database directory exists
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        self.learning_db = LearningDatabase(db_path)
        self.rule_inductor = RuleInductionEngine()
        self.evaluator = PerformanceEvaluator(self.learning_db)
        
        self.learning_enabled = True
    
    def learn_from_interaction(self, input_data: str, expected_output: str, 
                             actual_output: str, feedback: str, source: str = 'user') -> Dict[str, Any]:
        """Learn from a user interaction."""
        if not self.learning_enabled:
            return {'message': 'Learning is disabled'}
        
        # Create learning example
        example = LearningExample(
            input_data=input_data,
            expected_output=expected_output,
            actual_output=actual_output,
            feedback=feedback,
            confidence=0.8,  # Default confidence
            timestamp=datetime.now(),
            source=source
        )
        
        # Store the example
        self.learning_db.store_learning_example(example)
        
        # If feedback is positive, try to extract knowledge
        if feedback.lower() in ['positive', 'correct', 'good']:
            # Extract facts from the interaction
            learning_text = f"{input_data}. {expected_output}."
            facts_count = self.knowledge_integrator.integrate_text(learning_text, f'learning_{source}')
            
            # Try to induce rules
            recent_examples = self.learning_db.get_recent_examples(20)
            new_rules = self.rule_inductor.induce_rules_from_examples([example])
            
            # Add induced rules to logic engine
            for premise, conclusion, confidence in new_rules:
                self.logic_engine.add_rule(premise, conclusion)
            
            return {
                'message': 'Learning successful',
                'facts_extracted': facts_count,
                'rules_induced': len(new_rules),
                'example_stored': True
            }
        else:
            return {
                'message': 'Negative feedback noted',
                'example_stored': True,
                'learning_action': 'none'
            }
    
    def evaluate_performance(self) -> Dict[str, Any]:
        """Evaluate current performance."""
        return self.evaluator.generate_performance_report()
    
    def get_learning_statistics(self) -> Dict[str, Any]:
        """Get learning statistics."""
        recent_examples = self.learning_db.get_recent_examples(100)
        
        positive_examples = sum(1 for ex in recent_examples if ex.feedback.lower() in ['positive', 'correct', 'good'])
        negative_examples = len(recent_examples) - positive_examples
        
        return {
            'total_examples': len(recent_examples),
            'positive_examples': positive_examples,
            'negative_examples': negative_examples,
            'induced_rules': len(self.rule_inductor.get_induced_rules()),
            'learning_enabled': self.learning_enabled
        }
    
    def continuous_learning_cycle(self):
        """Perform a continuous learning cycle."""
        # Get recent examples
        recent_examples = self.learning_db.get_recent_examples(50)
        
        if recent_examples:
            # Induce new rules
            new_rules = self.rule_inductor.induce_rules_from_examples(recent_examples)
            
            # Add rules to logic engine
            for premise, conclusion, confidence in new_rules:
                if confidence > 0.7:  # Only add high-confidence rules
                    self.logic_engine.add_rule(premise, conclusion)
            
            # Evaluate performance
            performance = self.evaluator.generate_performance_report()
            
            # Store performance metrics
            accuracy_metric = PerformanceMetric(
                metric_name='accuracy',
                value=performance['current_accuracy'],
                timestamp=datetime.now(),
                context={'cycle': 'continuous_learning'}
            )
            self.learning_db.store_performance_metric(accuracy_metric)
            
            return {
                'rules_added': len([r for r in new_rules if r[2] > 0.7]),
                'performance': performance,
                'examples_processed': len(recent_examples)
            }
        
        return {'message': 'No new examples to process'}
    
    def enable_learning(self):
        """Enable learning."""
        self.learning_enabled = True
    
    def disable_learning(self):
        """Disable learning."""
        self.learning_enabled = False


# Example usage and testing
if __name__ == "__main__":
    from logic_engine import LogicEngine
    from knowledge_integration import KnowledgeIntegrator
    
    # Create components
    engine = LogicEngine()
    integrator = KnowledgeIntegrator(engine)
    learning_module = LearningModule(engine, integrator)
    
    # Simulate learning interactions
    print("Testing learning module...")
    
    # Positive interaction
    result = learning_module.learn_from_interaction(
        input_data="What is Socrates?",
        expected_output="Socrates is a philosopher",
        actual_output="Socrates is a philosopher",
        feedback="correct"
    )
    print(f"Positive learning result: {result}")
    
    # Negative interaction
    result = learning_module.learn_from_interaction(
        input_data="What is Plato?",
        expected_output="Plato is a student",
        actual_output="Plato is a teacher",
        feedback="incorrect"
    )
    print(f"Negative learning result: {result}")
    
    # Get statistics
    stats = learning_module.get_learning_statistics()
    print(f"Learning statistics: {stats}")
    
    # Evaluate performance
    performance = learning_module.evaluate_performance()
    print(f"Performance evaluation: {performance}")
    
    # Run continuous learning cycle
    cycle_result = learning_module.continuous_learning_cycle()
    print(f"Continuous learning cycle: {cycle_result}")

