"""
Logic Engine for Child AI
This module implements the core mathematical logic processing capabilities.
"""

import re
from typing import Dict, List, Set, Tuple, Union, Optional
from dataclasses import dataclass
from enum import Enum


class LogicOperator(Enum):
    """Enumeration of logical operators."""
    NOT = "¬"
    AND = "∧"
    OR = "∨"
    IMPLIES = "→"
    IFF = "↔"
    FORALL = "∀"
    EXISTS = "∃"


@dataclass
class Proposition:
    """Represents a propositional variable."""
    name: str
    value: Optional[bool] = None
    
    def __str__(self):
        return self.name


@dataclass
class Predicate:
    """Represents a predicate with arguments."""
    name: str
    arguments: List[str]
    
    def __str__(self):
        if self.arguments:
            return f"{self.name}({', '.join(self.arguments)})"
        return self.name


@dataclass
class LogicalStatement:
    """Represents a logical statement or formula."""
    operator: Optional[LogicOperator]
    operands: List[Union['LogicalStatement', Proposition, Predicate]]
    
    def __str__(self):
        if self.operator is None and len(self.operands) == 1:
            return str(self.operands[0])
        elif self.operator == LogicOperator.NOT:
            return f"¬{self.operands[0]}"
        elif self.operator in [LogicOperator.AND, LogicOperator.OR, LogicOperator.IMPLIES, LogicOperator.IFF]:
            op_symbol = self.operator.value
            return f"({self.operands[0]} {op_symbol} {self.operands[1]})"
        elif self.operator in [LogicOperator.FORALL, LogicOperator.EXISTS]:
            return f"{self.operator.value}{self.operands[0]} {self.operands[1]}"
        return str(self.operands)


class KnowledgeBase:
    """Stores and manages logical facts and rules."""
    
    def __init__(self):
        self.facts: Set[str] = set()
        self.rules: List[Tuple[LogicalStatement, LogicalStatement]] = []
        self.propositions: Dict[str, Proposition] = {}
        self.predicates: Dict[str, Predicate] = {}
    
    def add_fact(self, fact: str):
        """Add a fact to the knowledge base."""
        self.facts.add(fact)
    
    def add_rule(self, premise: LogicalStatement, conclusion: LogicalStatement):
        """Add a logical rule (premise → conclusion) to the knowledge base."""
        self.rules.append((premise, conclusion))
    
    def add_proposition(self, name: str, value: Optional[bool] = None):
        """Add a proposition to the knowledge base."""
        self.propositions[name] = Proposition(name, value)
    
    def add_predicate(self, name: str, arguments: List[str]):
        """Add a predicate to the knowledge base."""
        self.predicates[name] = Predicate(name, arguments)
    
    def get_facts(self) -> Set[str]:
        """Get all facts in the knowledge base."""
        return self.facts.copy()
    
    def get_rules(self) -> List[Tuple[LogicalStatement, LogicalStatement]]:
        """Get all rules in the knowledge base."""
        return self.rules.copy()


class InferenceEngine:
    """Implements logical inference mechanisms."""
    
    def __init__(self, knowledge_base: KnowledgeBase):
        self.kb = knowledge_base
        self.derived_facts: Set[str] = set()
    
    def modus_ponens(self, premise: str, rule_premise: str, rule_conclusion: str) -> Optional[str]:
        """Apply Modus Ponens inference rule."""
        if premise == rule_premise:
            return rule_conclusion
        return None
    
    def modus_tollens(self, negated_conclusion: str, rule_premise: str, rule_conclusion: str) -> Optional[str]:
        """Apply Modus Tollens inference rule."""
        if negated_conclusion == f"¬{rule_conclusion}":
            return f"¬{rule_premise}"
        return None
    
    def forward_chaining(self) -> Set[str]:
        """Perform forward chaining to derive new facts."""
        new_facts = set()
        changed = True
        
        while changed:
            changed = False
            current_facts = self.kb.get_facts() | self.derived_facts | new_facts
            
            for premise, conclusion in self.kb.get_rules():
                premise_str = str(premise)
                conclusion_str = str(conclusion)
                
                if premise_str in current_facts and conclusion_str not in current_facts:
                    new_facts.add(conclusion_str)
                    changed = True
        
        self.derived_facts.update(new_facts)
        return new_facts
    
    def backward_chaining(self, goal: str) -> bool:
        """Perform backward chaining to prove a goal."""
        # Check if goal is already a known fact
        if goal in self.kb.get_facts() or goal in self.derived_facts:
            return True
        
        # Check if goal can be derived from rules
        for premise, conclusion in self.kb.get_rules():
            if str(conclusion) == goal:
                # Try to prove the premise
                if self.backward_chaining(str(premise)):
                    self.derived_facts.add(goal)
                    return True
        
        return False
    
    def query(self, query: str) -> bool:
        """Query the knowledge base for a fact."""
        # First try forward chaining to derive new facts
        self.forward_chaining()
        
        # Then check if the query can be proven
        return self.backward_chaining(query)


class LogicEngine:
    """Main logic engine that coordinates all logical operations."""
    
    def __init__(self):
        self.knowledge_base = KnowledgeBase()
        self.inference_engine = InferenceEngine(self.knowledge_base)
    
    def add_fact(self, fact: str):
        """Add a fact to the knowledge base."""
        self.knowledge_base.add_fact(fact)
    
    def add_rule(self, premise_str: str, conclusion_str: str):
        """Add a rule to the knowledge base."""
        # For simplicity, we'll store rules as string pairs
        # In a more sophisticated implementation, we'd parse these into LogicalStatement objects
        premise = LogicalStatement(None, [Proposition(premise_str)])
        conclusion = LogicalStatement(None, [Proposition(conclusion_str)])
        self.knowledge_base.add_rule(premise, conclusion)
    
    def query(self, query: str) -> bool:
        """Query the knowledge base."""
        return self.inference_engine.query(query)
    
    def get_all_facts(self) -> Set[str]:
        """Get all facts (original and derived)."""
        return self.knowledge_base.get_facts() | self.inference_engine.derived_facts
    
    def explain_reasoning(self, query: str) -> List[str]:
        """Provide an explanation of how a conclusion was reached."""
        explanation = []
        
        if query in self.knowledge_base.get_facts():
            explanation.append(f"'{query}' is a known fact in the knowledge base.")
        elif query in self.inference_engine.derived_facts:
            explanation.append(f"'{query}' was derived through logical inference.")
            # In a more sophisticated implementation, we'd track the inference chain
            explanation.append("Inference chain: [This would show the step-by-step derivation]")
        else:
            explanation.append(f"'{query}' cannot be proven from the current knowledge base.")
        
        return explanation
    
    def get_statistics(self) -> Dict[str, int]:
        """Get statistics about the knowledge base."""
        return {
            "total_facts": len(self.knowledge_base.get_facts()),
            "derived_facts": len(self.inference_engine.derived_facts),
            "total_rules": len(self.knowledge_base.get_rules()),
            "propositions": len(self.knowledge_base.propositions),
            "predicates": len(self.knowledge_base.predicates)
        }


# Example usage and testing
if __name__ == "__main__":
    # Create a logic engine
    engine = LogicEngine()
    
    # Add some facts
    engine.add_fact("Human(Socrates)")
    engine.add_fact("Human(Plato)")
    
    # Add some rules
    engine.add_rule("Human(x)", "Mortal(x)")  # All humans are mortal
    engine.add_rule("Mortal(x)", "Finite(x)")  # All mortal beings are finite
    
    # Query the knowledge base
    print("Is Socrates mortal?", engine.query("Mortal(Socrates)"))
    print("Is Plato finite?", engine.query("Finite(Plato)"))
    
    # Get explanation
    print("\nExplanation for 'Mortal(Socrates)':")
    for line in engine.explain_reasoning("Mortal(Socrates)"):
        print(f"  {line}")
    
    # Get statistics
    print("\nKnowledge Base Statistics:")
    stats = engine.get_statistics()
    for key, value in stats.items():
        print(f"  {key}: {value}")

