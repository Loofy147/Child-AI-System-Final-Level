"""
Enhanced Child AI main application with industry best practices
Integrates security, monitoring, caching, error handling, and configuration management
"""

import os
import sys
import logging
from datetime import datetime
from flask import Flask, render_template, request, jsonify, g, send_from_directory
from flask_cors import CORS

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# Import configuration
from config import get_config, get_secrets

# Import core modules
from src.logic_engine import LogicEngine
from src.knowledge_integration import KnowledgeIntegrator
from src.learning_module import LearningModule

# Import best practices modules
from src.security import SecurityManager
from src.monitoring import StructuredLogger, MetricsCollector, HealthChecker, monitor_performance, log_requests
from src.caching import CacheManager, QueryOptimizer, cache_result
from src.error_handling import (
    error_recovery_manager, graceful_degradation, error_reporter,
    circuit_breaker, retry, safe_execute
)

# Import routes
from src.routes.ai_routes import ai_bp
from src.routes.learning_routes import learning_bp
from src.routes.auth_routes import auth_bp
from src.routes.monitoring_routes import monitoring_bp
from src.routes.user import user_bp

# Import database models
from src.models.user import db

def create_app(config_override=None):
    """Application factory with configuration"""
    
    # Get configuration
    config = get_config()
    secrets = get_secrets()
    
    # Override config if provided (for testing)
    if config_override:
        for section, values in config_override.items():
            if hasattr(config, section):
                section_obj = getattr(config, section)
                for key, value in values.items():
                    if hasattr(section_obj, key):
                        setattr(section_obj, key, value)
    
    # Create Flask app
    app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
    
    # Configure Flask app
    app.config['SECRET_KEY'] = secrets.get_secret('JWT_SECRET_KEY', 'default-secret-key')
    app.config['MAX_CONTENT_LENGTH'] = config.server.max_content_length_mb * 1024 * 1024
    
    # Database configuration
    app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{config.database.app_db_path}"
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Configure CORS
    if config.security.enable_cors:
        CORS(app, origins=config.security.cors_origins)
    
    # Initialize database
    db.init_app(app)
    
    # Initialize core AI components
    logic_engine = LogicEngine()
    knowledge_integrator = KnowledgeIntegrator()
    learning_module = LearningModule()
    
    # Initialize best practices components
    security_manager = SecurityManager(
        secret_key=secrets.get_secret('JWT_SECRET_KEY'),
        db_path=config.database.security_db_path
    )
    
    logger = StructuredLogger("child_ai", getattr(logging, config.logging.log_level.upper()))
    
    metrics_collector = None
    if config.monitoring.enable_metrics_collection:
        metrics_collector = MetricsCollector(config.database.metrics_db_path)
    
    cache_manager = CacheManager(
        redis_url=config.cache.redis_url,
        default_ttl=config.cache.default_ttl_seconds
    )
    
    query_optimizer = QueryOptimizer(
        config.database.app_db_path,
        config.database.connection_pool_size
    )
    
    health_checker = HealthChecker()
    
    # Make components available to routes
    app.logic_engine = logic_engine
    app.knowledge_integrator = knowledge_integrator
    app.learning_module = learning_module
    app.security_manager = security_manager
    app.logger = logger
    app.metrics_collector = metrics_collector
    app.cache_manager = cache_manager
    app.query_optimizer = query_optimizer
    app.health_checker = health_checker
    app.config_manager = config
    
    # Setup error recovery strategies
    setup_error_recovery(logger)
    
    # Setup graceful degradation
    setup_graceful_degradation(logger)
    
    # Setup request middleware
    setup_middleware(app, logger, metrics_collector)
    
    # Setup error handlers
    setup_error_handlers(app, logger)
    
    # Register blueprints based on feature flags
    register_blueprints(app, config)
    
    # Setup routes
    setup_routes(app)
    
    # Create database tables
    with app.app_context():
        db.create_all()
    
    return app

def setup_error_recovery(logger):
    """Setup error recovery strategies"""
    
    def ai_operation_recovery(error):
        """Recovery strategy for AI operation failures"""
        logger.warning(f"AI operation failed, using fallback: {error}")
        return {
            'result': False,
            'explanation': 'AI service temporarily unavailable. Please try again later.',
            'fallback': True
        }
    
    def database_recovery(error):
        """Recovery strategy for database errors"""
        logger.error(f"Database error, attempting recovery: {error}")
        # Could implement database reconnection logic here
        return None
    
    error_recovery_manager.register_recovery_strategy(Exception, ai_operation_recovery)
    error_recovery_manager.register_recovery_strategy(ConnectionError, database_recovery)

def setup_graceful_degradation(logger):
    """Setup graceful degradation fallbacks"""
    
    def knowledge_query_fallback(*args, **kwargs):
        """Fallback for knowledge queries"""
        logger.warning("Knowledge service degraded, using fallback")
        return {
            'result': False,
            'explanation': 'Knowledge service is temporarily unavailable.',
            'degraded': True
        }
    
    def learning_fallback(*args, **kwargs):
        """Fallback for learning operations"""
        logger.warning("Learning service degraded, using fallback")
        return {
            'success': False,
            'message': 'Learning service is temporarily unavailable.',
            'degraded': True
        }
    
    graceful_degradation.register_fallback('knowledge_query', knowledge_query_fallback)
    graceful_degradation.register_fallback('learning_operation', learning_fallback)

def setup_middleware(app, logger, metrics_collector):
    """Setup request middleware"""
    
    @app.before_request
    def before_request():
        """Setup request context"""
        g.start_time = datetime.utcnow()
        g.request_id = f"{int(g.start_time.timestamp())}-{id(request)}"
        g.metrics_collector = metrics_collector
        
        # Log request start
        logger.info(
            f"Request started: {request.method} {request.path}",
            request_id=g.request_id,
            method=request.method,
            path=request.path,
            user_agent=request.headers.get('User-Agent'),
            ip_address=request.remote_addr
        )
    
    @app.after_request
    def after_request(response):
        """Log request completion and collect metrics"""
        if hasattr(g, 'start_time'):
            duration = (datetime.utcnow() - g.start_time).total_seconds() * 1000
            
            # Log request completion
            logger.info(
                f"Request completed: {request.method} {request.path}",
                request_id=getattr(g, 'request_id', 'unknown'),
                status_code=response.status_code,
                duration=duration
            )
            
            # Record metrics
            if metrics_collector:
                user_id = getattr(request, 'current_user', {}).get('user_id')
                metrics_collector.record_request_metric(
                    request.endpoint,
                    request.method,
                    response.status_code,
                    duration,
                    user_id=user_id
                )
        
        return response

def setup_error_handlers(app, logger):
    """Setup global error handlers"""
    
    @app.errorhandler(404)
    def not_found(error):
        """Handle 404 errors"""
        return jsonify({
            'success': False,
            'error': 'Resource not found',
            'request_id': getattr(g, 'request_id', 'unknown')
        }), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors"""
        error_id = getattr(g, 'request_id', 'unknown')
        
        logger.error(
            f"Internal server error in request {error_id}: {str(error)}",
            request_id=error_id,
            error_type=type(error).__name__,
            endpoint=request.endpoint
        )
        
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'request_id': error_id
        }), 500
    
    @app.errorhandler(Exception)
    def handle_exception(error):
        """Global exception handler"""
        error_id = getattr(g, 'request_id', 'unknown')
        
        # Log error
        logger.error(
            f"Unhandled error in request {error_id}: {str(error)}",
            request_id=error_id,
            error_type=type(error).__name__,
            endpoint=request.endpoint
        )
        
        # Report error
        error_reporter.report_error(
            error,
            severity='high',
            context={
                'request_id': error_id,
                'endpoint': request.endpoint,
                'method': request.method,
                'path': request.path
            }
        )
        
        # Try error recovery
        try:
            recovery_result = error_recovery_manager.handle_error(error, {
                'request_id': error_id,
                'endpoint': request.endpoint
            })
            if recovery_result:
                return jsonify(recovery_result), 200
        except Exception:
            pass
        
        # Return generic error response
        return jsonify({
            'success': False,
            'error': 'Internal server error',
            'request_id': error_id
        }), 500

def register_blueprints(app, config):
    """Register blueprints based on feature flags"""
    
    # Core AI routes (always enabled)
    app.register_blueprint(ai_bp, url_prefix='/api/ai')
    
    # Learning routes (conditional)
    if config.features.enable_learning_api:
        app.register_blueprint(learning_bp, url_prefix='/api/learning')
    
    # Authentication routes (conditional)
    if config.features.enable_authentication:
        app.register_blueprint(auth_bp, url_prefix='/api/auth')
    
    # Monitoring routes (conditional)
    if config.features.enable_metrics_api:
        app.register_blueprint(monitoring_bp, url_prefix='/api/monitoring')
    
    # User routes (always enabled for compatibility)
    app.register_blueprint(user_bp, url_prefix='/api')

def setup_routes(app):
    """Setup additional routes"""
    
    @app.route('/api/health')
    @safe_execute(fallback_value={'status': 'unknown'})
    def health_check():
        """Simple health check endpoint"""
        health_status = app.health_checker.run_all_checks()
        status_code = 200 if health_status['overall_status'] == 'healthy' else 503
        return jsonify(health_status), status_code
    
    @app.route('/api/config')
    @cache_result('config', ttl=300)  # Cache for 5 minutes
    def get_config_info():
        """Get public configuration information"""
        config = app.config_manager
        return jsonify({
            'environment': config.environment,
            'features': config.features.__dict__,
            'version': '2.0.0-enhanced',
            'ai_capabilities': {
                'max_facts': config.ai.max_facts_in_memory,
                'max_rules': config.ai.max_rules_in_memory,
                'learning_enabled': config.ai.enable_learning,
                'explanation_enabled': config.ai.enable_explanation_generation
            }
        })
    
    @app.route('/api/stats')
    @monitor_performance('stats_generation')
    def get_system_stats():
        """Get system statistics"""
        stats = {
            'cache_stats': app.cache_manager.get_stats(),
            'error_stats': error_reporter.get_error_summary(hours=24),
            'recovery_stats': error_recovery_manager.get_error_statistics()
        }
        
        if app.metrics_collector:
            stats['metrics'] = app.metrics_collector.get_metrics_summary(hours=1)
        
        return jsonify({
            'success': True,
            'stats': stats,
            'timestamp': datetime.utcnow().isoformat()
        })
    
    # Static file serving (enhanced)
    @app.route('/', defaults={'path': ''})
    @app.route('/<path:path>')
    def serve_static(path):
        """Serve static files with enhanced error handling"""
        static_folder_path = app.static_folder
        if static_folder_path is None:
            return jsonify({'error': 'Static folder not configured'}), 404

        if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
            return send_from_directory(static_folder_path, path)
        else:
            index_path = os.path.join(static_folder_path, 'index.html')
            if os.path.exists(index_path):
                return send_from_directory(static_folder_path, 'index.html')
            else:
                return jsonify({'error': 'index.html not found'}), 404

# Create the application
app = create_app()

if __name__ == '__main__':
    config = get_config()
    
    # Setup logging
    logging.basicConfig(
        level=getattr(logging, config.logging.log_level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Start the application
    app.run(
        host=config.server.host,
        port=config.server.port,
        debug=config.server.debug,
        threaded=config.server.threaded
    )

