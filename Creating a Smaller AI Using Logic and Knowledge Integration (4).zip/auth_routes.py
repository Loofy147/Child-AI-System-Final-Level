"""
Authentication routes for Child AI system
Handles login, logout, registration, and token management
"""

from flask import Blueprint, request, jsonify, current_app
from src.security import SecurityManager, require_auth, rate_limit
import sqlite3
import secrets
from datetime import datetime

auth_bp = Blueprint('auth', __name__, url_prefix='/api/auth')

@auth_bp.route('/login', methods=['POST'])
@rate_limit(limit=10, window=300)  # 10 attempts per 5 minutes
def login():
    """Authenticate user and return JWT token"""
    try:
        data = request.get_json()
        
        if not data or not data.get('username') or not data.get('password'):
            return jsonify({
                'success': False,
                'error': 'Username and password required'
            }), 400
        
        username = data['username'].strip()
        password = data['password']
        
        # Authenticate user
        security_manager = current_app.security_manager
        auth_result = security_manager.authenticate_user(username, password)
        
        if auth_result['success']:
            # Generate token
            token = security_manager.generate_token(
                auth_result['user_id'],
                auth_result['username'],
                auth_result['role']
            )
            
            return jsonify({
                'success': True,
                'token': token,
                'user': {
                    'id': auth_result['user_id'],
                    'username': auth_result['username'],
                    'role': auth_result['role']
                },
                'expires_in': security_manager.token_expiry
            })
        else:
            return jsonify({
                'success': False,
                'error': auth_result['error']
            }), 401
            
    except Exception as e:
        current_app.logger.error(f"Login error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@auth_bp.route('/logout', methods=['POST'])
@require_auth
def logout():
    """Logout user and revoke token"""
    try:
        # Get token from Authorization header
        auth_header = request.headers.get('Authorization')
        token = auth_header.split(" ")[1] if auth_header else None
        
        if token:
            security_manager = current_app.security_manager
            security_manager.revoke_token(token)
        
        return jsonify({
            'success': True,
            'message': 'Logged out successfully'
        })
        
    except Exception as e:
        current_app.logger.error(f"Logout error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@auth_bp.route('/register', methods=['POST'])
@rate_limit(limit=5, window=300)  # 5 registrations per 5 minutes
def register():
    """Register new user"""
    try:
        data = request.get_json()
        
        if not data or not all(k in data for k in ['username', 'email', 'password']):
            return jsonify({
                'success': False,
                'error': 'Username, email, and password required'
            }), 400
        
        username = data['username'].strip()
        email = data['email'].strip()
        password = data['password']
        
        # Validate input
        if len(username) < 3:
            return jsonify({
                'success': False,
                'error': 'Username must be at least 3 characters'
            }), 400
        
        if len(password) < 6:
            return jsonify({
                'success': False,
                'error': 'Password must be at least 6 characters'
            }), 400
        
        if '@' not in email:
            return jsonify({
                'success': False,
                'error': 'Valid email address required'
            }), 400
        
        # Create user
        security_manager = current_app.security_manager
        conn = sqlite3.connect(security_manager.db_path)
        cursor = conn.cursor()
        
        # Check if user already exists
        cursor.execute('''
            SELECT id FROM users WHERE username = ? OR email = ?
        ''', (username, email))
        
        if cursor.fetchone():
            conn.close()
            return jsonify({
                'success': False,
                'error': 'Username or email already exists'
            }), 409
        
        # Create new user
        salt = secrets.token_hex(16)
        password_hash = security_manager.hash_password(password, salt)
        
        cursor.execute('''
            INSERT INTO users (username, email, password_hash, salt, role)
            VALUES (?, ?, ?, ?, ?)
        ''', (username, email, password_hash, salt, 'user'))
        
        user_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        # Generate token for new user
        token = security_manager.generate_token(user_id, username, 'user')
        
        return jsonify({
            'success': True,
            'message': 'User registered successfully',
            'token': token,
            'user': {
                'id': user_id,
                'username': username,
                'role': 'user'
            },
            'expires_in': security_manager.token_expiry
        }), 201
        
    except Exception as e:
        current_app.logger.error(f"Registration error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@auth_bp.route('/verify', methods=['GET'])
@require_auth
def verify_token():
    """Verify current token and return user info"""
    try:
        user_info = request.current_user
        
        return jsonify({
            'success': True,
            'valid': True,
            'user': {
                'id': user_info['user_id'],
                'username': user_info['username'],
                'role': user_info['role']
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Token verification error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@auth_bp.route('/refresh', methods=['POST'])
@require_auth
def refresh_token():
    """Refresh current token"""
    try:
        user_info = request.current_user
        security_manager = current_app.security_manager
        
        # Generate new token
        new_token = security_manager.generate_token(
            user_info['user_id'],
            user_info['username'],
            user_info['role']
        )
        
        # Revoke old token
        auth_header = request.headers.get('Authorization')
        old_token = auth_header.split(" ")[1] if auth_header else None
        if old_token:
            security_manager.revoke_token(old_token)
        
        return jsonify({
            'success': True,
            'token': new_token,
            'expires_in': security_manager.token_expiry
        })
        
    except Exception as e:
        current_app.logger.error(f"Token refresh error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@auth_bp.route('/profile', methods=['GET'])
@require_auth
def get_profile():
    """Get current user profile"""
    try:
        user_info = request.current_user
        security_manager = current_app.security_manager
        
        conn = sqlite3.connect(security_manager.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT username, email, role, created_at, last_login
            FROM users WHERE id = ?
        ''', (user_info['user_id'],))
        
        user_data = cursor.fetchone()
        conn.close()
        
        if user_data:
            return jsonify({
                'success': True,
                'profile': {
                    'id': user_info['user_id'],
                    'username': user_data[0],
                    'email': user_data[1],
                    'role': user_data[2],
                    'created_at': user_data[3],
                    'last_login': user_data[4]
                }
            })
        else:
            return jsonify({
                'success': False,
                'error': 'User not found'
            }), 404
            
    except Exception as e:
        current_app.logger.error(f"Profile retrieval error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

@auth_bp.route('/sessions', methods=['GET'])
@require_auth
def get_sessions():
    """Get active sessions for current user"""
    try:
        user_info = request.current_user
        security_manager = current_app.security_manager
        
        conn = sqlite3.connect(security_manager.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, created_at, expires_at, ip_address, user_agent, is_active
            FROM sessions 
            WHERE user_id = ? AND expires_at > ?
            ORDER BY created_at DESC
        ''', (user_info['user_id'], datetime.utcnow()))
        
        sessions = cursor.fetchall()
        conn.close()
        
        session_list = []
        for session in sessions:
            session_list.append({
                'id': session[0],
                'created_at': session[1],
                'expires_at': session[2],
                'ip_address': session[3],
                'user_agent': session[4],
                'is_active': bool(session[5])
            })
        
        return jsonify({
            'success': True,
            'sessions': session_list
        })
        
    except Exception as e:
        current_app.logger.error(f"Sessions retrieval error: {str(e)}")
        return jsonify({
            'success': False,
            'error': 'Internal server error'
        }), 500

