"""
Security module for Child AI system
Implements authentication, authorization, and security best practices
"""

import jwt
import hashlib
import secrets
import time
from datetime import datetime, timedelta
from functools import wraps
from flask import request, jsonify, current_app
import sqlite3
import os

class SecurityManager:
    """Manages authentication, authorization, and security policies"""
    
    def __init__(self, secret_key=None, db_path="src/database/security.db"):
        self.secret_key = secret_key or os.environ.get('JWT_SECRET_KEY', secrets.token_hex(32))
        self.db_path = db_path
        self.token_expiry = 3600  # 1 hour
        self.rate_limits = {}
        self.init_database()
    
    def init_database(self):
        """Initialize security database tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Users table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                salt TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP,
                is_active BOOLEAN DEFAULT 1
            )
        ''')
        
        # Sessions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                token_hash TEXT UNIQUE NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                ip_address TEXT,
                user_agent TEXT,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # API keys table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                key_hash TEXT UNIQUE NOT NULL,
                name TEXT NOT NULL,
                permissions TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_used TIMESTAMP,
                is_active BOOLEAN DEFAULT 1,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Rate limiting table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS rate_limits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                identifier TEXT NOT NULL,
                endpoint TEXT NOT NULL,
                requests INTEGER DEFAULT 0,
                window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(identifier, endpoint)
            )
        ''')
        
        conn.commit()
        conn.close()
        
        # Create default admin user if none exists
        self.create_default_admin()
    
    def create_default_admin(self):
        """Create default admin user for initial setup"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) FROM users WHERE role = 'admin'")
        admin_count = cursor.fetchone()[0]
        
        if admin_count == 0:
            # Create default admin
            salt = secrets.token_hex(16)
            password_hash = self.hash_password("admin123", salt)
            
            cursor.execute('''
                INSERT INTO users (username, email, password_hash, salt, role)
                VALUES (?, ?, ?, ?, ?)
            ''', ("admin", "admin@childai.local", password_hash, salt, "admin"))
            
            conn.commit()
        
        conn.close()
    
    def hash_password(self, password, salt):
        """Hash password with salt using SHA-256"""
        return hashlib.sha256((password + salt).encode()).hexdigest()
    
    def verify_password(self, password, hash_value, salt):
        """Verify password against hash"""
        return self.hash_password(password, salt) == hash_value
    
    def generate_token(self, user_id, username, role):
        """Generate JWT token for user"""
        payload = {
            'user_id': user_id,
            'username': username,
            'role': role,
            'exp': datetime.utcnow() + timedelta(seconds=self.token_expiry),
            'iat': datetime.utcnow()
        }
        
        token = jwt.encode(payload, self.secret_key, algorithm='HS256')
        
        # Store session in database
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        expires_at = datetime.utcnow() + timedelta(seconds=self.token_expiry)
        
        cursor.execute('''
            INSERT INTO sessions (user_id, token_hash, expires_at, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, token_hash, expires_at, 
              request.remote_addr if request else None,
              request.headers.get('User-Agent') if request else None))
        
        conn.commit()
        conn.close()
        
        return token
    
    def verify_token(self, token):
        """Verify JWT token and return user info"""
        try:
            payload = jwt.decode(token, self.secret_key, algorithms=['HS256'])
            
            # Check if session is still active in database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            token_hash = hashlib.sha256(token.encode()).hexdigest()
            cursor.execute('''
                SELECT s.*, u.username, u.role, u.is_active 
                FROM sessions s
                JOIN users u ON s.user_id = u.id
                WHERE s.token_hash = ? AND s.is_active = 1 AND s.expires_at > ?
            ''', (token_hash, datetime.utcnow()))
            
            session = cursor.fetchone()
            conn.close()
            
            if session:
                return {
                    'user_id': payload['user_id'],
                    'username': payload['username'],
                    'role': payload['role'],
                    'valid': True
                }
            else:
                return {'valid': False, 'error': 'Session not found or expired'}
                
        except jwt.ExpiredSignatureError:
            return {'valid': False, 'error': 'Token expired'}
        except jwt.InvalidTokenError:
            return {'valid': False, 'error': 'Invalid token'}
    
    def authenticate_user(self, username, password):
        """Authenticate user with username/password"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, username, password_hash, salt, role, is_active
            FROM users WHERE username = ? OR email = ?
        ''', (username, username))
        
        user = cursor.fetchone()
        
        if user and user[5] and self.verify_password(password, user[2], user[3]):
            # Update last login
            cursor.execute('''
                UPDATE users SET last_login = ? WHERE id = ?
            ''', (datetime.utcnow(), user[0]))
            conn.commit()
            conn.close()
            
            return {
                'success': True,
                'user_id': user[0],
                'username': user[1],
                'role': user[4]
            }
        
        conn.close()
        return {'success': False, 'error': 'Invalid credentials'}
    
    def check_rate_limit(self, identifier, endpoint, limit=100, window=3600):
        """Check if request is within rate limits"""
        current_time = datetime.utcnow()
        window_start = current_time - timedelta(seconds=window)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Clean old entries
        cursor.execute('''
            DELETE FROM rate_limits WHERE window_start < ?
        ''', (window_start,))
        
        # Get current count
        cursor.execute('''
            SELECT requests FROM rate_limits 
            WHERE identifier = ? AND endpoint = ?
        ''', (identifier, endpoint))
        
        result = cursor.fetchone()
        
        if result:
            if result[0] >= limit:
                conn.close()
                return False
            
            # Increment counter
            cursor.execute('''
                UPDATE rate_limits SET requests = requests + 1
                WHERE identifier = ? AND endpoint = ?
            ''', (identifier, endpoint))
        else:
            # Create new entry
            cursor.execute('''
                INSERT INTO rate_limits (identifier, endpoint, requests)
                VALUES (?, ?, 1)
            ''', (identifier, endpoint))
        
        conn.commit()
        conn.close()
        return True
    
    def revoke_token(self, token):
        """Revoke a specific token"""
        token_hash = hashlib.sha256(token.encode()).hexdigest()
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            UPDATE sessions SET is_active = 0 WHERE token_hash = ?
        ''', (token_hash,))
        
        conn.commit()
        conn.close()
    
    def cleanup_expired_sessions(self):
        """Clean up expired sessions"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            DELETE FROM sessions WHERE expires_at < ?
        ''', (datetime.utcnow(),))
        
        conn.commit()
        conn.close()

# Security decorators
def require_auth(f):
    """Decorator to require authentication"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        token = None
        
        # Check for token in Authorization header
        if 'Authorization' in request.headers:
            auth_header = request.headers['Authorization']
            try:
                token = auth_header.split(" ")[1]  # Bearer <token>
            except IndexError:
                return jsonify({'error': 'Invalid authorization header format'}), 401
        
        if not token:
            return jsonify({'error': 'Authentication token required'}), 401
        
        # Verify token
        security_manager = current_app.security_manager
        user_info = security_manager.verify_token(token)
        
        if not user_info['valid']:
            return jsonify({'error': user_info.get('error', 'Invalid token')}), 401
        
        # Add user info to request context
        request.current_user = user_info
        
        return f(*args, **kwargs)
    
    return decorated_function

def require_role(required_role):
    """Decorator to require specific role"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not hasattr(request, 'current_user'):
                return jsonify({'error': 'Authentication required'}), 401
            
            user_role = request.current_user.get('role')
            
            if user_role != required_role and user_role != 'admin':
                return jsonify({'error': f'Role {required_role} required'}), 403
            
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator

def rate_limit(limit=100, window=3600):
    """Decorator for rate limiting"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Use IP address as identifier
            identifier = request.remote_addr
            endpoint = request.endpoint
            
            security_manager = current_app.security_manager
            
            if not security_manager.check_rate_limit(identifier, endpoint, limit, window):
                return jsonify({
                    'error': 'Rate limit exceeded',
                    'limit': limit,
                    'window': window
                }), 429
            
            return f(*args, **kwargs)
        
        return decorated_function
    return decorator

