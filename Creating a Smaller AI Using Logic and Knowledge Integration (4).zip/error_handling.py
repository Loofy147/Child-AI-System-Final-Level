"""
Error handling and resilience module for Child AI system
Implements circuit breakers, retry mechanisms, and graceful error recovery
"""

import time
import threading
import traceback
import logging
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, Type
from enum import Enum
from datetime import datetime, timedelta
import json

class CircuitState(Enum):
    """Circuit breaker states"""
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing, requests blocked
    HALF_OPEN = "half_open"  # Testing if service recovered

class CircuitBreaker:
    """Circuit breaker pattern implementation"""
    
    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 60, 
                 expected_exception: Type[Exception] = Exception):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.expected_exception = expected_exception
        
        self.failure_count = 0
        self.last_failure_time = None
        self.state = CircuitState.CLOSED
        self.lock = threading.Lock()
    
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with circuit breaker protection"""
        with self.lock:
            if self.state == CircuitState.OPEN:
                if self._should_attempt_reset():
                    self.state = CircuitState.HALF_OPEN
                else:
                    raise CircuitBreakerOpenError(
                        f"Circuit breaker is OPEN. Last failure: {self.last_failure_time}"
                    )
            
            try:
                result = func(*args, **kwargs)
                self._on_success()
                return result
                
            except self.expected_exception as e:
                self._on_failure()
                raise e
    
    def _should_attempt_reset(self) -> bool:
        """Check if enough time has passed to attempt reset"""
        return (
            self.last_failure_time and
            time.time() - self.last_failure_time >= self.recovery_timeout
        )
    
    def _on_success(self):
        """Handle successful execution"""
        self.failure_count = 0
        self.state = CircuitState.CLOSED
    
    def _on_failure(self):
        """Handle failed execution"""
        self.failure_count += 1
        self.last_failure_time = time.time()
        
        if self.failure_count >= self.failure_threshold:
            self.state = CircuitState.OPEN
    
    def get_state(self) -> Dict[str, Any]:
        """Get current circuit breaker state"""
        return {
            'state': self.state.value,
            'failure_count': self.failure_count,
            'failure_threshold': self.failure_threshold,
            'last_failure_time': self.last_failure_time,
            'recovery_timeout': self.recovery_timeout
        }

class RetryPolicy:
    """Configurable retry policy"""
    
    def __init__(self, max_attempts: int = 3, base_delay: float = 1.0, 
                 max_delay: float = 60.0, backoff_multiplier: float = 2.0,
                 jitter: bool = True):
        self.max_attempts = max_attempts
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.backoff_multiplier = backoff_multiplier
        self.jitter = jitter
    
    def calculate_delay(self, attempt: int) -> float:
        """Calculate delay for given attempt"""
        delay = self.base_delay * (self.backoff_multiplier ** (attempt - 1))
        delay = min(delay, self.max_delay)
        
        if self.jitter:
            import random
            delay *= (0.5 + random.random() * 0.5)  # Add 0-50% jitter
        
        return delay

class ErrorRecoveryManager:
    """Manages error recovery strategies"""
    
    def __init__(self):
        self.recovery_strategies = {}
        self.error_history = []
        self.recovery_stats = {
            'total_errors': 0,
            'recovered_errors': 0,
            'unrecovered_errors': 0
        }
    
    def register_recovery_strategy(self, error_type: Type[Exception], 
                                 strategy: Callable[[Exception], Any]):
        """Register recovery strategy for specific error type"""
        self.recovery_strategies[error_type] = strategy
    
    def handle_error(self, error: Exception, context: Dict[str, Any] = None) -> Any:
        """Handle error with appropriate recovery strategy"""
        self.error_history.append({
            'error_type': type(error).__name__,
            'error_message': str(error),
            'timestamp': datetime.utcnow().isoformat(),
            'context': context or {}
        })
        
        self.recovery_stats['total_errors'] += 1
        
        # Find appropriate recovery strategy
        for error_type, strategy in self.recovery_strategies.items():
            if isinstance(error, error_type):
                try:
                    result = strategy(error)
                    self.recovery_stats['recovered_errors'] += 1
                    return result
                except Exception as recovery_error:
                    # Recovery failed, log and continue
                    logging.error(f"Recovery strategy failed: {recovery_error}")
        
        # No recovery strategy found or all failed
        self.recovery_stats['unrecovered_errors'] += 1
        raise error
    
    def get_error_statistics(self) -> Dict[str, Any]:
        """Get error and recovery statistics"""
        recent_errors = [
            error for error in self.error_history
            if datetime.fromisoformat(error['timestamp']) > 
               datetime.utcnow() - timedelta(hours=24)
        ]
        
        error_types = {}
        for error in recent_errors:
            error_type = error['error_type']
            error_types[error_type] = error_types.get(error_type, 0) + 1
        
        return {
            'stats': self.recovery_stats,
            'recent_errors_24h': len(recent_errors),
            'error_types_24h': error_types,
            'recovery_rate': (
                self.recovery_stats['recovered_errors'] / 
                max(self.recovery_stats['total_errors'], 1) * 100
            )
        }

class GracefulDegradation:
    """Implements graceful degradation patterns"""
    
    def __init__(self):
        self.fallback_strategies = {}
        self.service_health = {}
    
    def register_fallback(self, service_name: str, fallback_func: Callable):
        """Register fallback function for a service"""
        self.fallback_strategies[service_name] = fallback_func
    
    def call_with_fallback(self, service_name: str, primary_func: Callable, 
                          *args, **kwargs) -> Any:
        """Call primary function with fallback on failure"""
        try:
            result = primary_func(*args, **kwargs)
            self.service_health[service_name] = {
                'status': 'healthy',
                'last_success': datetime.utcnow().isoformat()
            }
            return result
            
        except Exception as e:
            self.service_health[service_name] = {
                'status': 'degraded',
                'last_failure': datetime.utcnow().isoformat(),
                'error': str(e)
            }
            
            # Try fallback
            if service_name in self.fallback_strategies:
                try:
                    return self.fallback_strategies[service_name](*args, **kwargs)
                except Exception as fallback_error:
                    self.service_health[service_name]['fallback_error'] = str(fallback_error)
            
            raise e
    
    def get_service_health(self) -> Dict[str, Any]:
        """Get health status of all services"""
        return self.service_health

# Custom exceptions
class CircuitBreakerOpenError(Exception):
    """Raised when circuit breaker is open"""
    pass

class RetryExhaustedError(Exception):
    """Raised when all retry attempts are exhausted"""
    pass

class GracefulDegradationError(Exception):
    """Raised when graceful degradation fails"""
    pass

# Decorators for error handling
def circuit_breaker(failure_threshold: int = 5, recovery_timeout: int = 60,
                   expected_exception: Type[Exception] = Exception):
    """Decorator to add circuit breaker protection"""
    def decorator(func: Callable) -> Callable:
        breaker = CircuitBreaker(failure_threshold, recovery_timeout, expected_exception)
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            return breaker.call(func, *args, **kwargs)
        
        wrapper._circuit_breaker = breaker
        return wrapper
    
    return decorator

def retry(max_attempts: int = 3, base_delay: float = 1.0, max_delay: float = 60.0,
          backoff_multiplier: float = 2.0, exceptions: tuple = (Exception,)):
    """Decorator to add retry logic"""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            policy = RetryPolicy(max_attempts, base_delay, max_delay, backoff_multiplier)
            last_exception = None
            
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    
                    if attempt == max_attempts:
                        raise RetryExhaustedError(
                            f"All {max_attempts} retry attempts failed. Last error: {e}"
                        ) from e
                    
                    delay = policy.calculate_delay(attempt)
                    time.sleep(delay)
            
            # This should never be reached, but just in case
            raise last_exception
        
        return wrapper
    
    return decorator

def safe_execute(fallback_value: Any = None, log_errors: bool = True):
    """Decorator to safely execute functions with fallback"""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if log_errors:
                    logging.error(f"Error in {func.__name__}: {e}")
                    logging.error(traceback.format_exc())
                
                return fallback_value
        
        return wrapper
    
    return decorator

def timeout(seconds: int):
    """Decorator to add timeout to function execution"""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            import signal
            
            def timeout_handler(signum, frame):
                raise TimeoutError(f"Function {func.__name__} timed out after {seconds} seconds")
            
            # Set timeout
            old_handler = signal.signal(signal.SIGALRM, timeout_handler)
            signal.alarm(seconds)
            
            try:
                result = func(*args, **kwargs)
                return result
            finally:
                # Reset alarm
                signal.alarm(0)
                signal.signal(signal.SIGALRM, old_handler)
        
        return wrapper
    
    return decorator

class ErrorReporter:
    """Centralized error reporting and alerting"""
    
    def __init__(self):
        self.error_log = []
        self.alert_thresholds = {
            'error_rate': 10,  # errors per minute
            'critical_errors': 1  # critical errors
        }
        self.alert_callbacks = []
    
    def register_alert_callback(self, callback: Callable[[Dict[str, Any]], None]):
        """Register callback for error alerts"""
        self.alert_callbacks.append(callback)
    
    def report_error(self, error: Exception, severity: str = 'medium', 
                    context: Dict[str, Any] = None):
        """Report error with context"""
        error_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'error_type': type(error).__name__,
            'error_message': str(error),
            'severity': severity,
            'context': context or {},
            'stack_trace': traceback.format_exc()
        }
        
        self.error_log.append(error_entry)
        
        # Check if alert should be triggered
        self._check_alert_conditions(error_entry)
    
    def _check_alert_conditions(self, error_entry: Dict[str, Any]):
        """Check if error conditions warrant an alert"""
        now = datetime.utcnow()
        one_minute_ago = now - timedelta(minutes=1)
        
        # Count recent errors
        recent_errors = [
            error for error in self.error_log
            if datetime.fromisoformat(error['timestamp']) > one_minute_ago
        ]
        
        # Check error rate threshold
        if len(recent_errors) >= self.alert_thresholds['error_rate']:
            self._trigger_alert({
                'type': 'high_error_rate',
                'message': f"High error rate: {len(recent_errors)} errors in last minute",
                'errors': recent_errors
            })
        
        # Check critical error threshold
        if error_entry['severity'] == 'critical':
            self._trigger_alert({
                'type': 'critical_error',
                'message': f"Critical error occurred: {error_entry['error_message']}",
                'error': error_entry
            })
    
    def _trigger_alert(self, alert_data: Dict[str, Any]):
        """Trigger alert callbacks"""
        for callback in self.alert_callbacks:
            try:
                callback(alert_data)
            except Exception as e:
                logging.error(f"Alert callback failed: {e}")
    
    def get_error_summary(self, hours: int = 24) -> Dict[str, Any]:
        """Get error summary for specified time period"""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        
        recent_errors = [
            error for error in self.error_log
            if datetime.fromisoformat(error['timestamp']) > cutoff_time
        ]
        
        # Group by error type
        error_types = {}
        severity_counts = {'low': 0, 'medium': 0, 'high': 0, 'critical': 0}
        
        for error in recent_errors:
            error_type = error['error_type']
            error_types[error_type] = error_types.get(error_type, 0) + 1
            severity_counts[error['severity']] += 1
        
        return {
            'total_errors': len(recent_errors),
            'error_types': error_types,
            'severity_distribution': severity_counts,
            'error_rate_per_hour': len(recent_errors) / hours,
            'most_common_error': max(error_types.items(), key=lambda x: x[1])[0] if error_types else None
        }

# Global instances
error_recovery_manager = ErrorRecoveryManager()
graceful_degradation = GracefulDegradation()
error_reporter = ErrorReporter()

# Default recovery strategies
def database_connection_recovery(error: Exception) -> Any:
    """Recovery strategy for database connection errors"""
    import sqlite3
    import time
    
    # Wait a bit and try to reconnect
    time.sleep(1)
    # This would implement actual database reconnection logic
    logging.info("Attempting database reconnection...")
    return None

def external_api_recovery(error: Exception) -> Any:
    """Recovery strategy for external API errors"""
    # Return cached data or default response
    logging.info("Using cached data due to external API failure")
    return {'status': 'degraded', 'data': None}

# Register default recovery strategies
error_recovery_manager.register_recovery_strategy(ConnectionError, database_connection_recovery)
error_recovery_manager.register_recovery_strategy(TimeoutError, external_api_recovery)

