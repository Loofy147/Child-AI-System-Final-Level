"""
Comprehensive tests for the Child AI logic engine
Tests propositional logic, predicate logic, and inference mechanisms
"""

import pytest
import sys
import os

# Add src directory to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from logic_engine import LogicEngine, LogicalStatement

class TestLogicEngine:
    """Test suite for LogicEngine class"""
    
    def setup_method(self):
        """Setup test environment"""
        self.engine = LogicEngine()
    
    def test_engine_initialization(self):
        """Test logic engine initialization"""
        assert self.engine is not None
        assert hasattr(self.engine, 'facts')
        assert hasattr(self.engine, 'rules')
        assert len(self.engine.facts) >= 0
        assert len(self.engine.rules) >= 0
    
    def test_add_fact(self):
        """Test adding facts to the knowledge base"""
        initial_count = len(self.engine.facts)
        
        # Add a simple fact
        self.engine.add_fact("Human(Socrates)")
        assert len(self.engine.facts) == initial_count + 1
        assert "Human(Socrates)" in self.engine.facts
        
        # Test duplicate fact handling
        self.engine.add_fact("Human(Socrates)")
        assert len(self.engine.facts) == initial_count + 1  # Should not duplicate
    
    def test_add_rule(self):
        """Test adding rules to the knowledge base"""
        initial_count = len(self.engine.rules)
        
        # Add a simple rule
        rule = "Human(X) -> Mortal(X)"
        self.engine.add_rule(rule)
        assert len(self.engine.rules) == initial_count + 1
        
        # Verify rule structure
        added_rule = self.engine.rules[-1]
        assert 'premise' in added_rule
        assert 'conclusion' in added_rule
    
    def test_simple_query(self):
        """Test simple fact queries"""
        # Add test facts
        self.engine.add_fact("Human(Socrates)")
        self.engine.add_fact("Human(Plato)")
        
        # Test positive queries
        result = self.engine.query("Human(Socrates)")
        assert result['result'] is True
        assert result['explanation'] is not None
        
        # Test negative queries
        result = self.engine.query("Human(Aristotle)")
        assert result['result'] is False
    
    def test_rule_based_inference(self):
        """Test inference using rules"""
        # Add facts and rules
        self.engine.add_fact("Human(Socrates)")
        self.engine.add_rule("Human(X) -> Mortal(X)")
        
        # Test inference
        result = self.engine.query("Mortal(Socrates)")
        assert result['result'] is True
        assert "inference" in result['explanation'].lower()
    
    def test_complex_inference_chain(self):
        """Test multi-step inference chains"""
        # Setup complex knowledge base
        self.engine.add_fact("Human(Socrates)")
        self.engine.add_rule("Human(X) -> Mortal(X)")
        self.engine.add_rule("Mortal(X) -> CanDie(X)")
        
        # Test multi-step inference
        result = self.engine.query("CanDie(Socrates)")
        assert result['result'] is True
    
    def test_invalid_queries(self):
        """Test handling of invalid queries"""
        # Test malformed queries
        result = self.engine.query("")
        assert result['result'] is False
        assert "error" in result['explanation'].lower() or "invalid" in result['explanation'].lower()
        
        result = self.engine.query("InvalidSyntax((")
        assert result['result'] is False
    
    def test_predicate_parsing(self):
        """Test predicate parsing functionality"""
        # Test simple predicate
        predicate = "Human(Socrates)"
        parsed = self.engine.parse_predicate(predicate)
        assert parsed is not None
        assert parsed['predicate'] == 'Human'
        assert 'Socrates' in parsed['arguments']
        
        # Test predicate with multiple arguments
        predicate = "Loves(John, Mary)"
        parsed = self.engine.parse_predicate(predicate)
        assert parsed is not None
        assert parsed['predicate'] == 'Loves'
        assert len(parsed['arguments']) == 2
    
    def test_variable_substitution(self):
        """Test variable substitution in rules"""
        # Add rule with variable
        self.engine.add_rule("Human(X) -> Mortal(X)")
        self.engine.add_fact("Human(Plato)")
        
        # Test that variable X is properly substituted
        result = self.engine.query("Mortal(Plato)")
        assert result['result'] is True
    
    def test_knowledge_base_state(self):
        """Test knowledge base state management"""
        # Get initial state
        initial_state = self.engine.get_knowledge_base_state()
        assert 'facts' in initial_state
        assert 'rules' in initial_state
        assert 'derived_facts' in initial_state
        
        # Add some knowledge
        self.engine.add_fact("Test(fact)")
        self.engine.add_rule("Test(X) -> Verified(X)")
        
        # Check updated state
        updated_state = self.engine.get_knowledge_base_state()
        assert len(updated_state['facts']) > len(initial_state['facts'])
        assert len(updated_state['rules']) > len(initial_state['rules'])
    
    def test_explanation_quality(self):
        """Test quality of explanations provided"""
        self.engine.add_fact("Human(Socrates)")
        self.engine.add_rule("Human(X) -> Mortal(X)")
        
        result = self.engine.query("Mortal(Socrates)")
        explanation = result['explanation']
        
        # Check that explanation contains key information
        assert "Human(Socrates)" in explanation
        assert "Human(X) -> Mortal(X)" in explanation or "rule" in explanation.lower()
        assert len(explanation) > 10  # Should be reasonably detailed
    
    def test_performance_with_large_knowledge_base(self):
        """Test performance with larger knowledge bases"""
        import time
        
        # Add many facts
        for i in range(100):
            self.engine.add_fact(f"Number({i})")
        
        # Add rules
        for i in range(10):
            self.engine.add_rule(f"Number(X) -> IsInteger{i}(X)")
        
        # Time a query
        start_time = time.time()
        result = self.engine.query("Number(50)")
        end_time = time.time()
        
        assert result['result'] is True
        assert (end_time - start_time) < 1.0  # Should complete within 1 second
    
    def test_contradiction_handling(self):
        """Test handling of contradictory information"""
        # Add contradictory facts
        self.engine.add_fact("Alive(Socrates)")
        self.engine.add_fact("Dead(Socrates)")
        self.engine.add_rule("Dead(X) -> ~Alive(X)")
        
        # The system should handle this gracefully
        result1 = self.engine.query("Alive(Socrates)")
        result2 = self.engine.query("Dead(Socrates)")
        
        # Both should return results (even if contradictory)
        assert 'result' in result1
        assert 'result' in result2

class TestLogicalStatement:
    """Test suite for LogicalStatement class"""
    
    def test_statement_creation(self):
        """Test creation of logical statements"""
        stmt = LogicalStatement("Human(Socrates)")
        assert stmt is not None
        assert str(stmt) == "Human(Socrates)"
    
    def test_statement_equality(self):
        """Test equality comparison of statements"""
        stmt1 = LogicalStatement("Human(Socrates)")
        stmt2 = LogicalStatement("Human(Socrates)")
        stmt3 = LogicalStatement("Human(Plato)")
        
        assert stmt1 == stmt2
        assert stmt1 != stmt3
    
    def test_statement_validation(self):
        """Test validation of logical statements"""
        # Valid statements
        valid_statements = [
            "Human(Socrates)",
            "Loves(John, Mary)",
            "GreaterThan(5, 3)",
            "P",
            "Q"
        ]
        
        for stmt_str in valid_statements:
            stmt = LogicalStatement(stmt_str)
            assert stmt.is_valid()
        
        # Invalid statements
        invalid_statements = [
            "",
            "Human(",
            "Loves(John,)",
            "(((",
            "Human Socrates"
        ]
        
        for stmt_str in invalid_statements:
            stmt = LogicalStatement(stmt_str)
            assert not stmt.is_valid()

class TestInferenceEngine:
    """Test suite for inference mechanisms"""
    
    def setup_method(self):
        """Setup test environment"""
        self.engine = LogicEngine()
    
    def test_modus_ponens(self):
        """Test modus ponens inference"""
        # P -> Q, P ⊢ Q
        self.engine.add_fact("P")
        self.engine.add_rule("P -> Q")
        
        result = self.engine.query("Q")
        assert result['result'] is True
    
    def test_modus_tollens(self):
        """Test modus tollens inference"""
        # P -> Q, ~Q ⊢ ~P
        self.engine.add_fact("~Q")
        self.engine.add_rule("P -> Q")
        
        # This is more complex and may not be implemented
        # Just test that the system handles it gracefully
        result = self.engine.query("~P")
        assert 'result' in result
    
    def test_hypothetical_syllogism(self):
        """Test hypothetical syllogism"""
        # P -> Q, Q -> R ⊢ P -> R
        self.engine.add_fact("P")
        self.engine.add_rule("P -> Q")
        self.engine.add_rule("Q -> R")
        
        result = self.engine.query("R")
        assert result['result'] is True
    
    def test_universal_instantiation(self):
        """Test universal instantiation"""
        # ∀x P(x) ⊢ P(a)
        self.engine.add_rule("Human(X) -> Mortal(X)")  # Universal rule
        self.engine.add_fact("Human(Socrates)")
        
        result = self.engine.query("Mortal(Socrates)")
        assert result['result'] is True

# Integration tests
class TestLogicEngineIntegration:
    """Integration tests for the complete logic engine"""
    
    def setup_method(self):
        """Setup test environment"""
        self.engine = LogicEngine()
    
    def test_philosophical_reasoning(self):
        """Test classical philosophical reasoning"""
        # All humans are mortal
        # Socrates is human
        # Therefore, Socrates is mortal
        
        self.engine.add_fact("Human(Socrates)")
        self.engine.add_rule("Human(X) -> Mortal(X)")
        
        result = self.engine.query("Mortal(Socrates)")
        assert result['result'] is True
        assert "Human(Socrates)" in result['explanation']
    
    def test_mathematical_reasoning(self):
        """Test mathematical reasoning"""
        # Numbers and their properties
        self.engine.add_fact("Number(5)")
        self.engine.add_fact("Number(3)")
        self.engine.add_rule("Number(X) -> Integer(X)")
        self.engine.add_rule("Integer(X) -> Real(X)")
        
        result = self.engine.query("Real(5)")
        assert result['result'] is True
    
    def test_family_relationships(self):
        """Test family relationship reasoning"""
        # Family facts
        self.engine.add_fact("Parent(John, Mary)")
        self.engine.add_fact("Parent(Mary, Alice)")
        
        # Family rules
        self.engine.add_rule("Parent(X, Y) -> Ancestor(X, Y)")
        self.engine.add_rule("Parent(X, Y) & Ancestor(Y, Z) -> Ancestor(X, Z)")
        
        # Test direct relationship
        result = self.engine.query("Ancestor(John, Mary)")
        assert result['result'] is True
        
        # Test transitive relationship (if implemented)
        result = self.engine.query("Ancestor(John, Alice)")
        # This may or may not be implemented, just check it doesn't crash
        assert 'result' in result
    
    def test_knowledge_base_consistency(self):
        """Test knowledge base consistency"""
        # Add various facts and rules
        facts = [
            "Human(Socrates)",
            "Human(Plato)",
            "Philosopher(Socrates)",
            "Philosopher(Plato)"
        ]
        
        rules = [
            "Human(X) -> Mortal(X)",
            "Philosopher(X) -> Wise(X)",
            "Human(X) & Philosopher(X) -> GreatThinker(X)"
        ]
        
        for fact in facts:
            self.engine.add_fact(fact)
        
        for rule in rules:
            self.engine.add_rule(rule)
        
        # Test various queries
        queries = [
            "Mortal(Socrates)",
            "Wise(Plato)",
            "GreatThinker(Socrates)"
        ]
        
        for query in queries:
            result = self.engine.query(query)
            assert 'result' in result
            assert 'explanation' in result

if __name__ == '__main__':
    pytest.main([__file__, '-v'])

