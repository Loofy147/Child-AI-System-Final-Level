"""
Configuration management for Child AI system
Handles environment-based configuration, secrets, and feature flags
"""

import os
import json
import logging
from typing import Any, Dict, Optional, Union
from dataclasses import dataclass, field
from pathlib import Path

@dataclass
class DatabaseConfig:
    """Database configuration settings"""
    app_db_path: str = "src/database/app.db"
    security_db_path: str = "src/database/security.db"
    metrics_db_path: str = "src/database/metrics.db"
    learning_db_path: str = "src/database/learning.db"
    connection_pool_size: int = 10
    query_timeout: int = 30
    enable_wal_mode: bool = True
    enable_foreign_keys: bool = True

@dataclass
class SecurityConfig:
    """Security configuration settings"""
    jwt_secret_key: str = field(default_factory=lambda: os.environ.get('JWT_SECRET_KEY', 'default-secret-key'))
    jwt_expiry_seconds: int = 3600
    password_min_length: int = 6
    max_login_attempts: int = 5
    lockout_duration_minutes: int = 15
    enable_rate_limiting: bool = True
    rate_limit_requests: int = 100
    rate_limit_window_seconds: int = 3600
    enable_cors: bool = True
    cors_origins: list = field(default_factory=lambda: ["*"])

@dataclass
class CacheConfig:
    """Caching configuration settings"""
    redis_url: Optional[str] = field(default_factory=lambda: os.environ.get('REDIS_URL'))
    default_ttl_seconds: int = 3600
    memory_cache_size: int = 1000
    enable_query_caching: bool = True
    enable_result_caching: bool = True
    cache_cleanup_interval_seconds: int = 300

@dataclass
class LoggingConfig:
    """Logging configuration settings"""
    log_level: str = field(default_factory=lambda: os.environ.get('LOG_LEVEL', 'INFO'))
    log_format: str = 'json'
    log_file_path: str = 'logs/child_ai.log'
    error_log_path: str = 'logs/child_ai_errors.log'
    max_log_file_size_mb: int = 100
    log_retention_days: int = 30
    enable_console_logging: bool = True
    enable_file_logging: bool = True

@dataclass
class MonitoringConfig:
    """Monitoring and observability configuration"""
    enable_metrics_collection: bool = True
    metrics_collection_interval_seconds: int = 60
    enable_health_checks: bool = True
    health_check_interval_seconds: int = 30
    enable_performance_monitoring: bool = True
    alert_error_threshold: int = 10
    alert_response_time_threshold_ms: int = 5000

@dataclass
class AIConfig:
    """AI-specific configuration settings"""
    max_facts_in_memory: int = 10000
    max_rules_in_memory: int = 1000
    inference_timeout_seconds: int = 30
    max_inference_depth: int = 10
    enable_learning: bool = True
    learning_rate: float = 0.01
    confidence_threshold: float = 0.7
    enable_explanation_generation: bool = True

@dataclass
class ServerConfig:
    """Server configuration settings"""
    host: str = field(default_factory=lambda: os.environ.get('HOST', '0.0.0.0'))
    port: int = field(default_factory=lambda: int(os.environ.get('PORT', '5000')))
    debug: bool = field(default_factory=lambda: os.environ.get('DEBUG', 'False').lower() == 'true')
    threaded: bool = True
    max_content_length_mb: int = 16
    request_timeout_seconds: int = 30

@dataclass
class FeatureFlags:
    """Feature flags for enabling/disabling functionality"""
    enable_authentication: bool = True
    enable_user_registration: bool = True
    enable_admin_panel: bool = True
    enable_api_documentation: bool = True
    enable_metrics_api: bool = True
    enable_learning_api: bool = True
    enable_knowledge_integration: bool = True
    enable_async_processing: bool = True
    enable_circuit_breakers: bool = True
    enable_graceful_degradation: bool = True

class ConfigManager:
    """Centralized configuration management"""
    
    def __init__(self, config_file: Optional[str] = None, environment: Optional[str] = None):
        self.environment = environment or os.environ.get('ENVIRONMENT', 'development')
        self.config_file = config_file or f"config/{self.environment}.json"
        
        # Initialize configuration objects
        self.database = DatabaseConfig()
        self.security = SecurityConfig()
        self.cache = CacheConfig()
        self.logging = LoggingConfig()
        self.monitoring = MonitoringConfig()
        self.ai = AIConfig()
        self.server = ServerConfig()
        self.features = FeatureFlags()
        
        # Load configuration
        self._load_configuration()
        self._validate_configuration()
        self._setup_logging()
    
    def _load_configuration(self):
        """Load configuration from file and environment variables"""
        # Load from file if exists
        config_path = Path(self.config_file)
        if config_path.exists():
            try:
                with open(config_path, 'r') as f:
                    file_config = json.load(f)
                self._apply_file_config(file_config)
            except (json.JSONDecodeError, IOError) as e:
                logging.warning(f"Failed to load config file {self.config_file}: {e}")
        
        # Override with environment variables
        self._apply_environment_config()
    
    def _apply_file_config(self, config: Dict[str, Any]):
        """Apply configuration from file"""
        for section_name, section_config in config.items():
            if hasattr(self, section_name):
                section_obj = getattr(self, section_name)
                for key, value in section_config.items():
                    if hasattr(section_obj, key):
                        setattr(section_obj, key, value)
    
    def _apply_environment_config(self):
        """Apply configuration from environment variables"""
        env_mappings = {
            # Database
            'DB_APP_PATH': ('database', 'app_db_path'),
            'DB_SECURITY_PATH': ('database', 'security_db_path'),
            'DB_METRICS_PATH': ('database', 'metrics_db_path'),
            'DB_LEARNING_PATH': ('database', 'learning_db_path'),
            'DB_POOL_SIZE': ('database', 'connection_pool_size'),
            
            # Security
            'JWT_SECRET_KEY': ('security', 'jwt_secret_key'),
            'JWT_EXPIRY': ('security', 'jwt_expiry_seconds'),
            'PASSWORD_MIN_LENGTH': ('security', 'password_min_length'),
            'ENABLE_RATE_LIMITING': ('security', 'enable_rate_limiting'),
            
            # Cache
            'REDIS_URL': ('cache', 'redis_url'),
            'CACHE_TTL': ('cache', 'default_ttl_seconds'),
            'ENABLE_CACHING': ('cache', 'enable_result_caching'),
            
            # Logging
            'LOG_LEVEL': ('logging', 'log_level'),
            'LOG_FORMAT': ('logging', 'log_format'),
            'LOG_FILE': ('logging', 'log_file_path'),
            
            # Monitoring
            'ENABLE_METRICS': ('monitoring', 'enable_metrics_collection'),
            'METRICS_INTERVAL': ('monitoring', 'metrics_collection_interval_seconds'),
            
            # AI
            'MAX_FACTS': ('ai', 'max_facts_in_memory'),
            'MAX_RULES': ('ai', 'max_rules_in_memory'),
            'INFERENCE_TIMEOUT': ('ai', 'inference_timeout_seconds'),
            'ENABLE_LEARNING': ('ai', 'enable_learning'),
            
            # Server
            'HOST': ('server', 'host'),
            'PORT': ('server', 'port'),
            'DEBUG': ('server', 'debug'),
            
            # Features
            'ENABLE_AUTH': ('features', 'enable_authentication'),
            'ENABLE_REGISTRATION': ('features', 'enable_user_registration'),
            'ENABLE_ADMIN': ('features', 'enable_admin_panel'),
        }
        
        for env_var, (section, key) in env_mappings.items():
            value = os.environ.get(env_var)
            if value is not None:
                section_obj = getattr(self, section)
                current_value = getattr(section_obj, key)
                
                # Convert value to appropriate type
                if isinstance(current_value, bool):
                    value = value.lower() in ('true', '1', 'yes', 'on')
                elif isinstance(current_value, int):
                    value = int(value)
                elif isinstance(current_value, float):
                    value = float(value)
                elif isinstance(current_value, list):
                    value = value.split(',') if value else []
                
                setattr(section_obj, key, value)
    
    def _validate_configuration(self):
        """Validate configuration settings"""
        errors = []
        
        # Validate security settings
        if len(self.security.jwt_secret_key) < 16:
            errors.append("JWT secret key must be at least 16 characters long")
        
        if self.security.password_min_length < 4:
            errors.append("Password minimum length must be at least 4 characters")
        
        # Validate server settings
        if not (1 <= self.server.port <= 65535):
            errors.append("Server port must be between 1 and 65535")
        
        # Validate AI settings
        if self.ai.max_facts_in_memory < 100:
            errors.append("Maximum facts in memory must be at least 100")
        
        if self.ai.inference_timeout_seconds < 1:
            errors.append("Inference timeout must be at least 1 second")
        
        # Validate logging settings
        valid_log_levels = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
        if self.logging.log_level.upper() not in valid_log_levels:
            errors.append(f"Log level must be one of: {', '.join(valid_log_levels)}")
        
        if errors:
            raise ValueError(f"Configuration validation failed: {'; '.join(errors)}")
    
    def _setup_logging(self):
        """Setup logging based on configuration"""
        # Create logs directory
        log_dir = Path(self.logging.log_file_path).parent
        log_dir.mkdir(exist_ok=True)
        
        # Configure logging level
        numeric_level = getattr(logging, self.logging.log_level.upper())
        logging.basicConfig(level=numeric_level)
    
    def get_database_url(self, db_type: str = 'app') -> str:
        """Get database URL for specified database type"""
        db_paths = {
            'app': self.database.app_db_path,
            'security': self.database.security_db_path,
            'metrics': self.database.metrics_db_path,
            'learning': self.database.learning_db_path
        }
        
        if db_type not in db_paths:
            raise ValueError(f"Unknown database type: {db_type}")
        
        return db_paths[db_type]
    
    def is_feature_enabled(self, feature_name: str) -> bool:
        """Check if a feature is enabled"""
        return getattr(self.features, feature_name, False)
    
    def get_config_dict(self) -> Dict[str, Any]:
        """Get complete configuration as dictionary"""
        return {
            'environment': self.environment,
            'database': self.database.__dict__,
            'security': {k: v for k, v in self.security.__dict__.items() if 'secret' not in k.lower()},
            'cache': self.cache.__dict__,
            'logging': self.logging.__dict__,
            'monitoring': self.monitoring.__dict__,
            'ai': self.ai.__dict__,
            'server': self.server.__dict__,
            'features': self.features.__dict__
        }
    
    def update_config(self, section: str, key: str, value: Any) -> bool:
        """Update configuration value at runtime"""
        try:
            if hasattr(self, section):
                section_obj = getattr(self, section)
                if hasattr(section_obj, key):
                    setattr(section_obj, key, value)
                    return True
            return False
        except Exception:
            return False
    
    def save_config(self, file_path: Optional[str] = None) -> bool:
        """Save current configuration to file"""
        try:
            save_path = file_path or self.config_file
            config_dict = self.get_config_dict()
            
            # Create directory if it doesn't exist
            Path(save_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(save_path, 'w') as f:
                json.dump(config_dict, f, indent=2)
            
            return True
        except Exception as e:
            logging.error(f"Failed to save configuration: {e}")
            return False

class SecretsManager:
    """Secure secrets management"""
    
    def __init__(self):
        self.secrets = {}
        self._load_secrets()
    
    def _load_secrets(self):
        """Load secrets from environment or secure storage"""
        # Load from environment variables
        secret_keys = [
            'JWT_SECRET_KEY',
            'DATABASE_PASSWORD',
            'REDIS_PASSWORD',
            'API_KEY',
            'ENCRYPTION_KEY'
        ]
        
        for key in secret_keys:
            value = os.environ.get(key)
            if value:
                self.secrets[key] = value
    
    def get_secret(self, key: str, default: Optional[str] = None) -> Optional[str]:
        """Get secret value"""
        return self.secrets.get(key, default)
    
    def set_secret(self, key: str, value: str):
        """Set secret value (in memory only)"""
        self.secrets[key] = value
    
    def has_secret(self, key: str) -> bool:
        """Check if secret exists"""
        return key in self.secrets

# Global configuration instances
config_manager = ConfigManager()
secrets_manager = SecretsManager()

# Convenience functions
def get_config() -> ConfigManager:
    """Get global configuration manager"""
    return config_manager

def get_secrets() -> SecretsManager:
    """Get global secrets manager"""
    return secrets_manager

def is_development() -> bool:
    """Check if running in development environment"""
    return config_manager.environment == 'development'

def is_production() -> bool:
    """Check if running in production environment"""
    return config_manager.environment == 'production'

def is_testing() -> bool:
    """Check if running in testing environment"""
    return config_manager.environment == 'testing'

