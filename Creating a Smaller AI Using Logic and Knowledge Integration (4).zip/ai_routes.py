"""
API Routes for Child AI System
This module defines the REST API endpoints for interacting with the Child AI.
"""

from flask import Blueprint, request, jsonify
from src.logic_engine import LogicEngine
from src.knowledge_integration import KnowledgeIntegrator
import json
import traceback

# Create blueprint
ai_bp = Blueprint('ai', __name__)

# Initialize the AI components (in a real application, these would be properly managed)
logic_engine = LogicEngine()
knowledge_integrator = KnowledgeIntegrator(logic_engine)

# Add some initial knowledge for demonstration
logic_engine.add_fact("Human(Socrates)")
logic_engine.add_fact("Human(Plato)")
logic_engine.add_rule("Human(x)", "Mortal(x)")
logic_engine.add_rule("Mortal(x)", "Finite(x)")


@ai_bp.route('/status', methods=['GET'])
def get_status():
    """Get the current status of the AI system."""
    try:
        stats = logic_engine.get_statistics()
        integration_stats = knowledge_integrator.get_integration_statistics()
        
        return jsonify({
            'status': 'active',
            'logic_engine': stats,
            'knowledge_integration': integration_stats,
            'message': 'Child AI is running successfully'
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@ai_bp.route('/facts', methods=['GET'])
def get_facts():
    """Get all facts in the knowledge base."""
    try:
        facts = list(logic_engine.get_all_facts())
        return jsonify({
            'facts': facts,
            'count': len(facts)
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/facts', methods=['POST'])
def add_fact():
    """Add a new fact to the knowledge base."""
    try:
        data = request.get_json()
        if not data or 'fact' not in data:
            return jsonify({
                'error': 'Missing required field: fact'
            }), 400
        
        fact = data['fact']
        logic_engine.add_fact(fact)
        
        return jsonify({
            'message': f'Fact "{fact}" added successfully',
            'fact': fact
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/rules', methods=['POST'])
def add_rule():
    """Add a new rule to the knowledge base."""
    try:
        data = request.get_json()
        if not data or 'premise' not in data or 'conclusion' not in data:
            return jsonify({
                'error': 'Missing required fields: premise, conclusion'
            }), 400
        
        premise = data['premise']
        conclusion = data['conclusion']
        logic_engine.add_rule(premise, conclusion)
        
        return jsonify({
            'message': f'Rule "{premise} → {conclusion}" added successfully',
            'premise': premise,
            'conclusion': conclusion
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/query', methods=['POST'])
def query_knowledge():
    """Query the knowledge base."""
    try:
        data = request.get_json()
        if not data or 'query' not in data:
            return jsonify({
                'error': 'Missing required field: query'
            }), 400
        
        query = data['query']
        result = logic_engine.query(query)
        explanation = logic_engine.explain_reasoning(query)
        
        return jsonify({
            'query': query,
            'result': result,
            'explanation': explanation
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/integrate/text', methods=['POST'])
def integrate_text():
    """Integrate knowledge from text."""
    try:
        data = request.get_json()
        if not data or 'text' not in data:
            return jsonify({
                'error': 'Missing required field: text'
            }), 400
        
        text = data['text']
        source_name = data.get('source_name', 'api_input')
        
        count = knowledge_integrator.integrate_text(text, source_name)
        
        return jsonify({
            'message': f'Successfully integrated {count} facts from text',
            'facts_integrated': count,
            'source': source_name
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/integrate/structured', methods=['POST'])
def integrate_structured():
    """Integrate knowledge from structured data."""
    try:
        data = request.get_json()
        if not data or 'data' not in data:
            return jsonify({
                'error': 'Missing required field: data'
            }), 400
        
        structured_data = data['data']
        source_name = data.get('source_name', 'api_structured_input')
        
        count = knowledge_integrator.integrate_structured_data(structured_data, source_name)
        
        return jsonify({
            'message': f'Successfully integrated {count} facts from structured data',
            'facts_integrated': count,
            'source': source_name
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/reasoning/explain', methods=['POST'])
def explain_reasoning():
    """Get detailed explanation for a query."""
    try:
        data = request.get_json()
        if not data or 'query' not in data:
            return jsonify({
                'error': 'Missing required field: query'
            }), 400
        
        query = data['query']
        explanation = logic_engine.explain_reasoning(query)
        result = logic_engine.query(query)
        
        return jsonify({
            'query': query,
            'result': result,
            'explanation': explanation,
            'reasoning_steps': explanation  # For now, same as explanation
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/conflicts', methods=['GET'])
def get_conflicts():
    """Get conflicts in the knowledge base."""
    try:
        conflicts = knowledge_integrator.resolve_conflicts()
        
        return jsonify({
            'conflicts': conflicts,
            'count': len(conflicts)
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/integrations/recent', methods=['GET'])
def get_recent_integrations():
    """Get recent knowledge integrations."""
    try:
        limit = request.args.get('limit', 10, type=int)
        integrations = knowledge_integrator.get_recent_integrations(limit)
        
        return jsonify({
            'integrations': integrations,
            'count': len(integrations)
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/learn', methods=['POST'])
def learn_from_interaction():
    """Learn from user interaction (simplified learning mechanism)."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                'error': 'No data provided'
            }), 400
        
        # Extract learning data
        user_input = data.get('input', '')
        expected_output = data.get('expected_output', '')
        feedback = data.get('feedback', '')
        
        # Simple learning: if feedback is positive, try to extract facts from the interaction
        if feedback.lower() in ['positive', 'correct', 'good']:
            # Try to extract facts from the interaction
            learning_text = f"{user_input}. {expected_output}."
            count = knowledge_integrator.integrate_text(learning_text, 'learning_interaction')
            
            return jsonify({
                'message': f'Learned from interaction: integrated {count} new facts',
                'facts_learned': count,
                'feedback_processed': feedback
            })
        else:
            return jsonify({
                'message': 'Feedback noted but no learning action taken',
                'feedback_processed': feedback
            })
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@ai_bp.route('/reset', methods=['POST'])
def reset_knowledge():
    """Reset the knowledge base (for testing purposes)."""
    try:
        global logic_engine, knowledge_integrator
        
        # Reinitialize the components
        logic_engine = LogicEngine()
        knowledge_integrator = KnowledgeIntegrator(logic_engine)
        
        # Add back initial knowledge
        logic_engine.add_fact("Human(Socrates)")
        logic_engine.add_fact("Human(Plato)")
        logic_engine.add_rule("Human(x)", "Mortal(x)")
        logic_engine.add_rule("Mortal(x)", "Finite(x)")
        
        return jsonify({
            'message': 'Knowledge base reset successfully',
            'initial_facts': list(logic_engine.get_all_facts())
        })
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


# Error handlers
@ai_bp.errorhandler(404)
def not_found(error):
    return jsonify({
        'error': 'Endpoint not found'
    }), 404


@ai_bp.errorhandler(500)
def internal_error(error):
    return jsonify({
        'error': 'Internal server error'
    }), 500

