"""
Learning API Routes for Child AI System
This module defines the REST API endpoints for the learning and adaptation features.
"""

from flask import Blueprint, request, jsonify
from src.learning_module import LearningModule
from src.logic_engine import LogicEngine
from src.knowledge_integration import KnowledgeIntegrator
import json
import traceback

# Create blueprint
learning_bp = Blueprint('learning', __name__)

# Initialize components (in a real application, these would be shared instances)
logic_engine = LogicEngine()
knowledge_integrator = KnowledgeIntegrator(logic_engine)
learning_module = LearningModule(logic_engine, knowledge_integrator)

# Add some initial knowledge
logic_engine.add_fact("Human(Socrates)")
logic_engine.add_fact("Human(Plato)")
logic_engine.add_rule("Human(x)", "Mortal(x)")


@learning_bp.route('/status', methods=['GET'])
def get_learning_status():
    """Get the current status of the learning module."""
    try:
        stats = learning_module.get_learning_statistics()
        performance = learning_module.evaluate_performance()
        
        return jsonify({
            'status': 'active',
            'learning_enabled': learning_module.learning_enabled,
            'statistics': stats,
            'performance': performance
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 500


@learning_bp.route('/interact', methods=['POST'])
def learn_from_interaction():
    """Learn from a user interaction."""
    try:
        data = request.get_json()
        if not data:
            return jsonify({
                'error': 'No data provided'
            }), 400
        
        # Validate required fields
        required_fields = ['input_data', 'expected_output', 'actual_output', 'feedback']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'error': f'Missing required field: {field}'
                }), 400
        
        input_data = data['input_data']
        expected_output = data['expected_output']
        actual_output = data['actual_output']
        feedback = data['feedback']
        source = data.get('source', 'api_user')
        
        result = learning_module.learn_from_interaction(
            input_data, expected_output, actual_output, feedback, source
        )
        
        return jsonify({
            'message': 'Interaction processed successfully',
            'learning_result': result
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500


@learning_bp.route('/evaluate', methods=['POST'])
def evaluate_response():
    """Evaluate an AI response using external LLM."""
    try:
        data = request.get_json()
        if not data or 'query' not in data or 'response' not in data:
            return jsonify({
                'error': 'Missing required fields: query, response'
            }), 400
        
        query = data['query']
        response = data['response']
        
        evaluation = learning_module.evaluator.evaluate_with_external_llm(query, response)
        
        return jsonify({
            'query': query,
            'response': response,
            'evaluation': evaluation
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@learning_bp.route('/performance', methods=['GET'])
def get_performance():
    """Get performance evaluation."""
    try:
        performance = learning_module.evaluate_performance()
        return jsonify(performance)
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@learning_bp.route('/statistics', methods=['GET'])
def get_statistics():
    """Get learning statistics."""
    try:
        stats = learning_module.get_learning_statistics()
        return jsonify(stats)
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@learning_bp.route('/examples/recent', methods=['GET'])
def get_recent_examples():
    """Get recent learning examples."""
    try:
        limit = request.args.get('limit', 20, type=int)
        examples = learning_module.learning_db.get_recent_examples(limit)
        
        # Convert examples to dict format
        examples_data = []
        for example in examples:
            examples_data.append({
                'input_data': example.input_data,
                'expected_output': example.expected_output,
                'actual_output': example.actual_output,
                'feedback': example.feedback,
                'confidence': example.confidence,
                'timestamp': example.timestamp.isoformat(),
                'source': example.source
            })
        
        return jsonify({
            'examples': examples_data,
            'count': len(examples_data)
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@learning_bp.route('/rules/induced', methods=['GET'])
def get_induced_rules():
    """Get rules that have been induced from learning."""
    try:
        rules = learning_module.rule_inductor.get_induced_rules()
        
        rules_data = []
        for premise, conclusion, confidence in rules:
            rules_data.append({
                'premise': premise,
                'conclusion': conclusion,
                'confidence': confidence
            })
        
        return jsonify({
            'rules': rules_data,
            'count': len(rules_data)
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@learning_bp.route('/cycle/run', methods=['POST'])
def run_learning_cycle():
    """Run a continuous learning cycle."""
    try:
        result = learning_module.continuous_learning_cycle()
        
        return jsonify({
            'message': 'Learning cycle completed',
            'result': result
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@learning_bp.route('/enable', methods=['POST'])
def enable_learning():
    """Enable learning."""
    try:
        learning_module.enable_learning()
        
        return jsonify({
            'message': 'Learning enabled',
            'learning_enabled': True
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@learning_bp.route('/disable', methods=['POST'])
def disable_learning():
    """Disable learning."""
    try:
        learning_module.disable_learning()
        
        return jsonify({
            'message': 'Learning disabled',
            'learning_enabled': False
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@learning_bp.route('/feedback/batch', methods=['POST'])
def process_batch_feedback():
    """Process multiple feedback examples at once."""
    try:
        data = request.get_json()
        if not data or 'examples' not in data:
            return jsonify({
                'error': 'Missing required field: examples'
            }), 400
        
        examples = data['examples']
        if not isinstance(examples, list):
            return jsonify({
                'error': 'Examples must be a list'
            }), 400
        
        results = []
        for i, example in enumerate(examples):
            try:
                # Validate example structure
                required_fields = ['input_data', 'expected_output', 'actual_output', 'feedback']
                for field in required_fields:
                    if field not in example:
                        results.append({
                            'index': i,
                            'error': f'Missing required field: {field}'
                        })
                        continue
                
                # Process the example
                result = learning_module.learn_from_interaction(
                    example['input_data'],
                    example['expected_output'],
                    example['actual_output'],
                    example['feedback'],
                    example.get('source', 'batch_api')
                )
                
                results.append({
                    'index': i,
                    'success': True,
                    'result': result
                })
            
            except Exception as e:
                results.append({
                    'index': i,
                    'error': str(e)
                })
        
        successful = len([r for r in results if r.get('success', False)])
        failed = len(results) - successful
        
        return jsonify({
            'message': f'Processed {len(examples)} examples',
            'successful': successful,
            'failed': failed,
            'results': results
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


@learning_bp.route('/knowledge/evolve', methods=['POST'])
def evolve_knowledge():
    """Trigger knowledge evolution based on learning."""
    try:
        data = request.get_json()
        threshold = data.get('confidence_threshold', 0.7) if data else 0.7
        
        # Get recent examples and induce rules
        recent_examples = learning_module.learning_db.get_recent_examples(100)
        new_rules = learning_module.rule_inductor.induce_rules_from_examples(recent_examples)
        
        # Filter by confidence threshold
        high_confidence_rules = [(p, c, conf) for p, c, conf in new_rules if conf >= threshold]
        
        # Add to logic engine
        for premise, conclusion, confidence in high_confidence_rules:
            learning_module.logic_engine.add_rule(premise, conclusion)
        
        return jsonify({
            'message': 'Knowledge evolution completed',
            'rules_considered': len(new_rules),
            'rules_added': len(high_confidence_rules),
            'confidence_threshold': threshold
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e)
        }), 500


# Error handlers
@learning_bp.errorhandler(404)
def not_found(error):
    return jsonify({
        'error': 'Learning endpoint not found'
    }), 404


@learning_bp.errorhandler(500)
def internal_error(error):
    return jsonify({
        'error': 'Internal server error in learning module'
    }), 500

