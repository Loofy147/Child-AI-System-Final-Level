"""
Performance optimization and caching module for Child AI system
Implements intelligent caching strategies, query optimization, and async processing
"""

import redis
import json
import hashlib
import time
import sqlite3
import threading
import asyncio
from functools import wraps, lru_cache
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Callable
import pickle
import os

class CacheManager:
    """Intelligent caching system with multiple backends"""
    
    def __init__(self, redis_url=None, default_ttl=3600):
        self.default_ttl = default_ttl
        self.memory_cache = {}
        self.cache_stats = {
            'hits': 0,
            'misses': 0,
            'sets': 0,
            'deletes': 0
        }
        
        # Try to connect to Redis, fall back to memory cache
        self.redis_client = None
        if redis_url:
            try:
                self.redis_client = redis.from_url(redis_url)
                self.redis_client.ping()
            except (redis.ConnectionError, redis.TimeoutError):
                self.redis_client = None
        
        # Start cleanup thread for memory cache
        self.start_cleanup_thread()
    
    def _generate_key(self, prefix: str, *args, **kwargs) -> str:
        """Generate cache key from arguments"""
        key_data = {
            'args': args,
            'kwargs': sorted(kwargs.items())
        }
        key_hash = hashlib.md5(json.dumps(key_data, sort_keys=True).encode()).hexdigest()
        return f"{prefix}:{key_hash}"
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        try:
            # Try Redis first
            if self.redis_client:
                try:
                    value = self.redis_client.get(key)
                    if value:
                        self.cache_stats['hits'] += 1
                        return pickle.loads(value)
                except (redis.ConnectionError, pickle.PickleError):
                    pass
            
            # Fall back to memory cache
            if key in self.memory_cache:
                entry = self.memory_cache[key]
                if entry['expires_at'] > time.time():
                    self.cache_stats['hits'] += 1
                    return entry['value']
                else:
                    del self.memory_cache[key]
            
            self.cache_stats['misses'] += 1
            return None
            
        except Exception:
            self.cache_stats['misses'] += 1
            return None
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> bool:
        """Set value in cache"""
        try:
            ttl = ttl or self.default_ttl
            
            # Try Redis first
            if self.redis_client:
                try:
                    serialized_value = pickle.dumps(value)
                    self.redis_client.setex(key, ttl, serialized_value)
                    self.cache_stats['sets'] += 1
                    return True
                except (redis.ConnectionError, pickle.PickleError):
                    pass
            
            # Fall back to memory cache
            self.memory_cache[key] = {
                'value': value,
                'expires_at': time.time() + ttl
            }
            self.cache_stats['sets'] += 1
            return True
            
        except Exception:
            return False
    
    def delete(self, key: str) -> bool:
        """Delete value from cache"""
        try:
            deleted = False
            
            # Delete from Redis
            if self.redis_client:
                try:
                    if self.redis_client.delete(key):
                        deleted = True
                except redis.ConnectionError:
                    pass
            
            # Delete from memory cache
            if key in self.memory_cache:
                del self.memory_cache[key]
                deleted = True
            
            if deleted:
                self.cache_stats['deletes'] += 1
            
            return deleted
            
        except Exception:
            return False
    
    def clear_pattern(self, pattern: str) -> int:
        """Clear all keys matching pattern"""
        try:
            deleted_count = 0
            
            # Clear from Redis
            if self.redis_client:
                try:
                    keys = self.redis_client.keys(pattern)
                    if keys:
                        deleted_count += self.redis_client.delete(*keys)
                except redis.ConnectionError:
                    pass
            
            # Clear from memory cache
            keys_to_delete = [k for k in self.memory_cache.keys() if pattern.replace('*', '') in k]
            for key in keys_to_delete:
                del self.memory_cache[key]
                deleted_count += 1
            
            return deleted_count
            
        except Exception:
            return 0
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_requests = self.cache_stats['hits'] + self.cache_stats['misses']
        hit_rate = (self.cache_stats['hits'] / total_requests * 100) if total_requests > 0 else 0
        
        return {
            'hits': self.cache_stats['hits'],
            'misses': self.cache_stats['misses'],
            'sets': self.cache_stats['sets'],
            'deletes': self.cache_stats['deletes'],
            'hit_rate_percent': round(hit_rate, 2),
            'memory_cache_size': len(self.memory_cache),
            'redis_connected': self.redis_client is not None
        }
    
    def start_cleanup_thread(self):
        """Start background thread to clean expired memory cache entries"""
        def cleanup():
            while True:
                try:
                    current_time = time.time()
                    expired_keys = [
                        key for key, entry in self.memory_cache.items()
                        if entry['expires_at'] <= current_time
                    ]
                    for key in expired_keys:
                        del self.memory_cache[key]
                    
                    time.sleep(300)  # Clean every 5 minutes
                except Exception:
                    time.sleep(300)
        
        thread = threading.Thread(target=cleanup, daemon=True)
        thread.start()

class QueryOptimizer:
    """Database query optimization and connection pooling"""
    
    def __init__(self, db_path: str, pool_size: int = 10):
        self.db_path = db_path
        self.pool_size = pool_size
        self.connection_pool = []
        self.pool_lock = threading.Lock()
        self.query_stats = {}
        
        # Initialize connection pool
        self.init_connection_pool()
    
    def init_connection_pool(self):
        """Initialize database connection pool"""
        for _ in range(self.pool_size):
            conn = sqlite3.connect(self.db_path, check_same_thread=False)
            conn.row_factory = sqlite3.Row  # Enable column access by name
            
            # Optimize SQLite settings
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA cache_size=10000")
            conn.execute("PRAGMA temp_store=MEMORY")
            
            self.connection_pool.append(conn)
    
    def get_connection(self) -> sqlite3.Connection:
        """Get connection from pool"""
        with self.pool_lock:
            if self.connection_pool:
                return self.connection_pool.pop()
            else:
                # Create new connection if pool is empty
                conn = sqlite3.connect(self.db_path, check_same_thread=False)
                conn.row_factory = sqlite3.Row
                return conn
    
    def return_connection(self, conn: sqlite3.Connection):
        """Return connection to pool"""
        with self.pool_lock:
            if len(self.connection_pool) < self.pool_size:
                self.connection_pool.append(conn)
            else:
                conn.close()
    
    def execute_query(self, query: str, params: tuple = (), fetch_one: bool = False) -> Any:
        """Execute optimized query with connection pooling"""
        start_time = time.time()
        conn = self.get_connection()
        
        try:
            cursor = conn.cursor()
            cursor.execute(query, params)
            
            if fetch_one:
                result = cursor.fetchone()
            else:
                result = cursor.fetchall()
            
            conn.commit()
            
            # Record query statistics
            duration = (time.time() - start_time) * 1000
            query_key = hashlib.md5(query.encode()).hexdigest()[:8]
            
            if query_key not in self.query_stats:
                self.query_stats[query_key] = {
                    'query': query[:100] + '...' if len(query) > 100 else query,
                    'count': 0,
                    'total_duration': 0,
                    'avg_duration': 0
                }
            
            stats = self.query_stats[query_key]
            stats['count'] += 1
            stats['total_duration'] += duration
            stats['avg_duration'] = stats['total_duration'] / stats['count']
            
            return result
            
        finally:
            self.return_connection(conn)
    
    def get_query_stats(self) -> Dict[str, Any]:
        """Get query performance statistics"""
        return dict(self.query_stats)

class AsyncProcessor:
    """Asynchronous processing for heavy operations"""
    
    def __init__(self, max_workers: int = 4):
        self.max_workers = max_workers
        self.task_queue = asyncio.Queue()
        self.results = {}
        self.task_status = {}
        
    async def submit_task(self, task_id: str, func: Callable, *args, **kwargs) -> str:
        """Submit task for async processing"""
        task_data = {
            'id': task_id,
            'func': func,
            'args': args,
            'kwargs': kwargs,
            'submitted_at': time.time()
        }
        
        await self.task_queue.put(task_data)
        self.task_status[task_id] = {
            'status': 'queued',
            'submitted_at': task_data['submitted_at'],
            'started_at': None,
            'completed_at': None
        }
        
        return task_id
    
    async def get_task_result(self, task_id: str) -> Dict[str, Any]:
        """Get task result"""
        if task_id in self.results:
            return {
                'status': 'completed',
                'result': self.results[task_id],
                'task_info': self.task_status.get(task_id, {})
            }
        elif task_id in self.task_status:
            return {
                'status': self.task_status[task_id]['status'],
                'result': None,
                'task_info': self.task_status[task_id]
            }
        else:
            return {
                'status': 'not_found',
                'result': None,
                'task_info': {}
            }
    
    async def process_tasks(self):
        """Process tasks from queue"""
        while True:
            try:
                task_data = await self.task_queue.get()
                task_id = task_data['id']
                
                # Update status
                self.task_status[task_id]['status'] = 'processing'
                self.task_status[task_id]['started_at'] = time.time()
                
                # Execute task
                try:
                    if asyncio.iscoroutinefunction(task_data['func']):
                        result = await task_data['func'](*task_data['args'], **task_data['kwargs'])
                    else:
                        result = task_data['func'](*task_data['args'], **task_data['kwargs'])
                    
                    self.results[task_id] = result
                    self.task_status[task_id]['status'] = 'completed'
                    
                except Exception as e:
                    self.results[task_id] = {'error': str(e)}
                    self.task_status[task_id]['status'] = 'failed'
                
                self.task_status[task_id]['completed_at'] = time.time()
                self.task_queue.task_done()
                
            except Exception:
                continue

# Caching decorators
def cache_result(prefix: str, ttl: int = 3600, cache_manager: Optional[CacheManager] = None):
    """Decorator to cache function results"""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Use global cache manager if not provided
            nonlocal cache_manager
            if cache_manager is None:
                cache_manager = getattr(wrapper, '_cache_manager', None)
                if cache_manager is None:
                    cache_manager = CacheManager()
                    wrapper._cache_manager = cache_manager
            
            # Generate cache key
            cache_key = cache_manager._generate_key(prefix, *args, **kwargs)
            
            # Try to get from cache
            cached_result = cache_manager.get(cache_key)
            if cached_result is not None:
                return cached_result
            
            # Execute function and cache result
            result = func(*args, **kwargs)
            cache_manager.set(cache_key, result, ttl)
            
            return result
        
        return wrapper
    return decorator

def invalidate_cache(prefix: str, cache_manager: Optional[CacheManager] = None):
    """Decorator to invalidate cache after function execution"""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            
            # Invalidate cache
            nonlocal cache_manager
            if cache_manager is None:
                cache_manager = getattr(wrapper, '_cache_manager', None)
                if cache_manager is None:
                    cache_manager = CacheManager()
                    wrapper._cache_manager = cache_manager
            
            cache_manager.clear_pattern(f"{prefix}:*")
            
            return result
        
        return wrapper
    return decorator

@lru_cache(maxsize=1000)
def cached_logic_operation(operation: str, *args) -> Any:
    """LRU cache for frequently used logic operations"""
    # This would be implemented based on specific logic operations
    # For now, it's a placeholder for caching expensive computations
    pass

class PerformanceMonitor:
    """Monitor and optimize system performance"""
    
    def __init__(self):
        self.performance_data = {}
        self.optimization_suggestions = []
    
    def record_operation(self, operation_name: str, duration: float, 
                        memory_usage: float = 0, cpu_usage: float = 0):
        """Record performance data for an operation"""
        if operation_name not in self.performance_data:
            self.performance_data[operation_name] = {
                'count': 0,
                'total_duration': 0,
                'avg_duration': 0,
                'max_duration': 0,
                'min_duration': float('inf'),
                'total_memory': 0,
                'avg_memory': 0,
                'total_cpu': 0,
                'avg_cpu': 0
            }
        
        data = self.performance_data[operation_name]
        data['count'] += 1
        data['total_duration'] += duration
        data['avg_duration'] = data['total_duration'] / data['count']
        data['max_duration'] = max(data['max_duration'], duration)
        data['min_duration'] = min(data['min_duration'], duration)
        
        if memory_usage > 0:
            data['total_memory'] += memory_usage
            data['avg_memory'] = data['total_memory'] / data['count']
        
        if cpu_usage > 0:
            data['total_cpu'] += cpu_usage
            data['avg_cpu'] = data['total_cpu'] / data['count']
        
        # Generate optimization suggestions
        self._analyze_performance(operation_name, data)
    
    def _analyze_performance(self, operation_name: str, data: Dict[str, Any]):
        """Analyze performance and generate optimization suggestions"""
        suggestions = []
        
        # Check for slow operations
        if data['avg_duration'] > 1000:  # More than 1 second
            suggestions.append({
                'operation': operation_name,
                'type': 'slow_operation',
                'message': f"Operation {operation_name} averages {data['avg_duration']:.2f}ms. Consider optimization.",
                'severity': 'high' if data['avg_duration'] > 5000 else 'medium'
            })
        
        # Check for high memory usage
        if data['avg_memory'] > 100:  # More than 100MB
            suggestions.append({
                'operation': operation_name,
                'type': 'high_memory',
                'message': f"Operation {operation_name} uses {data['avg_memory']:.2f}MB on average. Consider memory optimization.",
                'severity': 'high' if data['avg_memory'] > 500 else 'medium'
            })
        
        # Check for frequent operations that could benefit from caching
        if data['count'] > 100 and data['avg_duration'] > 100:
            suggestions.append({
                'operation': operation_name,
                'type': 'caching_opportunity',
                'message': f"Operation {operation_name} called {data['count']} times. Consider caching results.",
                'severity': 'low'
            })
        
        # Add new suggestions
        for suggestion in suggestions:
            if suggestion not in self.optimization_suggestions:
                self.optimization_suggestions.append(suggestion)
    
    def get_performance_report(self) -> Dict[str, Any]:
        """Get comprehensive performance report"""
        return {
            'operations': self.performance_data,
            'suggestions': self.optimization_suggestions,
            'summary': {
                'total_operations': len(self.performance_data),
                'total_suggestions': len(self.optimization_suggestions),
                'slowest_operation': max(
                    self.performance_data.items(),
                    key=lambda x: x[1]['avg_duration'],
                    default=('none', {'avg_duration': 0})
                )[0] if self.performance_data else 'none'
            }
        }

