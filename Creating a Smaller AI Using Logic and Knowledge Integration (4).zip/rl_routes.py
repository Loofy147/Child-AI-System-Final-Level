"""
API routes for Reinforcement Learning functionality
Provides endpoints for training, monitoring, and visualization
"""

from flask import Blueprint, request, jsonify, current_app
import json
import threading
import time
from datetime import datetime
from typing import Dict, Any, Optional

from rl_environment import KnowledgeLearningEnvironment
from rl_agent import RLAgent, RLConfig
from rl_trainer import RLTrainer, TrainingConfig
from logic_engine import LogicEngine
from knowledge_integration import KnowledgeIntegrator

rl_bp = Blueprint('rl', __name__)

# Global training state
training_thread = None
trainer_instance = None
training_status = {
    'is_training': False,
    'current_episode': 0,
    'start_time': None,
    'progress': 0.0
}

@rl_bp.route('/initialize', methods=['POST'])
def initialize_rl_system():
    """Initialize the RL system with configuration"""
    try:
        data = request.get_json() or {}
        
        # Get configuration
        rl_config = RLConfig(
            learning_rate=data.get('learning_rate', 0.1),
            discount_factor=data.get('discount_factor', 0.95),
            epsilon=data.get('epsilon', 1.0),
            epsilon_decay=data.get('epsilon_decay', 0.995),
            algorithm=data.get('algorithm', 'q_learning')
        )
        
        training_config = TrainingConfig(
            max_episodes=data.get('max_episodes', 1000),
            max_steps_per_episode=data.get('max_steps_per_episode', 100),
            evaluation_frequency=data.get('evaluation_frequency', 50)
        )
        
        # Initialize components
        logic_engine = LogicEngine()
        knowledge_integrator = KnowledgeIntegrator()
        environment = KnowledgeLearningEnvironment()
        agent = RLAgent(logic_engine, knowledge_integrator, rl_config)
        trainer = RLTrainer(agent, environment, training_config)
        
        # Store globally for other endpoints
        global trainer_instance
        trainer_instance = trainer
        
        return jsonify({
            'success': True,
            'message': 'RL system initialized successfully',
            'config': {
                'rl_config': {
                    'learning_rate': rl_config.learning_rate,
                    'discount_factor': rl_config.discount_factor,
                    'epsilon': rl_config.epsilon,
                    'algorithm': rl_config.algorithm
                },
                'training_config': {
                    'max_episodes': training_config.max_episodes,
                    'max_steps_per_episode': training_config.max_steps_per_episode,
                    'evaluation_frequency': training_config.evaluation_frequency
                }
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/start_training', methods=['POST'])
def start_training():
    """Start RL training in a background thread"""
    global training_thread, trainer_instance, training_status
    
    try:
        if training_status['is_training']:
            return jsonify({
                'success': False,
                'error': 'Training is already in progress'
            }), 400
        
        if trainer_instance is None:
            return jsonify({
                'success': False,
                'error': 'RL system not initialized. Call /initialize first.'
            }), 400
        
        data = request.get_json() or {}
        episodes = data.get('episodes', 100)
        
        # Update training status
        training_status.update({
            'is_training': True,
            'current_episode': 0,
            'start_time': datetime.utcnow().isoformat(),
            'progress': 0.0,
            'total_episodes': episodes
        })
        
        # Start training in background thread
        def training_worker():
            try:
                result = trainer_instance.train(episodes)
                training_status.update({
                    'is_training': False,
                    'completed': True,
                    'result': result
                })
            except Exception as e:
                training_status.update({
                    'is_training': False,
                    'error': str(e)
                })
        
        training_thread = threading.Thread(target=training_worker)
        training_thread.daemon = True
        training_thread.start()
        
        return jsonify({
            'success': True,
            'message': f'Training started for {episodes} episodes',
            'training_id': training_status['start_time']
        })
        
    except Exception as e:
        training_status['is_training'] = False
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/stop_training', methods=['POST'])
def stop_training():
    """Stop ongoing training"""
    global trainer_instance, training_status
    
    try:
        if not training_status['is_training']:
            return jsonify({
                'success': False,
                'error': 'No training in progress'
            }), 400
        
        if trainer_instance:
            trainer_instance.stop_training()
        
        training_status['is_training'] = False
        
        return jsonify({
            'success': True,
            'message': 'Training stop requested'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/training_status', methods=['GET'])
def get_training_status():
    """Get current training status and progress"""
    global trainer_instance, training_status
    
    try:
        if trainer_instance:
            # Update with latest trainer status
            trainer_status = trainer_instance.get_training_status()
            training_status.update(trainer_status)
            
            # Calculate progress
            if training_status.get('total_episodes', 0) > 0:
                progress = training_status.get('current_episode', 0) / training_status['total_episodes']
                training_status['progress'] = min(progress * 100, 100)
        
        return jsonify({
            'success': True,
            'status': training_status
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/performance_metrics', methods=['GET'])
def get_performance_metrics():
    """Get detailed performance metrics"""
    global trainer_instance
    
    try:
        if trainer_instance is None:
            return jsonify({
                'success': False,
                'error': 'RL system not initialized'
            }), 400
        
        # Get metrics from trainer
        current_metrics = trainer_instance.metrics.get_current_performance()
        learning_analysis = trainer_instance.metrics.analyze_learning_curve()
        agent_metrics = trainer_instance.agent.get_performance_metrics()
        
        return jsonify({
            'success': True,
            'metrics': {
                'current_performance': current_metrics,
                'learning_analysis': learning_analysis,
                'agent_metrics': agent_metrics,
                'evaluation_history': trainer_instance.evaluation_results[-5:] if trainer_instance.evaluation_results else []
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/learning_curve_data', methods=['GET'])
def get_learning_curve_data():
    """Get data for plotting learning curves"""
    global trainer_instance
    
    try:
        if trainer_instance is None:
            return jsonify({
                'success': False,
                'error': 'RL system not initialized'
            }), 400
        
        metrics = trainer_instance.metrics
        
        # Prepare data for visualization
        episodes = list(range(1, len(metrics.episode_rewards) + 1))
        
        # Calculate moving averages for smoother curves
        window_size = min(20, len(metrics.episode_rewards) // 10) if len(metrics.episode_rewards) > 20 else 1
        
        def moving_average(data, window):
            if len(data) < window:
                return data
            return [sum(data[i:i+window])/window for i in range(len(data)-window+1)]
        
        reward_ma = moving_average(metrics.episode_rewards, window_size)
        success_ma = moving_average(metrics.success_rates, window_size)
        efficiency_ma = moving_average(metrics.learning_efficiency, window_size)
        
        return jsonify({
            'success': True,
            'data': {
                'episodes': episodes,
                'raw_rewards': metrics.episode_rewards,
                'reward_moving_average': reward_ma,
                'success_rates': metrics.success_rates,
                'success_moving_average': success_ma,
                'learning_efficiency': metrics.learning_efficiency,
                'efficiency_moving_average': efficiency_ma,
                'exploration_rates': metrics.exploration_rates,
                'episode_lengths': metrics.episode_lengths,
                'window_size': window_size
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/agent_policy', methods=['GET'])
def get_agent_policy():
    """Get current agent policy information"""
    global trainer_instance
    
    try:
        if trainer_instance is None:
            return jsonify({
                'success': False,
                'error': 'RL system not initialized'
            }), 400
        
        policy_summary = trainer_instance.agent.get_policy_summary()
        
        # Get action distribution
        action_stats = trainer_instance.agent.action_statistics
        total_actions = sum(action_stats.values()) if action_stats else 1
        action_distribution = {
            action: count / total_actions 
            for action, count in action_stats.items()
        }
        
        return jsonify({
            'success': True,
            'policy': {
                'summary': policy_summary,
                'action_distribution': action_distribution,
                'current_epsilon': trainer_instance.agent.epsilon,
                'total_actions_taken': total_actions
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/evaluate_agent', methods=['POST'])
def evaluate_agent():
    """Run evaluation of the current agent"""
    global trainer_instance
    
    try:
        if trainer_instance is None:
            return jsonify({
                'success': False,
                'error': 'RL system not initialized'
            }), 400
        
        data = request.get_json() or {}
        num_episodes = data.get('episodes', 10)
        
        # Run evaluation
        evaluation_result = trainer_instance.evaluate(num_episodes)
        
        return jsonify({
            'success': True,
            'evaluation': evaluation_result
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/environment_info', methods=['GET'])
def get_environment_info():
    """Get information about the RL environment"""
    global trainer_instance
    
    try:
        if trainer_instance is None:
            return jsonify({
                'success': False,
                'error': 'RL system not initialized'
            }), 400
        
        environment = trainer_instance.environment
        
        # Get environment statistics
        env_stats = environment.get_statistics()
        
        # Get available scenarios
        scenarios_info = []
        for scenario in environment.scenarios:
            scenarios_info.append({
                'id': scenario['id'],
                'name': scenario['name'],
                'difficulty': scenario['difficulty'],
                'description': scenario['description'],
                'facts_count': len(scenario['facts']),
                'rules_count': len(scenario['rules']),
                'queries_count': len(scenario['queries'])
            })
        
        return jsonify({
            'success': True,
            'environment': {
                'statistics': env_stats,
                'scenarios': scenarios_info,
                'action_space': [action.value for action in environment.get_action_space()],
                'state_space_description': environment.get_state_space_description()
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/save_model', methods=['POST'])
def save_model():
    """Save the current trained model"""
    global trainer_instance
    
    try:
        if trainer_instance is None:
            return jsonify({
                'success': False,
                'error': 'RL system not initialized'
            }), 400
        
        data = request.get_json() or {}
        filename = data.get('filename', f'rl_model_{datetime.now().strftime("%Y%m%d_%H%M%S")}.pkl')
        
        # Save model
        trainer_instance.agent.save_model(filename)
        
        return jsonify({
            'success': True,
            'message': f'Model saved as {filename}'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/load_model', methods=['POST'])
def load_model():
    """Load a previously trained model"""
    global trainer_instance
    
    try:
        if trainer_instance is None:
            return jsonify({
                'success': False,
                'error': 'RL system not initialized'
            }), 400
        
        data = request.get_json() or {}
        filename = data.get('filename')
        
        if not filename:
            return jsonify({
                'success': False,
                'error': 'Filename is required'
            }), 400
        
        # Load model
        trainer_instance.agent.load_model(filename)
        
        return jsonify({
            'success': True,
            'message': f'Model loaded from {filename}'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/training_visualization', methods=['GET'])
def get_training_visualization():
    """Generate and return training visualization"""
    global trainer_instance
    
    try:
        if trainer_instance is None:
            return jsonify({
                'success': False,
                'error': 'RL system not initialized'
            }), 400
        
        # Generate plot
        plot_path = trainer_instance.plot_training_progress()
        
        return jsonify({
            'success': True,
            'visualization_path': plot_path,
            'message': 'Training visualization generated'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/reset_training', methods=['POST'])
def reset_training():
    """Reset the training system"""
    global trainer_instance, training_status
    
    try:
        if training_status['is_training']:
            return jsonify({
                'success': False,
                'error': 'Cannot reset while training is in progress'
            }), 400
        
        # Reset training status
        training_status = {
            'is_training': False,
            'current_episode': 0,
            'start_time': None,
            'progress': 0.0
        }
        
        # Reinitialize if needed
        if trainer_instance:
            trainer_instance.current_episode = 0
            trainer_instance.total_steps = 0
            trainer_instance.metrics = trainer_instance.__class__.PerformanceMetrics()
            trainer_instance.evaluation_results = []
            trainer_instance.best_performance = 0.0
            trainer_instance.episodes_without_improvement = 0
        
        return jsonify({
            'success': True,
            'message': 'Training system reset successfully'
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@rl_bp.route('/config', methods=['GET', 'POST'])
def handle_config():
    """Get or update RL configuration"""
    global trainer_instance
    
    try:
        if request.method == 'GET':
            if trainer_instance is None:
                return jsonify({
                    'success': False,
                    'error': 'RL system not initialized'
                }), 400
            
            return jsonify({
                'success': True,
                'config': {
                    'agent_config': {
                        'learning_rate': trainer_instance.agent.config.learning_rate,
                        'discount_factor': trainer_instance.agent.config.discount_factor,
                        'epsilon': trainer_instance.agent.epsilon,
                        'algorithm': trainer_instance.agent.config.algorithm
                    },
                    'training_config': {
                        'max_episodes': trainer_instance.config.max_episodes,
                        'max_steps_per_episode': trainer_instance.config.max_steps_per_episode,
                        'evaluation_frequency': trainer_instance.config.evaluation_frequency
                    }
                }
            })
        
        elif request.method == 'POST':
            if training_status['is_training']:
                return jsonify({
                    'success': False,
                    'error': 'Cannot update config while training is in progress'
                }), 400
            
            data = request.get_json() or {}
            
            # Update agent config
            if 'agent_config' in data and trainer_instance:
                agent_config = data['agent_config']
                if 'learning_rate' in agent_config:
                    trainer_instance.agent.config.learning_rate = agent_config['learning_rate']
                if 'discount_factor' in agent_config:
                    trainer_instance.agent.config.discount_factor = agent_config['discount_factor']
                if 'epsilon' in agent_config:
                    trainer_instance.agent.epsilon = agent_config['epsilon']
            
            # Update training config
            if 'training_config' in data and trainer_instance:
                training_config = data['training_config']
                if 'max_episodes' in training_config:
                    trainer_instance.config.max_episodes = training_config['max_episodes']
                if 'max_steps_per_episode' in training_config:
                    trainer_instance.config.max_steps_per_episode = training_config['max_steps_per_episode']
                if 'evaluation_frequency' in training_config:
                    trainer_instance.config.evaluation_frequency = training_config['evaluation_frequency']
            
            return jsonify({
                'success': True,
                'message': 'Configuration updated successfully'
            })
    
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

