"""
Monitoring and observability module for Child AI system
Implements structured logging, metrics collection, and health monitoring
"""

import logging
import json
import time
import psutil
import sqlite3
from datetime import datetime, timedelta
from functools import wraps
from flask import request, g
import threading
import os

class StructuredLogger:
    """Structured logging with JSON format and multiple handlers"""
    
    def __init__(self, name="child_ai", log_level=logging.INFO):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(log_level)
        
        # Prevent duplicate handlers
        if not self.logger.handlers:
            self.setup_handlers()
    
    def setup_handlers(self):
        """Setup file and console handlers with JSON formatting"""
        
        # Create logs directory
        os.makedirs("logs", exist_ok=True)
        
        # JSON formatter
        class JSONFormatter(logging.Formatter):
            def format(self, record):
                log_entry = {
                    'timestamp': datetime.utcnow().isoformat(),
                    'level': record.levelname,
                    'logger': record.name,
                    'message': record.getMessage(),
                    'module': record.module,
                    'function': record.funcName,
                    'line': record.lineno
                }
                
                # Add extra fields if present
                if hasattr(record, 'user_id'):
                    log_entry['user_id'] = record.user_id
                if hasattr(record, 'request_id'):
                    log_entry['request_id'] = record.request_id
                if hasattr(record, 'duration'):
                    log_entry['duration'] = record.duration
                if hasattr(record, 'status_code'):
                    log_entry['status_code'] = record.status_code
                
                return json.dumps(log_entry)
        
        # File handler for all logs
        file_handler = logging.FileHandler('logs/child_ai.log')
        file_handler.setFormatter(JSONFormatter())
        self.logger.addHandler(file_handler)
        
        # Error file handler
        error_handler = logging.FileHandler('logs/child_ai_errors.log')
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(JSONFormatter())
        self.logger.addHandler(error_handler)
        
        # Console handler for development
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        ))
        self.logger.addHandler(console_handler)
    
    def info(self, message, **kwargs):
        """Log info message with extra context"""
        extra = {k: v for k, v in kwargs.items()}
        self.logger.info(message, extra=extra)
    
    def error(self, message, **kwargs):
        """Log error message with extra context"""
        extra = {k: v for k, v in kwargs.items()}
        self.logger.error(message, extra=extra)
    
    def warning(self, message, **kwargs):
        """Log warning message with extra context"""
        extra = {k: v for k, v in kwargs.items()}
        self.logger.warning(message, extra=extra)
    
    def debug(self, message, **kwargs):
        """Log debug message with extra context"""
        extra = {k: v for k, v in kwargs.items()}
        self.logger.debug(message, extra=extra)

class MetricsCollector:
    """Collects and stores system and application metrics"""
    
    def __init__(self, db_path="src/database/metrics.db"):
        self.db_path = db_path
        self.init_database()
        self.start_background_collection()
    
    def init_database(self):
        """Initialize metrics database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # System metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS system_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                cpu_percent REAL,
                memory_percent REAL,
                memory_used_mb REAL,
                disk_percent REAL,
                disk_used_gb REAL
            )
        ''')
        
        # Application metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS app_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                endpoint TEXT,
                method TEXT,
                status_code INTEGER,
                response_time_ms REAL,
                user_id INTEGER,
                request_size_bytes INTEGER,
                response_size_bytes INTEGER
            )
        ''')
        
        # AI operation metrics
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ai_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                operation_type TEXT,
                duration_ms REAL,
                success BOOLEAN,
                facts_processed INTEGER,
                rules_applied INTEGER,
                inferences_made INTEGER,
                user_id INTEGER
            )
        ''')
        
        # Error tracking
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS error_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                error_type TEXT,
                error_message TEXT,
                stack_trace TEXT,
                endpoint TEXT,
                user_id INTEGER,
                request_data TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def collect_system_metrics(self):
        """Collect current system metrics"""
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO system_metrics 
                (cpu_percent, memory_percent, memory_used_mb, disk_percent, disk_used_gb)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                cpu_percent,
                memory.percent,
                memory.used / (1024 * 1024),  # Convert to MB
                disk.percent,
                disk.used / (1024 * 1024 * 1024)  # Convert to GB
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger = StructuredLogger()
            logger.error(f"Failed to collect system metrics: {str(e)}")
    
    def record_request_metric(self, endpoint, method, status_code, response_time, 
                            user_id=None, request_size=0, response_size=0):
        """Record HTTP request metrics"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO app_metrics 
                (endpoint, method, status_code, response_time_ms, user_id, 
                 request_size_bytes, response_size_bytes)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (endpoint, method, status_code, response_time, user_id, 
                  request_size, response_size))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger = StructuredLogger()
            logger.error(f"Failed to record request metric: {str(e)}")
    
    def record_ai_operation(self, operation_type, duration, success, 
                          facts_processed=0, rules_applied=0, inferences_made=0, user_id=None):
        """Record AI operation metrics"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO ai_metrics 
                (operation_type, duration_ms, success, facts_processed, 
                 rules_applied, inferences_made, user_id)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (operation_type, duration, success, facts_processed, 
                  rules_applied, inferences_made, user_id))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger = StructuredLogger()
            logger.error(f"Failed to record AI operation metric: {str(e)}")
    
    def record_error(self, error_type, error_message, stack_trace=None, 
                    endpoint=None, user_id=None, request_data=None):
        """Record error occurrence"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO error_logs 
                (error_type, error_message, stack_trace, endpoint, user_id, request_data)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (error_type, error_message, stack_trace, endpoint, user_id, 
                  json.dumps(request_data) if request_data else None))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            logger = StructuredLogger()
            logger.error(f"Failed to record error: {str(e)}")
    
    def get_metrics_summary(self, hours=24):
        """Get metrics summary for the last N hours"""
        try:
            since = datetime.utcnow() - timedelta(hours=hours)
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # System metrics summary
            cursor.execute('''
                SELECT 
                    AVG(cpu_percent) as avg_cpu,
                    MAX(cpu_percent) as max_cpu,
                    AVG(memory_percent) as avg_memory,
                    MAX(memory_percent) as max_memory,
                    AVG(disk_percent) as avg_disk
                FROM system_metrics 
                WHERE timestamp > ?
            ''', (since,))
            
            system_stats = cursor.fetchone()
            
            # Request metrics summary
            cursor.execute('''
                SELECT 
                    COUNT(*) as total_requests,
                    AVG(response_time_ms) as avg_response_time,
                    MAX(response_time_ms) as max_response_time,
                    COUNT(CASE WHEN status_code >= 400 THEN 1 END) as error_count
                FROM app_metrics 
                WHERE timestamp > ?
            ''', (since,))
            
            request_stats = cursor.fetchone()
            
            # AI operation summary
            cursor.execute('''
                SELECT 
                    COUNT(*) as total_operations,
                    AVG(duration_ms) as avg_duration,
                    SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) as successful_operations,
                    SUM(facts_processed) as total_facts_processed,
                    SUM(inferences_made) as total_inferences
                FROM ai_metrics 
                WHERE timestamp > ?
            ''', (since,))
            
            ai_stats = cursor.fetchone()
            
            conn.close()
            
            return {
                'system': {
                    'avg_cpu_percent': round(system_stats[0] or 0, 2),
                    'max_cpu_percent': round(system_stats[1] or 0, 2),
                    'avg_memory_percent': round(system_stats[2] or 0, 2),
                    'max_memory_percent': round(system_stats[3] or 0, 2),
                    'avg_disk_percent': round(system_stats[4] or 0, 2)
                },
                'requests': {
                    'total_requests': request_stats[0] or 0,
                    'avg_response_time_ms': round(request_stats[1] or 0, 2),
                    'max_response_time_ms': round(request_stats[2] or 0, 2),
                    'error_count': request_stats[3] or 0,
                    'error_rate': round((request_stats[3] or 0) / max(request_stats[0] or 1, 1) * 100, 2)
                },
                'ai_operations': {
                    'total_operations': ai_stats[0] or 0,
                    'avg_duration_ms': round(ai_stats[1] or 0, 2),
                    'successful_operations': ai_stats[2] or 0,
                    'success_rate': round((ai_stats[2] or 0) / max(ai_stats[0] or 1, 1) * 100, 2),
                    'total_facts_processed': ai_stats[3] or 0,
                    'total_inferences': ai_stats[4] or 0
                }
            }
            
        except Exception as e:
            logger = StructuredLogger()
            logger.error(f"Failed to get metrics summary: {str(e)}")
            return {}
    
    def start_background_collection(self):
        """Start background thread for periodic metrics collection"""
        def collect_periodically():
            while True:
                self.collect_system_metrics()
                time.sleep(60)  # Collect every minute
        
        thread = threading.Thread(target=collect_periodically, daemon=True)
        thread.start()

class HealthChecker:
    """Health monitoring and status checking"""
    
    def __init__(self):
        self.checks = {}
        self.register_default_checks()
    
    def register_check(self, name, check_function):
        """Register a health check function"""
        self.checks[name] = check_function
    
    def register_default_checks(self):
        """Register default system health checks"""
        
        def database_check():
            """Check database connectivity"""
            try:
                conn = sqlite3.connect("src/database/app.db")
                cursor = conn.cursor()
                cursor.execute("SELECT 1")
                conn.close()
                return {'status': 'healthy', 'message': 'Database accessible'}
            except Exception as e:
                return {'status': 'unhealthy', 'message': f'Database error: {str(e)}'}
        
        def memory_check():
            """Check memory usage"""
            try:
                memory = psutil.virtual_memory()
                if memory.percent > 90:
                    return {'status': 'warning', 'message': f'High memory usage: {memory.percent}%'}
                elif memory.percent > 95:
                    return {'status': 'unhealthy', 'message': f'Critical memory usage: {memory.percent}%'}
                else:
                    return {'status': 'healthy', 'message': f'Memory usage: {memory.percent}%'}
            except Exception as e:
                return {'status': 'unhealthy', 'message': f'Memory check failed: {str(e)}'}
        
        def disk_check():
            """Check disk usage"""
            try:
                disk = psutil.disk_usage('/')
                if disk.percent > 85:
                    return {'status': 'warning', 'message': f'High disk usage: {disk.percent}%'}
                elif disk.percent > 95:
                    return {'status': 'unhealthy', 'message': f'Critical disk usage: {disk.percent}%'}
                else:
                    return {'status': 'healthy', 'message': f'Disk usage: {disk.percent}%'}
            except Exception as e:
                return {'status': 'unhealthy', 'message': f'Disk check failed: {str(e)}'}
        
        self.register_check('database', database_check)
        self.register_check('memory', memory_check)
        self.register_check('disk', disk_check)
    
    def run_all_checks(self):
        """Run all registered health checks"""
        results = {}
        overall_status = 'healthy'
        
        for name, check_func in self.checks.items():
            try:
                result = check_func()
                results[name] = result
                
                if result['status'] == 'unhealthy':
                    overall_status = 'unhealthy'
                elif result['status'] == 'warning' and overall_status == 'healthy':
                    overall_status = 'warning'
                    
            except Exception as e:
                results[name] = {
                    'status': 'unhealthy',
                    'message': f'Check failed: {str(e)}'
                }
                overall_status = 'unhealthy'
        
        return {
            'overall_status': overall_status,
            'timestamp': datetime.utcnow().isoformat(),
            'checks': results
        }

# Monitoring decorators
def monitor_performance(operation_type=None):
    """Decorator to monitor function performance"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            start_time = time.time()
            success = True
            error = None
            
            try:
                result = f(*args, **kwargs)
                return result
            except Exception as e:
                success = False
                error = e
                raise
            finally:
                duration = (time.time() - start_time) * 1000  # Convert to milliseconds
                
                # Record metrics if metrics collector is available
                if hasattr(g, 'metrics_collector'):
                    user_id = getattr(request, 'current_user', {}).get('user_id')
                    g.metrics_collector.record_ai_operation(
                        operation_type or f.__name__,
                        duration,
                        success,
                        user_id=user_id
                    )
                
                # Log performance
                logger = StructuredLogger()
                logger.info(
                    f"Operation {operation_type or f.__name__} completed",
                    duration=duration,
                    success=success,
                    error=str(error) if error else None
                )
        
        return decorated_function
    return decorator

def log_requests(f):
    """Decorator to log HTTP requests"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        start_time = time.time()
        
        # Log request start
        logger = StructuredLogger()
        request_id = f"{int(time.time())}-{id(request)}"
        g.request_id = request_id
        
        logger.info(
            f"Request started: {request.method} {request.path}",
            request_id=request_id,
            method=request.method,
            path=request.path,
            user_agent=request.headers.get('User-Agent'),
            ip_address=request.remote_addr
        )
        
        try:
            response = f(*args, **kwargs)
            status_code = getattr(response, 'status_code', 200)
            
            # Calculate response time
            response_time = (time.time() - start_time) * 1000
            
            # Record metrics
            if hasattr(g, 'metrics_collector'):
                user_id = getattr(request, 'current_user', {}).get('user_id')
                g.metrics_collector.record_request_metric(
                    request.endpoint,
                    request.method,
                    status_code,
                    response_time,
                    user_id=user_id
                )
            
            # Log request completion
            logger.info(
                f"Request completed: {request.method} {request.path}",
                request_id=request_id,
                status_code=status_code,
                duration=response_time
            )
            
            return response
            
        except Exception as e:
            response_time = (time.time() - start_time) * 1000
            
            # Record error metrics
            if hasattr(g, 'metrics_collector'):
                user_id = getattr(request, 'current_user', {}).get('user_id')
                g.metrics_collector.record_request_metric(
                    request.endpoint,
                    request.method,
                    500,
                    response_time,
                    user_id=user_id
                )
                
                g.metrics_collector.record_error(
                    type(e).__name__,
                    str(e),
                    endpoint=request.endpoint,
                    user_id=user_id,
                    request_data={
                        'method': request.method,
                        'path': request.path,
                        'args': dict(request.args),
                        'json': request.get_json(silent=True)
                    }
                )
            
            # Log error
            logger.error(
                f"Request failed: {request.method} {request.path}",
                request_id=request_id,
                error=str(e),
                duration=response_time
            )
            
            raise
    
    return decorated_function

