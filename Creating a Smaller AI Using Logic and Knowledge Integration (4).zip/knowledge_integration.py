"""
Knowledge Integration Module for Child AI
This module handles the integration of knowledge from various sources.
"""

import json
import re
import requests
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from abc import ABC, abstractmethod
import sqlite3
import os


@dataclass
class KnowledgeSource:
    """Represents a knowledge source."""
    name: str
    source_type: str  # 'api', 'database', 'file', 'web'
    connection_info: Dict[str, Any]
    is_active: bool = True


class KnowledgeExtractor(ABC):
    """Abstract base class for knowledge extractors."""
    
    @abstractmethod
    def extract(self, data: Any) -> List[Tuple[str, str]]:
        """Extract knowledge facts from data. Returns list of (fact, confidence) tuples."""
        pass


class TextKnowledgeExtractor(KnowledgeExtractor):
    """Extracts knowledge from text using simple pattern matching."""
    
    def __init__(self):
        # Simple patterns for extracting facts from text
        self.patterns = [
            (r'(\w+) is a (\w+)', r'\1 is \2'),
            (r'(\w+) are (\w+)', r'\1 are \2'),
            (r'All (\w+) are (\w+)', r'All \1 are \2'),
            (r'(\w+) has (\w+)', r'\1 has \2'),
            (r'(\w+) can (\w+)', r'\1 can \2'),
            (r'(\w+) lives in (\w+)', r'\1 lives in \2'),
            (r'(\w+) belongs to (\w+)', r'\1 belongs to \2'),
        ]
    
    def extract(self, text: str) -> List[Tuple[str, str]]:
        """Extract facts from text."""
        facts = []
        sentences = text.split('.')
        
        for sentence in sentences:
            sentence = sentence.strip()
            for pattern, template in self.patterns:
                matches = re.findall(pattern, sentence, re.IGNORECASE)
                for match in matches:
                    if isinstance(match, tuple):
                        fact = template
                        for i, group in enumerate(match):
                            fact = fact.replace(f'\\{i+1}', group)
                        facts.append((fact, "0.8"))  # Default confidence
                    else:
                        fact = template.replace('\\1', match)
                        facts.append((fact, "0.8"))
        
        return facts


class StructuredDataExtractor(KnowledgeExtractor):
    """Extracts knowledge from structured data (JSON, CSV, etc.)."""
    
    def extract(self, data: Dict[str, Any]) -> List[Tuple[str, str]]:
        """Extract facts from structured data."""
        facts = []
        
        def extract_from_dict(obj: Dict[str, Any], prefix: str = ""):
            for key, value in obj.items():
                if isinstance(value, dict):
                    extract_from_dict(value, f"{prefix}{key}.")
                elif isinstance(value, list):
                    for i, item in enumerate(value):
                        if isinstance(item, dict):
                            extract_from_dict(item, f"{prefix}{key}[{i}].")
                        else:
                            fact = f"{prefix}{key} contains {item}"
                            facts.append((fact, "0.9"))
                else:
                    fact = f"{prefix}{key} is {value}"
                    facts.append((fact, "0.9"))
        
        if isinstance(data, dict):
            extract_from_dict(data)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                if isinstance(item, dict):
                    extract_from_dict(item, f"item[{i}].")
                else:
                    fact = f"list contains {item}"
                    facts.append((fact, "0.9"))
        
        return facts


class KnowledgeIntegrator:
    """Main class for integrating knowledge from various sources."""
    
    def __init__(self, logic_engine):
        self.logic_engine = logic_engine
        self.sources: Dict[str, KnowledgeSource] = {}
        self.extractors: Dict[str, KnowledgeExtractor] = {
            'text': TextKnowledgeExtractor(),
            'structured': StructuredDataExtractor()
        }
        self.integration_log: List[Dict[str, Any]] = []
    
    def add_source(self, source: KnowledgeSource):
        """Add a knowledge source."""
        self.sources[source.name] = source
    
    def remove_source(self, source_name: str):
        """Remove a knowledge source."""
        if source_name in self.sources:
            del self.sources[source_name]
    
    def integrate_text(self, text: str, source_name: str = "manual_input") -> int:
        """Integrate knowledge from text."""
        extractor = self.extractors['text']
        facts = extractor.extract(text)
        
        integrated_count = 0
        for fact, confidence in facts:
            # Add fact to logic engine
            self.logic_engine.add_fact(fact)
            integrated_count += 1
            
            # Log the integration
            self.integration_log.append({
                'source': source_name,
                'fact': fact,
                'confidence': confidence,
                'type': 'text_extraction'
            })
        
        return integrated_count
    
    def integrate_structured_data(self, data: Dict[str, Any], source_name: str = "structured_input") -> int:
        """Integrate knowledge from structured data."""
        extractor = self.extractors['structured']
        facts = extractor.extract(data)
        
        integrated_count = 0
        for fact, confidence in facts:
            # Add fact to logic engine
            self.logic_engine.add_fact(fact)
            integrated_count += 1
            
            # Log the integration
            self.integration_log.append({
                'source': source_name,
                'fact': fact,
                'confidence': confidence,
                'type': 'structured_data'
            })
        
        return integrated_count
    
    def integrate_from_api(self, api_url: str, source_name: str) -> int:
        """Integrate knowledge from an API endpoint."""
        try:
            response = requests.get(api_url, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            return self.integrate_structured_data(data, source_name)
        
        except requests.RequestException as e:
            self.integration_log.append({
                'source': source_name,
                'error': str(e),
                'type': 'api_error'
            })
            return 0
    
    def integrate_from_file(self, file_path: str, source_name: str) -> int:
        """Integrate knowledge from a file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read()
            
            # Determine file type and extract accordingly
            if file_path.endswith('.json'):
                data = json.loads(content)
                return self.integrate_structured_data(data, source_name)
            else:
                # Treat as text
                return self.integrate_text(content, source_name)
        
        except Exception as e:
            self.integration_log.append({
                'source': source_name,
                'error': str(e),
                'type': 'file_error'
            })
            return 0
    
    def resolve_conflicts(self) -> List[Dict[str, Any]]:
        """Identify and resolve conflicts in the knowledge base."""
        conflicts = []
        
        # Simple conflict detection: look for contradictory facts
        all_facts = self.logic_engine.get_all_facts()
        
        for fact in all_facts:
            # Look for negation patterns
            if fact.startswith('¬'):
                positive_fact = fact[1:]
                if positive_fact in all_facts:
                    conflicts.append({
                        'type': 'contradiction',
                        'fact1': fact,
                        'fact2': positive_fact,
                        'resolution': 'manual_review_required'
                    })
            else:
                negative_fact = f'¬{fact}'
                if negative_fact in all_facts:
                    conflicts.append({
                        'type': 'contradiction',
                        'fact1': fact,
                        'fact2': negative_fact,
                        'resolution': 'manual_review_required'
                    })
        
        return conflicts
    
    def get_integration_statistics(self) -> Dict[str, Any]:
        """Get statistics about knowledge integration."""
        total_integrations = len(self.integration_log)
        successful_integrations = len([log for log in self.integration_log if 'error' not in log])
        failed_integrations = total_integrations - successful_integrations
        
        source_stats = {}
        for log in self.integration_log:
            source = log['source']
            if source not in source_stats:
                source_stats[source] = {'successful': 0, 'failed': 0}
            
            if 'error' in log:
                source_stats[source]['failed'] += 1
            else:
                source_stats[source]['successful'] += 1
        
        return {
            'total_integrations': total_integrations,
            'successful_integrations': successful_integrations,
            'failed_integrations': failed_integrations,
            'source_statistics': source_stats,
            'active_sources': len([s for s in self.sources.values() if s.is_active])
        }
    
    def get_recent_integrations(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get the most recent knowledge integrations."""
        return self.integration_log[-limit:] if self.integration_log else []


# Example usage and testing
if __name__ == "__main__":
    from logic_engine import LogicEngine
    
    # Create logic engine and knowledge integrator
    engine = LogicEngine()
    integrator = KnowledgeIntegrator(engine)
    
    # Test text integration
    sample_text = """
    Socrates is a philosopher. Plato is a student of Socrates.
    All philosophers are thinkers. Socrates lives in Athens.
    Dogs are animals. All animals are living beings.
    """
    
    print("Integrating text knowledge...")
    count = integrator.integrate_text(sample_text)
    print(f"Integrated {count} facts from text.")
    
    # Test structured data integration
    sample_data = {
        "person": {
            "name": "Aristotle",
            "profession": "philosopher",
            "teacher": "Plato",
            "location": "Athens"
        },
        "facts": [
            "Logic is important",
            "Reasoning helps understanding"
        ]
    }
    
    print("\nIntegrating structured data...")
    count = integrator.integrate_structured_data(sample_data)
    print(f"Integrated {count} facts from structured data.")
    
    # Show all facts
    print("\nAll facts in knowledge base:")
    for fact in engine.get_all_facts():
        print(f"  - {fact}")
    
    # Show integration statistics
    print("\nIntegration Statistics:")
    stats = integrator.get_integration_statistics()
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    # Show recent integrations
    print("\nRecent Integrations:")
    for integration in integrator.get_recent_integrations(5):
        print(f"  Source: {integration['source']}, Fact: {integration.get('fact', 'N/A')}")

