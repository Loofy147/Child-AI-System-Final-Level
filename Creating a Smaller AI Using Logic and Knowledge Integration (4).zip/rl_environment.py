"""
Reinforcement Learning Environment for Child AI
A simulated environment where the Child AI can learn through trial and error
"""

import numpy as np
import random
import json
from typing import Dict, List, Tuple, Any, Optional
from dataclasses import dataclass
from enum import Enum
import logging
from datetime import datetime

class ActionType(Enum):
    """Types of actions the AI can take in the environment"""
    QUERY_KNOWLEDGE = "query_knowledge"
    ADD_FACT = "add_fact"
    ADD_RULE = "add_rule"
    MAKE_INFERENCE = "make_inference"
    LEARN_FROM_FEEDBACK = "learn_from_feedback"
    EXPLORE_TOPIC = "explore_topic"

class EnvironmentState(Enum):
    """States of the learning environment"""
    INITIAL = "initial"
    LEARNING = "learning"
    TESTING = "testing"
    EVALUATION = "evaluation"
    COMPLETE = "complete"

@dataclass
class Action:
    """Represents an action taken by the AI agent"""
    action_type: ActionType
    parameters: Dict[str, Any]
    timestamp: datetime
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'action_type': self.action_type.value,
            'parameters': self.parameters,
            'timestamp': self.timestamp.isoformat()
        }

@dataclass
class Observation:
    """Represents an observation from the environment"""
    state: Dict[str, Any]
    reward: float
    done: bool
    info: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'state': self.state,
            'reward': self.reward,
            'done': self.done,
            'info': self.info
        }

class KnowledgeLearningEnvironment:
    """
    A simulated environment for training the Child AI through reinforcement learning.
    The environment presents various knowledge-based challenges and provides rewards
    based on the AI's performance in reasoning, learning, and knowledge integration.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the RL environment"""
        self.config = config or self._default_config()
        self.logger = logging.getLogger(__name__)
        
        # Environment state
        self.current_state = EnvironmentState.INITIAL
        self.episode_count = 0
        self.step_count = 0
        self.total_reward = 0.0
        
        # Knowledge base for the environment
        self.environment_facts = set()
        self.environment_rules = set()
        self.ground_truth = {}
        
        # Agent's knowledge state (what the AI has learned)
        self.agent_facts = set()
        self.agent_rules = set()
        self.agent_performance_history = []
        
        # Scenarios and challenges
        self.scenarios = self._initialize_scenarios()
        self.current_scenario = None
        self.scenario_progress = {}
        
        # Reward tracking
        self.reward_history = []
        self.action_history = []
        
        # Initialize environment
        self._reset_environment()
    
    def _default_config(self) -> Dict[str, Any]:
        """Default configuration for the environment"""
        return {
            'max_steps_per_episode': 100,
            'max_episodes': 1000,
            'reward_scale': 1.0,
            'exploration_bonus': 0.1,
            'learning_rate_bonus': 0.2,
            'accuracy_weight': 0.5,
            'efficiency_weight': 0.3,
            'creativity_weight': 0.2,
            'scenario_difficulty_progression': True,
            'enable_curriculum_learning': True
        }
    
    def _initialize_scenarios(self) -> List[Dict[str, Any]]:
        """Initialize learning scenarios of varying difficulty"""
        scenarios = [
            # Beginner scenarios
            {
                'id': 'basic_facts',
                'name': 'Basic Fact Learning',
                'difficulty': 1,
                'description': 'Learn basic facts about objects and their properties',
                'facts': [
                    'Bird(sparrow)', 'Bird(eagle)', 'Bird(penguin)',
                    'CanFly(sparrow)', 'CanFly(eagle)', '¬CanFly(penguin)',
                    'Animal(sparrow)', 'Animal(eagle)', 'Animal(penguin)'
                ],
                'rules': [
                    'Bird(X) → Animal(X)',
                    'Bird(X) ∧ ¬Penguin(X) → CanFly(X)'
                ],
                'queries': [
                    'Animal(sparrow)?',
                    'CanFly(eagle)?',
                    'CanFly(penguin)?'
                ],
                'expected_answers': [True, True, False]
            },
            {
                'id': 'family_relations',
                'name': 'Family Relationships',
                'difficulty': 2,
                'description': 'Learn and reason about family relationships',
                'facts': [
                    'Parent(john, mary)', 'Parent(john, tom)',
                    'Parent(mary, alice)', 'Parent(tom, bob)',
                    'Male(john)', 'Male(tom)', 'Male(bob)',
                    'Female(mary)', 'Female(alice)'
                ],
                'rules': [
                    'Parent(X, Y) ∧ Parent(Y, Z) → Grandparent(X, Z)',
                    'Parent(X, Y) ∧ Male(X) → Father(X, Y)',
                    'Parent(X, Y) ∧ Female(X) → Mother(X, Y)',
                    'Parent(X, Y) ∧ Parent(X, Z) ∧ Y≠Z → Sibling(Y, Z)'
                ],
                'queries': [
                    'Grandparent(john, alice)?',
                    'Father(john, mary)?',
                    'Sibling(mary, tom)?'
                ],
                'expected_answers': [True, True, True]
            },
            # Intermediate scenarios
            {
                'id': 'mathematical_reasoning',
                'name': 'Mathematical Reasoning',
                'difficulty': 3,
                'description': 'Learn mathematical concepts and relationships',
                'facts': [
                    'Number(1)', 'Number(2)', 'Number(3)', 'Number(4)',
                    'Even(2)', 'Even(4)', 'Odd(1)', 'Odd(3)',
                    'Prime(2)', 'Prime(3)', 'Composite(4)'
                ],
                'rules': [
                    'Even(X) ∧ X>2 → ¬Prime(X)',
                    'Number(X) ∧ ¬Even(X) → Odd(X)',
                    'Prime(X) → Number(X)',
                    'Composite(X) → Number(X)'
                ],
                'queries': [
                    'Prime(4)?',
                    'Odd(2)?',
                    'Number(3)?'
                ],
                'expected_answers': [False, False, True]
            },
            # Advanced scenarios
            {
                'id': 'complex_reasoning',
                'name': 'Complex Multi-Step Reasoning',
                'difficulty': 4,
                'description': 'Complex reasoning requiring multiple inference steps',
                'facts': [
                    'Student(alice)', 'Student(bob)', 'Course(math)', 'Course(physics)',
                    'Enrolled(alice, math)', 'Enrolled(bob, physics)',
                    'Difficult(math)', 'Difficult(physics)',
                    'Smart(alice)', 'Hardworking(bob)'
                ],
                'rules': [
                    'Student(X) ∧ Enrolled(X, Y) ∧ Difficult(Y) ∧ Smart(X) → WillPass(X, Y)',
                    'Student(X) ∧ Enrolled(X, Y) ∧ Difficult(Y) ∧ Hardworking(X) → WillPass(X, Y)',
                    'WillPass(X, Y) → Success(X)',
                    'Success(X) ∧ Student(X) → ProudParents(X)'
                ],
                'queries': [
                    'WillPass(alice, math)?',
                    'Success(bob)?',
                    'ProudParents(alice)?'
                ],
                'expected_answers': [True, True, True]
            }
        ]
        return scenarios
    
    def reset(self) -> Dict[str, Any]:
        """Reset the environment for a new episode"""
        self.episode_count += 1
        self.step_count = 0
        self.total_reward = 0.0
        self.current_state = EnvironmentState.INITIAL
        
        # Select scenario based on curriculum learning
        if self.config['enable_curriculum_learning']:
            self.current_scenario = self._select_curriculum_scenario()
        else:
            self.current_scenario = random.choice(self.scenarios)
        
        # Reset agent's knowledge for this episode
        self.agent_facts = set()
        self.agent_rules = set()
        
        # Initialize environment knowledge
        self._load_scenario_knowledge()
        
        # Clear history for this episode
        self.reward_history = []
        self.action_history = []
        
        self.logger.info(f"Episode {self.episode_count} started with scenario: {self.current_scenario['name']}")
        
        return self._get_current_state()
    
    def _select_curriculum_scenario(self) -> Dict[str, Any]:
        """Select scenario based on curriculum learning progression"""
        # Calculate agent's current performance level
        if len(self.agent_performance_history) < 5:
            # Start with easiest scenarios
            available_scenarios = [s for s in self.scenarios if s['difficulty'] == 1]
        else:
            # Calculate average performance over last 10 episodes
            recent_performance = np.mean(self.agent_performance_history[-10:])
            
            if recent_performance > 0.8:
                # High performance, increase difficulty
                max_difficulty = min(4, max([s['difficulty'] for s in self.scenarios]))
                available_scenarios = [s for s in self.scenarios if s['difficulty'] <= max_difficulty]
            elif recent_performance > 0.6:
                # Medium performance, maintain current level
                current_difficulty = 2
                available_scenarios = [s for s in self.scenarios if s['difficulty'] <= current_difficulty + 1]
            else:
                # Low performance, use easier scenarios
                available_scenarios = [s for s in self.scenarios if s['difficulty'] <= 2]
        
        return random.choice(available_scenarios)
    
    def _load_scenario_knowledge(self):
        """Load knowledge for the current scenario"""
        if not self.current_scenario:
            return
        
        # Load ground truth facts and rules
        self.environment_facts = set(self.current_scenario['facts'])
        self.environment_rules = set(self.current_scenario['rules'])
        
        # Store expected answers for evaluation
        self.ground_truth = {
            query: answer for query, answer in 
            zip(self.current_scenario['queries'], self.current_scenario['expected_answers'])
        }
    
    def step(self, action: Action) -> Observation:
        """Execute an action and return the resulting observation"""
        self.step_count += 1
        self.action_history.append(action)
        
        # Calculate reward for this action
        reward = self._calculate_reward(action)
        self.total_reward += reward
        self.reward_history.append(reward)
        
        # Update environment state based on action
        self._update_environment_state(action)
        
        # Check if episode is done
        done = self._is_episode_done()
        
        # Prepare observation
        observation = Observation(
            state=self._get_current_state(),
            reward=reward,
            done=done,
            info=self._get_info()
        )
        
        if done:
            self._finalize_episode()
        
        return observation
    
    def _calculate_reward(self, action: Action) -> float:
        """Calculate reward for the given action"""
        base_reward = 0.0
        
        if action.action_type == ActionType.ADD_FACT:
            # Reward for adding correct facts
            fact = action.parameters.get('fact', '')
            if fact in self.environment_facts:
                base_reward += 1.0  # Correct fact
                self.agent_facts.add(fact)
            elif fact not in self.environment_facts:
                base_reward -= 0.5  # Incorrect fact
            else:
                base_reward += 0.1  # Neutral/exploratory fact
        
        elif action.action_type == ActionType.ADD_RULE:
            # Reward for adding correct rules
            rule = action.parameters.get('rule', '')
            if rule in self.environment_rules:
                base_reward += 2.0  # Correct rule (more valuable than facts)
                self.agent_rules.add(rule)
            else:
                base_reward -= 0.3  # Incorrect rule
        
        elif action.action_type == ActionType.MAKE_INFERENCE:
            # Reward for correct inferences
            query = action.parameters.get('query', '')
            result = action.parameters.get('result', None)
            
            if query in self.ground_truth:
                expected = self.ground_truth[query]
                if result == expected:
                    base_reward += 3.0  # Correct inference
                else:
                    base_reward -= 1.0  # Incorrect inference
            else:
                base_reward += 0.2  # Exploratory inference
        
        elif action.action_type == ActionType.QUERY_KNOWLEDGE:
            # Small reward for knowledge exploration
            base_reward += 0.1
        
        elif action.action_type == ActionType.LEARN_FROM_FEEDBACK:
            # Reward for learning from feedback
            base_reward += 0.5
        
        elif action.action_type == ActionType.EXPLORE_TOPIC:
            # Reward for exploration
            base_reward += self.config['exploration_bonus']
        
        # Apply bonuses and penalties
        
        # Efficiency bonus (fewer steps to solve)
        if self.step_count < self.config['max_steps_per_episode'] * 0.5:
            base_reward *= (1 + self.config['efficiency_weight'])
        
        # Learning rate bonus (quick adaptation)
        if len(self.reward_history) > 5:
            recent_improvement = np.mean(self.reward_history[-3:]) - np.mean(self.reward_history[-6:-3])
            if recent_improvement > 0:
                base_reward *= (1 + self.config['learning_rate_bonus'])
        
        # Scale reward
        final_reward = base_reward * self.config['reward_scale']
        
        self.logger.debug(f"Action: {action.action_type.value}, Base reward: {base_reward:.2f}, Final reward: {final_reward:.2f}")
        
        return final_reward
    
    def _update_environment_state(self, action: Action):
        """Update the environment state based on the action"""
        # Update state machine
        if self.current_state == EnvironmentState.INITIAL:
            self.current_state = EnvironmentState.LEARNING
        elif self.current_state == EnvironmentState.LEARNING and self.step_count > 50:
            self.current_state = EnvironmentState.TESTING
        elif self.current_state == EnvironmentState.TESTING and self._all_queries_attempted():
            self.current_state = EnvironmentState.EVALUATION
    
    def _all_queries_attempted(self) -> bool:
        """Check if all scenario queries have been attempted"""
        if not self.current_scenario:
            return False
        
        attempted_queries = set()
        for action in self.action_history:
            if action.action_type == ActionType.MAKE_INFERENCE:
                query = action.parameters.get('query', '')
                attempted_queries.add(query)
        
        scenario_queries = set(self.current_scenario['queries'])
        return scenario_queries.issubset(attempted_queries)
    
    def _is_episode_done(self) -> bool:
        """Check if the current episode is complete"""
        # Episode ends if:
        # 1. Maximum steps reached
        # 2. All queries correctly answered
        # 3. Agent explicitly signals completion
        
        if self.step_count >= self.config['max_steps_per_episode']:
            return True
        
        if self.current_state == EnvironmentState.EVALUATION:
            return True
        
        # Check if all queries are correctly answered
        if self._all_queries_correctly_answered():
            return True
        
        return False
    
    def _all_queries_correctly_answered(self) -> bool:
        """Check if all scenario queries have been correctly answered"""
        if not self.current_scenario:
            return False
        
        correct_answers = 0
        total_queries = len(self.current_scenario['queries'])
        
        for action in self.action_history:
            if action.action_type == ActionType.MAKE_INFERENCE:
                query = action.parameters.get('query', '')
                result = action.parameters.get('result', None)
                
                if query in self.ground_truth and result == self.ground_truth[query]:
                    correct_answers += 1
        
        return correct_answers == total_queries
    
    def _get_current_state(self) -> Dict[str, Any]:
        """Get the current state representation"""
        return {
            'episode': self.episode_count,
            'step': self.step_count,
            'environment_state': self.current_state.value,
            'scenario': self.current_scenario['id'] if self.current_scenario else None,
            'scenario_difficulty': self.current_scenario['difficulty'] if self.current_scenario else 0,
            'agent_facts_count': len(self.agent_facts),
            'agent_rules_count': len(self.agent_rules),
            'total_reward': self.total_reward,
            'available_actions': [action.value for action in ActionType],
            'scenario_progress': {
                'facts_learned': len(self.agent_facts.intersection(self.environment_facts)),
                'rules_learned': len(self.agent_rules.intersection(self.environment_rules)),
                'queries_attempted': len([a for a in self.action_history if a.action_type == ActionType.MAKE_INFERENCE]),
                'correct_inferences': self._count_correct_inferences()
            }
        }
    
    def _count_correct_inferences(self) -> int:
        """Count the number of correct inferences made"""
        correct_count = 0
        for action in self.action_history:
            if action.action_type == ActionType.MAKE_INFERENCE:
                query = action.parameters.get('query', '')
                result = action.parameters.get('result', None)
                
                if query in self.ground_truth and result == self.ground_truth[query]:
                    correct_count += 1
        
        return correct_count
    
    def _get_info(self) -> Dict[str, Any]:
        """Get additional information about the current state"""
        return {
            'scenario_name': self.current_scenario['name'] if self.current_scenario else None,
            'scenario_description': self.current_scenario['description'] if self.current_scenario else None,
            'remaining_steps': self.config['max_steps_per_episode'] - self.step_count,
            'performance_metrics': self._calculate_performance_metrics(),
            'hints': self._generate_hints(),
            'available_knowledge': {
                'facts': list(self.environment_facts),
                'rules': list(self.environment_rules),
                'queries': self.current_scenario['queries'] if self.current_scenario else []
            }
        }
    
    def _calculate_performance_metrics(self) -> Dict[str, float]:
        """Calculate current performance metrics"""
        if not self.reward_history:
            return {'accuracy': 0.0, 'efficiency': 0.0, 'learning_rate': 0.0}
        
        # Accuracy: ratio of positive to total rewards
        positive_rewards = sum(1 for r in self.reward_history if r > 0)
        accuracy = positive_rewards / len(self.reward_history) if self.reward_history else 0.0
        
        # Efficiency: reward per step
        efficiency = self.total_reward / self.step_count if self.step_count > 0 else 0.0
        
        # Learning rate: improvement over time
        if len(self.reward_history) >= 10:
            early_avg = np.mean(self.reward_history[:5])
            recent_avg = np.mean(self.reward_history[-5:])
            learning_rate = (recent_avg - early_avg) / early_avg if early_avg != 0 else 0.0
        else:
            learning_rate = 0.0
        
        return {
            'accuracy': accuracy,
            'efficiency': efficiency,
            'learning_rate': learning_rate
        }
    
    def _generate_hints(self) -> List[str]:
        """Generate helpful hints for the agent"""
        hints = []
        
        if not self.current_scenario:
            return hints
        
        # Hint about missing facts
        missing_facts = self.environment_facts - self.agent_facts
        if missing_facts and len(missing_facts) <= 3:
            hints.append(f"Consider learning these facts: {list(missing_facts)[:2]}")
        
        # Hint about missing rules
        missing_rules = self.environment_rules - self.agent_rules
        if missing_rules and len(missing_rules) <= 2:
            hints.append(f"You might need this rule: {list(missing_rules)[0]}")
        
        # Hint about unattempted queries
        attempted_queries = set()
        for action in self.action_history:
            if action.action_type == ActionType.MAKE_INFERENCE:
                attempted_queries.add(action.parameters.get('query', ''))
        
        unattempted = set(self.current_scenario['queries']) - attempted_queries
        if unattempted:
            hints.append(f"Try answering: {list(unattempted)[0]}")
        
        return hints
    
    def _finalize_episode(self):
        """Finalize the current episode"""
        # Calculate episode performance
        performance = self._calculate_episode_performance()
        self.agent_performance_history.append(performance)
        
        # Log episode summary
        self.logger.info(f"Episode {self.episode_count} completed:")
        self.logger.info(f"  Scenario: {self.current_scenario['name']}")
        self.logger.info(f"  Steps: {self.step_count}")
        self.logger.info(f"  Total Reward: {self.total_reward:.2f}")
        self.logger.info(f"  Performance: {performance:.2f}")
        
        self.current_state = EnvironmentState.COMPLETE
    
    def _calculate_episode_performance(self) -> float:
        """Calculate overall performance for the episode"""
        metrics = self._calculate_performance_metrics()
        
        # Weighted combination of metrics
        performance = (
            metrics['accuracy'] * self.config['accuracy_weight'] +
            min(metrics['efficiency'], 1.0) * self.config['efficiency_weight'] +
            max(metrics['learning_rate'], 0.0) * self.config['creativity_weight']
        )
        
        return performance
    
    def _reset_environment(self):
        """Reset the environment to initial state"""
        self.current_state = EnvironmentState.INITIAL
        self.step_count = 0
        self.total_reward = 0.0
        self.agent_facts = set()
        self.agent_rules = set()
        self.reward_history = []
        self.action_history = []
    
    def get_action_space(self) -> List[ActionType]:
        """Get the available action space"""
        return list(ActionType)
    
    def get_state_space_description(self) -> Dict[str, str]:
        """Get description of the state space"""
        return {
            'episode': 'Current episode number',
            'step': 'Current step within episode',
            'environment_state': 'Current state of the environment',
            'scenario': 'Current learning scenario ID',
            'scenario_difficulty': 'Difficulty level of current scenario',
            'agent_facts_count': 'Number of facts learned by agent',
            'agent_rules_count': 'Number of rules learned by agent',
            'total_reward': 'Cumulative reward for current episode',
            'scenario_progress': 'Progress metrics for current scenario'
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics about the environment"""
        return {
            'total_episodes': self.episode_count,
            'current_episode_steps': self.step_count,
            'average_performance': np.mean(self.agent_performance_history) if self.agent_performance_history else 0.0,
            'performance_trend': self._calculate_performance_trend(),
            'scenario_statistics': self._get_scenario_statistics(),
            'action_distribution': self._get_action_distribution(),
            'reward_statistics': {
                'total_reward': self.total_reward,
                'average_reward_per_step': self.total_reward / self.step_count if self.step_count > 0 else 0.0,
                'reward_variance': np.var(self.reward_history) if self.reward_history else 0.0
            }
        }
    
    def _calculate_performance_trend(self) -> str:
        """Calculate the trend in agent performance"""
        if len(self.agent_performance_history) < 5:
            return "insufficient_data"
        
        recent_avg = np.mean(self.agent_performance_history[-5:])
        earlier_avg = np.mean(self.agent_performance_history[-10:-5]) if len(self.agent_performance_history) >= 10 else np.mean(self.agent_performance_history[:-5])
        
        if recent_avg > earlier_avg * 1.1:
            return "improving"
        elif recent_avg < earlier_avg * 0.9:
            return "declining"
        else:
            return "stable"
    
    def _get_scenario_statistics(self) -> Dict[str, Any]:
        """Get statistics about scenario performance"""
        # This would track performance across different scenarios
        # For now, return basic info
        return {
            'current_scenario': self.current_scenario['id'] if self.current_scenario else None,
            'scenario_difficulty': self.current_scenario['difficulty'] if self.current_scenario else 0,
            'scenarios_available': len(self.scenarios)
        }
    
    def _get_action_distribution(self) -> Dict[str, int]:
        """Get distribution of actions taken"""
        action_counts = {}
        for action in self.action_history:
            action_type = action.action_type.value
            action_counts[action_type] = action_counts.get(action_type, 0) + 1
        
        return action_counts

